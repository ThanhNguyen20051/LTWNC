﻿using System;
using System.Collections.Generic;

namespace FFoodsStore.Models;

public partial class OrderDetailsTopping
{
    public int ID { get; set; }

    public int OrderDetailsID { get; set; }

    public int ToppingID { get; set; }

    public decimal? ToppingPrice { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string? UpdatedBy { get; set; }

    // THÊM DÒNG NÀY
    public virtual Topping? Topping { get; set; }
}
