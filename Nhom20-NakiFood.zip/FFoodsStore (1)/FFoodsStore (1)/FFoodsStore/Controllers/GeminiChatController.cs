using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using System.Text;
using System.Text.Json;
using System.Linq;

namespace FFoodsStore.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GeminiChatController : ControllerBase
    {
        private readonly StoreDbContext _context;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;

        public GeminiChatController(
            StoreDbContext context,
            IHttpClientFactory httpClientFactory,
            IConfiguration configuration)
        {
            _context = context;
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
        }

        // POST: /api/geminichat/chat
        [HttpPost("chat")]
        public async Task<IActionResult> Chat([FromBody] GeminiChatRequest request)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(request.Message))
                {
                    return BadRequest(new { reply = "Tin nhắn không được để trống!" });
                }

                // Get API Key from config or use hardcoded one
                var apiKey = _configuration["Gemini:ApiKey"] ?? "AIzaSyAfPnjlx1Z5o7xXbOcou2mqEyvE1VU-hxk";

                // Prepare context from database
                var context = await PrepareContextAsync();

                // Generate Gemini response
                var reply = await GenerateGeminiResponseAsync(request.Message, context, apiKey);

                return Ok(new { reply = reply });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[GEMINI CHAT] Error: {ex.Message}");
                return StatusCode(500, new { reply = "Xin lỗi, đã xảy ra lỗi. Vui lòng thử lại sau! 😔" });
            }
        }

        // Prepare context from database
        private async Task<string> PrepareContextAsync()
        {
            var contextBuilder = new StringBuilder();

            // Get products with prices
            var productsList = await _context.Products
                .Include(p => p.ProductDetails)
                .Include(p => p.ProductType)
                .Where(p => (p.IsDeleted == null || p.IsDeleted == false) 
                         && (p.IsActive == null || p.IsActive == true))
                .Take(50)
                .ToListAsync();

            if (productsList.Any())
            {
                contextBuilder.AppendLine("=== DANH SÁCH SẢN PHẨM ===");
                foreach (var p in productsList)
                {
                    var activeDetails = p.ProductDetails?
                        .Where(pd => pd.IsDelete == null || pd.IsDelete == false && pd.Price.HasValue)
                        .ToList() ?? new List<Models.ProductDetail>();
                    
                    var prices = activeDetails.Select(pd => pd.Price!.Value).ToList();
                    var minPrice = prices.Any() ? prices.Min() : 0m;
                    var maxPrice = prices.Any() ? prices.Max() : 0m;
                    
                    var priceInfo = minPrice == maxPrice 
                        ? $"{minPrice:N0}đ" 
                        : $"{minPrice:N0}đ - {maxPrice:N0}đ";
                    
                    contextBuilder.AppendLine($"- {p.ProductName ?? "N/A"} ({p.ProductType?.TypeName ?? "Khác"}) - Giá: {priceInfo}");
                    if (!string.IsNullOrWhiteSpace(p.Description))
                    {
                        contextBuilder.AppendLine($"  {p.Description}");
                    }
                }
                contextBuilder.AppendLine();
            }

            // Get promotions
            var promotions = await _context.Promotion
                .Where(p => p.IsActive && !p.IsDeleted 
                         && p.StartDate <= DateTime.Now 
                         && p.EndDate >= DateTime.Now)
                .OrderByDescending(p => p.CreatedDate)
                .Take(10)
                .ToListAsync();

            if (promotions.Any())
            {
                contextBuilder.AppendLine("=== KHUYẾN MÃI HIỆN TẠI ===");
                foreach (var promo in promotions)
                {
                    var discountValue = promo.Type == 1 ? $"{promo.Value}%" : $"{promo.Value:N0}đ";
                    contextBuilder.AppendLine($"- {promo.Name}: Giảm {discountValue}");
                    if (!string.IsNullOrWhiteSpace(promo.Description))
                    {
                        contextBuilder.AppendLine($"  {promo.Description}");
                    }
                }
                contextBuilder.AppendLine();
            }

            // Get categories
            var categories = await _context.Set<Models.ProductType>()
                .Where(t => t.IsDelete == null || t.IsDelete == false)
                .ToListAsync();

            if (categories.Any())
            {
                contextBuilder.AppendLine("=== DANH MỤC SẢN PHẨM ===");
                foreach (var cat in categories)
                {
                    contextBuilder.AppendLine($"- {cat.TypeName ?? ""}");
                }
                contextBuilder.AppendLine();
            }

            return contextBuilder.ToString();
        }

        // Generate Gemini response
        private async Task<string> GenerateGeminiResponseAsync(string userMessage, string context, string apiKey)
        {
            try
            {
                var client = _httpClientFactory.CreateClient();
                client.Timeout = TimeSpan.FromSeconds(30);

                // Build system prompt with context
                var systemPrompt = $@"Bạn là FFoods AI Assistant - trợ lý AI thân thiện của cửa hàng thức ăn nhanh FastFood.

NHIỆM VỤ:
- Luôn trả lời bằng tiếng Việt
- Luôn thân thiện, nhiệt tình và hữu ích
- Khi người dùng hỏi về sản phẩm, hãy gợi ý các món dựa trên dữ liệu trong cơ sở dữ liệu
- Nếu người dùng hỏi về giá, hãy tham khảo thông tin giá trong dữ liệu
- Nếu người dùng hỏi về khuyến mãi, hãy thông báo các chương trình khuyến mãi hiện tại
- Sử dụng markdown để format câu trả lời (bold, lists, line breaks)
- Luôn khuyến khích người dùng xem chi tiết tại website

DỮ LIỆU CƠ SỞ DỮ LIỆU:
{context}

HƯỚNG DẪN:
- Khi người dùng hỏi về menu hoặc món ăn, hãy liệt kê một số món phổ biến từ danh sách trên
- Khi người dùng hỏi về khuyến mãi, hãy thông báo các chương trình khuyến mãi hiện tại
- Khi người dùng hỏi về giá, hãy cung cấp thông tin giá từ dữ liệu
- Nếu không có thông tin trong dữ liệu, hãy trả lời một cách chung chung nhưng vẫn hữu ích
- Sử dụng xuống dòng và format đẹp để câu trả lời dễ đọc

Hãy trả lời câu hỏi của người dùng một cách tự nhiên và hữu ích.";

                var fullPrompt = $"{systemPrompt}\n\nNgười dùng hỏi: {userMessage}\n\nHãy trả lời:";

                var requestBody = new
                {
                    contents = new[]
                    {
                        new
                        {
                            parts = new[]
                            {
                                new { text = fullPrompt }
                            }
                        }
                    },
                    generationConfig = new
                    {
                        temperature = 0.7,
                        topK = 40,
                        topP = 0.95,
                        maxOutputTokens = 1024
                    }
                };

                var jsonContent = JsonSerializer.Serialize(requestBody);
                var httpContent = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await client.PostAsync(
                    $"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={apiKey}",
                    httpContent
                );

                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    throw new Exception($"Gemini API error: {response.StatusCode} - {errorContent}");
                }

                var jsonString = await response.Content.ReadAsStringAsync();
                var result = JsonSerializer.Deserialize<GeminiResponse>(jsonString, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                return result?.candidates?.FirstOrDefault()?.content?.parts?.FirstOrDefault()?.text
                    ?? "Xin lỗi, tôi không thể trả lời câu hỏi này. Vui lòng thử lại sau.";
            }
            catch (Exception ex)
            {
                throw new Exception($"Error calling Gemini API: {ex.Message}", ex);
            }
        }

        // Request/Response Models
        public class GeminiChatRequest
        {
            public string Message { get; set; } = string.Empty;
            public int? UserId { get; set; }
        }

        // Gemini Response Models
        private class GeminiResponse
        {
            public List<GeminiCandidate>? candidates { get; set; }
        }

        private class GeminiCandidate
        {
            public GeminiContent? content { get; set; }
        }

        private class GeminiContent
        {
            public List<GeminiPart>? parts { get; set; }
        }

        private class GeminiPart
        {
            public string? text { get; set; }
        }
    }
}

