using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using FFoodsStore.ViewModels;
using static FFoodsStore.Models.OrderStatus;
using static FFoodsStore.Models.OrderStatusHelper;
using Microsoft.EntityFrameworkCore.Query;

namespace FFoodsStore.Controllers
{
    [Route("Shipper")]
    public class ShipperController : Controller
    {
        private readonly StoreDbContext _context;

        public ShipperController(StoreDbContext context)
        {
            _context = context;
        }

        // GET: /Shipper
        // GET: /Shipper/Dashboard
        [HttpGet("")]
        [HttpGet("Dashboard")]
        public async Task<IActionResult> Dashboard()
        {
            // TODO: Get shipper ID from session/auth
            // For now, we'll get all orders that can be assigned to shipper
            var today = DateTime.Today;
            var tomorrow = today.AddDays(1);

            var vm = new ShipperDashboardVM
            {
                // Đơn đã được gán (Assigned hoặc Ready - có thể nhận)
                AssignedOrders = await _context.Orders
                    .CountAsync(o => (o.Status == (int)OrderStatus.Assigned 
                        || o.Status == (int)OrderStatus.Ready)
                        && (o.IsDeleted == null || o.IsDeleted == false)
                        && (o.Address == null || (!EF.Functions.Like(o.Address, "%Tại quầy%") && o.Address.ToLower() != "tại quầy"))),

                // Đơn đang giao (Accepted, PickedUp, OnTheWay, Arrived, Delivering)
                DeliveringOrders = await _context.Orders
                    .CountAsync(o => (o.Status == (int)OrderStatus.Accepted
                        || o.Status == (int)OrderStatus.PickedUp
                        || o.Status == (int)OrderStatus.OnTheWay
                        || o.Status == (int)OrderStatus.Arrived
                        || o.Status == (int)OrderStatus.Delivering)
                        && (o.IsDeleted == null || o.IsDeleted == false)
                        && (o.Address == null || (!EF.Functions.Like(o.Address, "%Tại quầy%") && o.Address.ToLower() != "tại quầy"))),

                // Đơn đã giao thành công hôm nay (loại bỏ đơn tại quầy)
                CompletedToday = await _context.Orders
                    .CountAsync(o => (o.Status == (int)OrderStatus.Delivered
                        || o.Status == (int)OrderStatus.Completed)
                        && o.UpdatedDate >= today
                        && o.UpdatedDate < tomorrow
                        && (o.IsDeleted == null || o.IsDeleted == false)
                        && (o.Address == null || (!EF.Functions.Like(o.Address, "%Tại quầy%") && o.Address.ToLower() != "tại quầy"))),

                // Đơn giao thất bại hôm nay (loại bỏ đơn tại quầy)
                FailedToday = await _context.Orders
                    .CountAsync(o => (o.Status == (int)OrderStatus.DeliveryFailed
                        || o.Status == (int)OrderStatus.FailedDelivery)
                        && o.UpdatedDate >= today
                        && o.UpdatedDate < tomorrow
                        && (o.IsDeleted == null || o.IsDeleted == false)
                        && (o.Address == null || (!EF.Functions.Like(o.Address, "%Tại quầy%") && o.Address.ToLower() != "tại quầy"))),

                IsOnline = true // TODO: Get from database or session
            };

            // Recent orders (Assigned, Accepted, PickedUp, OnTheWay, Arrived, Delivering)
            // Chỉ lấy đơn cần giao hàng, loại bỏ đơn tại quầy
            var recentOrders = await _context.Orders
                .Where(o => (o.Status == (int)OrderStatus.Assigned
                    || o.Status == (int)OrderStatus.Accepted
                    || o.Status == (int)OrderStatus.PickedUp
                    || o.Status == (int)OrderStatus.OnTheWay
                    || o.Status == (int)OrderStatus.Arrived
                    || o.Status == (int)OrderStatus.Delivering
                    || o.Status == (int)OrderStatus.Ready)
                    && (o.IsDeleted == null || o.IsDeleted == false)
                    && (o.Address == null || (!EF.Functions.Like(o.Address, "%Tại quầy%") && o.Address.ToLower() != "tại quầy")))
                .OrderByDescending(o => o.CreateDate)
                .Take(10)
                .ToListAsync();

            vm.RecentOrders = recentOrders.Select(o => new ShipperOrderVM
            {
                Id = o.ID,
                OrderCode = o.OrderCode ?? "",
                CustomerName = o.CustomerName ?? "",
                PhoneNumber = o.PhoneNumber ?? "",
                Address = o.Address ?? "",
                Status = o.Status,
                StatusName = GetStatusName(o.Status),
                PaymentMethod = o.PaymentMethod ?? "cod",
                IsPaid = o.PaymentMethod != "cod",
                CreateDate = o.CreateDate,
                Total = _context.OrderDetails
                    .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                    .Sum(od => od.TotalMoney ?? 0),
                CodAmount = o.PaymentMethod == "cod" 
                    ? _context.OrderDetails
                        .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                        .Sum(od => od.TotalMoney ?? 0)
                    : 0
            }).ToList();

            // Calculate today earnings (simplified - assume fixed fee per order)
            vm.TodayEarnings = vm.CompletedToday * 20000; // 20k per order

            return View(vm);
        }

        // GET: /Shipper/Orders?status=assigned
        [HttpGet("Orders")]
        public async Task<IActionResult> Orders(string? status = null)
        {
            var query = _context.Orders
                .Where(o => (o.IsDeleted == null || o.IsDeleted == false)
                    // Loại bỏ đơn tại quầy - chỉ lấy đơn cần giao hàng
                    && (o.Address == null || (!EF.Functions.Like(o.Address, "%Tại quầy%") && o.Address.ToLower() != "tại quầy")));

            // Filter by status
            if (!string.IsNullOrEmpty(status))
            {
                var statusInt = status switch
                {
                    "assigned" => (int)OrderStatus.Assigned,
                    "accepted" => (int)OrderStatus.Accepted,
                    "pickedup" => (int)OrderStatus.PickedUp,
                    "ontheway" => (int)OrderStatus.OnTheWay,
                    "arrived" => (int)OrderStatus.Arrived,
                    "delivering" => (int)OrderStatus.Delivering,
                    "delivered" => (int)OrderStatus.Delivered,
                    "failed" => (int)OrderStatus.DeliveryFailed,
                    _ => (int?)null
                };

                if (statusInt.HasValue)
                {
                    query = query.Where(o => o.Status == statusInt.Value);
                }
            }
            else
            {
                // Default: show assigned and active delivery orders
                query = query.Where(o => o.Status == (int)OrderStatus.Assigned
                    || o.Status == (int)OrderStatus.Accepted
                    || o.Status == (int)OrderStatus.PickedUp
                    || o.Status == (int)OrderStatus.OnTheWay
                    || o.Status == (int)OrderStatus.Arrived
                    || o.Status == (int)OrderStatus.Delivering
                    || o.Status == (int)OrderStatus.Ready);
            }

            var orders = await query
                .OrderByDescending(o => o.CreateDate)
                .ToListAsync();

            var orderVMs = orders.Select(o => new ShipperOrderVM
            {
                Id = o.ID,
                OrderCode = o.OrderCode ?? "",
                CustomerName = o.CustomerName ?? "",
                PhoneNumber = o.PhoneNumber ?? "",
                Address = o.Address ?? "",
                Status = o.Status,
                StatusName = GetStatusName(o.Status),
                PaymentMethod = o.PaymentMethod ?? "cod",
                IsPaid = o.PaymentMethod != "cod",
                CreateDate = o.CreateDate,
                Total = _context.OrderDetails
                    .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                    .Sum(od => od.TotalMoney ?? 0),
                CodAmount = o.PaymentMethod == "cod"
                    ? _context.OrderDetails
                        .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                        .Sum(od => od.TotalMoney ?? 0)
                    : 0
            }).ToList();

            ViewBag.StatusFilter = status;
            return View(orderVMs);
        }

        // GET: /Shipper/OrderDetail/{id}
        [HttpGet("OrderDetail/{id}")]
        public async Task<IActionResult> OrderDetail(int id)
        {
            var order = await _context.Orders
                .FirstOrDefaultAsync(o => o.ID == id && (o.IsDeleted == null || o.IsDeleted == false));

            if (order == null)
            {
                return NotFound();
            }

            var orderDetails = await _context.OrderDetails
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.Product)
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.ProductSize)
                .Where(od => od.OrderID == id && (od.IsDelete == null || od.IsDelete == false))
                .ToListAsync();

            var vm = new ShipperOrderVM
            {
                Id = order.ID,
                OrderCode = order.OrderCode ?? "",
                CustomerName = order.CustomerName ?? "",
                PhoneNumber = order.PhoneNumber ?? "",
                Address = order.Address ?? "",
                Status = order.Status,
                StatusName = GetStatusName(order.Status),
                PaymentMethod = order.PaymentMethod ?? "cod",
                IsPaid = order.PaymentMethod != "cod",
                CreateDate = order.CreateDate,
                ReadyTime = order.CreateDate?.AddMinutes(30), // Giả định 30 phút để chuẩn bị
                Deadline = order.CreateDate?.AddHours(2), // Deadline 2 giờ sau khi đặt
                Total = orderDetails.Sum(od => od.TotalMoney ?? 0),
                CodAmount = order.PaymentMethod == "cod"
                    ? orderDetails.Sum(od => od.TotalMoney ?? 0)
                    : 0,
                StoreAddress = "828 Sư Vạn Hạnh, Phường Hòa Hưng, TP. Hồ Chí Minh",
                StorePhone = "0123 456 789", // TODO: Get from config
                Items = orderDetails.Select(od => new ShipperOrderDetailVM
                {
                    Id = od.ID,
                    ProductName = od.ProductDetail?.Product?.ProductName ?? "",
                    SizeName = od.ProductDetail?.ProductSize?.SizeName ?? "",
                    Quantity = od.Quantity ?? 0,
                    Price = od.ProductDetail?.Price ?? 0,
                    TotalMoney = od.TotalMoney ?? 0
                }).ToList()
            };

            return View(vm);
        }

        // GET: /Shipper/History
        [HttpGet("History")]
        public async Task<IActionResult> History(DateTime? fromDate = null, DateTime? toDate = null)
        {
            var query = _context.Orders
                .Where(o => (o.Status == (int)OrderStatus.Delivered
                    || o.Status == (int)OrderStatus.Completed
                    || o.Status == (int)OrderStatus.DeliveryFailed
                    || o.Status == (int)OrderStatus.FailedDelivery)
                    && (o.IsDeleted == null || o.IsDeleted == false)
                    // Loại bỏ đơn tại quầy - chỉ lấy đơn cần giao hàng
                    && (o.Address == null || (!EF.Functions.Like(o.Address, "%Tại quầy%") && o.Address.ToLower() != "tại quầy")));

            if (fromDate.HasValue)
            {
                query = query.Where(o => o.UpdatedDate >= fromDate.Value);
            }

            if (toDate.HasValue)
            {
                query = query.Where(o => o.UpdatedDate <= toDate.Value.AddDays(1));
            }

            var orders = await query
                .OrderByDescending(o => o.UpdatedDate)
                .ToListAsync();

            var historyVMs = orders.Select(o => new ShipperHistoryVM
            {
                OrderId = o.ID,
                OrderCode = o.OrderCode ?? "",
                CustomerName = o.CustomerName ?? "",
                Address = o.Address ?? "",
                Status = o.Status,
                StatusName = GetStatusName(o.Status),
                CreateDate = o.CreateDate,
                CompletedDate = o.UpdatedDate,
                FailureReason = o.ReasonCancel,
                Total = _context.OrderDetails
                    .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                    .Sum(od => od.TotalMoney ?? 0)
            }).ToList();

            ViewBag.FromDate = fromDate;
            ViewBag.ToDate = toDate;
            return View(historyVMs);
        }

        // GET: /Shipper/Profile
        [HttpGet("Profile")]
        public IActionResult Profile()
        {
            return View();
        }

        // GET: /Shipper/Support
        [HttpGet("Support")]
        public IActionResult Support()
        {
            return View();
        }

        // GET: /Shipper/Report
        [HttpGet("Report")]
        public IActionResult Report()
        {
            return View();
        }
    }
}

