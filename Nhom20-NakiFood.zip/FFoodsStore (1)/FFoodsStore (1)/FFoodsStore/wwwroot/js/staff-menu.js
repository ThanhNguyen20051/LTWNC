// ============================================
// STAFF MENU - Nhận đơn tại quầy
// ============================================

let staffCart = [];
let products = [];
let categories = [];

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    loadCategories();
    loadMenu();
    setupEventListeners();
});

// Load categories
async function loadCategories() {
    try {
        const response = await fetch('/api/menu/categories');
        const data = await response.json();
        console.log('Categories API response:', data);
        categories = data.Categories || data.categories || [];
        
        const select = document.getElementById('categoryFilter');
        // Clear existing options except "Tất cả"
        while (select.children.length > 1) {
            select.removeChild(select.lastChild);
        }
        
        categories.forEach(cat => {
            const option = document.createElement('option');
            option.value = cat.ID || cat.id;
            option.textContent = cat.Name || cat.name;
            select.appendChild(option);
        });
        
        console.log('Loaded categories:', categories);
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

// Load menu items
async function loadMenu() {
    const grid = document.getElementById('menuGrid');
    grid.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; padding: 40px;"><i class="fas fa-spinner fa-spin" style="font-size: 48px;"></i><p>Đang tải menu...</p></div>';
    
    try {
        const searchQuery = document.getElementById('searchBox').value;
        const categoryId = document.getElementById('categoryFilter').value;
        
        // Find category slug if categoryId is not 'all'
        let categorySlug = null;
        if (categoryId !== 'all' && categories.length > 0) {
            const category = categories.find(cat => (cat.ID || cat.id) == categoryId);
            if (category) {
                categorySlug = category.Slug || category.slug;
            }
        }
        
        const url = `/api/menu/items?page=1&pageSize=100${searchQuery ? '&q=' + encodeURIComponent(searchQuery) : ''}${categorySlug ? '&cat=' + encodeURIComponent(categorySlug) : ''}`;
        console.log('Loading menu from:', url);
        const response = await fetch(url);
        const data = await response.json();
        
        console.log('Menu API response:', data);
        products = data.items || data.Items || [];
        renderMenu(products);
    } catch (error) {
        console.error('Error loading menu:', error);
        grid.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: #e74c3c;"><i class="fas fa-exclamation-triangle"></i><p>Có lỗi xảy ra khi tải menu</p></div>';
    }
}

// Render menu
function renderMenu(items) {
    const grid = document.getElementById('menuGrid');
    
    if (!items || items.length === 0) {
        grid.innerHTML = '<div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: #7f8c8d;"><i class="fas fa-inbox"></i><p>Không tìm thấy món nào</p></div>';
        return;
    }
    
    grid.innerHTML = items.map(item => {
        // Handle both PascalCase and camelCase
        const productId = item.productId || item.ProductId || item.ProductDetailId || 0;
        const productDetailId = item.productDetailId || item.ProductDetailId || 0;
        const name = item.name || item.Name || 'Sản phẩm';
        const price = item.price || item.Price || 0;
        const imageUrl = item.imageUrl || item.ImageUrl || '';
        const categoryName = item.categoryName || item.CategoryName || 'Khác';
        
        return `
        <div class="menu-card" style="background: white; border: 1px solid #dee2e6; border-radius: 8px; overflow: hidden; cursor: pointer; transition: transform 0.2s;"
             onclick="openProductModal(${productId})"
             onmouseover="this.style.transform='translateY(-5px)'; this.style.boxShadow='0 4px 8px rgba(0,0,0,0.1)';"
             onmouseout="this.style.transform=''; this.style.boxShadow='none';">
            <div style="width: 100%; height: 200px; overflow: hidden; background: #f8f9fa;">
                <img src="${imageUrl || 'https://picsum.photos/seed/' + productId + '/400/300'}" 
                     alt="${escapeHtml(name)}"
                     style="width: 100%; height: 100%; object-fit: cover;"
                     onerror="this.src='https://picsum.photos/seed/${productId}/400/300'">
            </div>
            <div style="padding: 15px;">
                <div style="font-size: 12px; color: #7f8c8d; margin-bottom: 5px;">${escapeHtml(categoryName)}</div>
                <h3 style="margin: 0 0 10px 0; font-size: 18px; color: #2c3e50;">${escapeHtml(name)}</h3>
                <div style="display: flex; justify-content: space-between; align-items: center;">
                    <span style="font-size: 20px; font-weight: bold; color: #e74c3c;">${formatPrice(price)}</span>
                    <button onclick="event.stopPropagation(); addToCart(${productId}, ${productDetailId})" 
                            style="padding: 8px 16px; background: #27ae60; color: white; border: none; border-radius: 4px; cursor: pointer; font-weight: bold;">
                        <i class="fas fa-plus"></i> Thêm
                    </button>
                </div>
            </div>
        </div>
        `;
    }).join('');
}

// Open product modal
async function openProductModal(productId) {
    const modal = document.getElementById('productModal');
    const content = document.getElementById('productModalContent');
    
    modal.style.display = 'flex';
    content.innerHTML = '<div style="text-align: center; padding: 40px;"><i class="fas fa-spinner fa-spin" style="font-size: 48px;"></i><p>Đang tải...</p></div>';
    
    try {
        const response = await fetch(`/api/product/${productId}`);
        const product = await response.json();
        
        let sizeOptions = '';
        let defaultPrice = 0;
        let defaultProductDetailId = null;
        
        if (product.productDetails && product.productDetails.length > 0) {
            product.productDetails.forEach((detail, index) => {
                if (index === 0) {
                    defaultPrice = detail.price;
                    defaultProductDetailId = detail.id;
                }
                sizeOptions += `<option value="${detail.id}" data-price="${detail.price}">${detail.sizeName} - ${formatPrice(detail.price)}</option>`;
            });
        }
        
        let toppingOptions = '';
        if (product.toppings && product.toppings.length > 0) {
            product.toppings.forEach(topping => {
                toppingOptions += `
                    <label style="display: flex; align-items: center; padding: 10px; border: 1px solid #dee2e6; border-radius: 4px; margin-bottom: 10px; cursor: pointer;">
                        <input type="checkbox" value="${topping.id}" data-price="${topping.price || 0}" style="margin-right: 10px;">
                        <span style="flex: 1;">${topping.name}</span>
                        <span style="color: #e74c3c; font-weight: bold;">+${formatPrice(topping.price || 0)}</span>
                    </label>
                `;
            });
        }
        
        content.innerHTML = `
            <div style="position: relative;">
                <img src="${product.imageUrl || 'https://picsum.photos/seed/' + productId + '/600/400'}" 
                     alt="${product.name}"
                     style="width: 100%; height: 300px; object-fit: cover; border-radius: 8px 8px 0 0;"
                     onerror="this.src='https://picsum.photos/seed/${productId}/600/400'">
            </div>
            <div style="padding: 20px;">
                <h2 style="margin: 0 0 10px 0;">${escapeHtml(product.name)}</h2>
                <p style="color: #7f8c8d; margin-bottom: 20px;">${escapeHtml(product.description || '')}</p>
                
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 10px; font-weight: bold;">Chọn size:</label>
                    <select id="productSize" style="width: 100%; padding: 10px; border: 1px solid #dee2e6; border-radius: 4px; font-size: 16px;">
                        ${sizeOptions}
                    </select>
                </div>
                
                ${toppingOptions ? `
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 10px; font-weight: bold;">Topping (tùy chọn):</label>
                    <div id="toppingOptions">
                        ${toppingOptions}
                    </div>
                </div>
                ` : ''}
                
                <div style="margin-bottom: 20px;">
                    <label style="display: block; margin-bottom: 10px; font-weight: bold;">Số lượng:</label>
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <button onclick="changeQuantity(-1)" style="width: 40px; height: 40px; border: 1px solid #dee2e6; background: white; border-radius: 4px; cursor: pointer; font-size: 20px;">-</button>
                        <input type="number" id="productQuantity" value="1" min="1" 
                               style="width: 80px; text-align: center; padding: 10px; border: 1px solid #dee2e6; border-radius: 4px; font-size: 16px;">
                        <button onclick="changeQuantity(1)" style="width: 40px; height: 40px; border: 1px solid #dee2e6; background: white; border-radius: 4px; cursor: pointer; font-size: 20px;">+</button>
                    </div>
                </div>
                
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; padding: 15px; background: #f8f9fa; border-radius: 4px;">
                    <span style="font-size: 18px; font-weight: bold;">Tổng:</span>
                    <span id="modalTotal" style="font-size: 24px; font-weight: bold; color: #e74c3c;">${formatPrice(defaultPrice)}</span>
                </div>
                
                <button onclick="addToCartFromModal(${productId})" 
                        style="width: 100%; padding: 15px; background: #27ae60; color: white; border: none; border-radius: 4px; font-size: 16px; font-weight: bold; cursor: pointer;">
                    <i class="fas fa-cart-plus"></i> Thêm vào giỏ hàng
                </button>
            </div>
        `;
        
        // Update total when size or quantity changes
        document.getElementById('productSize').addEventListener('change', updateModalTotal);
        document.getElementById('productQuantity').addEventListener('input', updateModalTotal);
        document.querySelectorAll('#toppingOptions input[type="checkbox"]').forEach(cb => {
            cb.addEventListener('change', updateModalTotal);
        });
        
    } catch (error) {
        console.error('Error loading product:', error);
        content.innerHTML = '<div style="text-align: center; padding: 40px; color: #e74c3c;"><i class="fas fa-exclamation-triangle"></i><p>Có lỗi xảy ra</p></div>';
    }
}

function closeProductModal() {
    document.getElementById('productModal').style.display = 'none';
}

function changeQuantity(delta) {
    const input = document.getElementById('productQuantity');
    const newValue = parseInt(input.value) + delta;
    if (newValue >= 1) {
        input.value = newValue;
        updateModalTotal();
    }
}

function updateModalTotal() {
    const sizeSelect = document.getElementById('productSize');
    const quantity = parseInt(document.getElementById('productQuantity').value) || 1;
    const selectedSize = sizeSelect.options[sizeSelect.selectedIndex];
    const basePrice = parseFloat(selectedSize.getAttribute('data-price')) || 0;
    
    let toppingPrice = 0;
    document.querySelectorAll('#toppingOptions input[type="checkbox"]:checked').forEach(cb => {
        toppingPrice += parseFloat(cb.getAttribute('data-price')) || 0;
    });
    
    const total = (basePrice + toppingPrice) * quantity;
    document.getElementById('modalTotal').textContent = formatPrice(total);
}

// Add to cart (simple - from menu grid)
function addToCart(productId, productDetailId) {
    const product = products.find(p => (p.productId || p.ProductId) == productId);
    if (!product) {
        console.error('Product not found:', productId);
        return;
    }
    
    const name = product.name || product.Name || 'Sản phẩm';
    const price = product.price || product.Price || 0;
    
    staffCart.push({
        productId: productId,
        productDetailId: productDetailId,
        productName: name,
        sizeName: 'Default',
        price: price,
        quantity: 1,
        toppings: []
    });
    
    updateCart();
    showNotification('Đã thêm vào giỏ hàng!', 'success');
}

// Add to cart from modal (with size, quantity, toppings)
function addToCartFromModal(productId) {
    const sizeSelect = document.getElementById('productSize');
    const quantity = parseInt(document.getElementById('productQuantity').value) || 1;
    const selectedSize = sizeSelect.options[sizeSelect.selectedIndex];
    const productDetailId = parseInt(selectedSize.value);
    const sizeName = selectedSize.textContent.split(' - ')[0];
    const basePrice = parseFloat(selectedSize.getAttribute('data-price')) || 0;
    
    const selectedToppings = [];
    let toppingPrice = 0;
    document.querySelectorAll('#toppingOptions input[type="checkbox"]:checked').forEach(cb => {
        const toppingId = parseInt(cb.value);
        const toppingPrice = parseFloat(cb.getAttribute('data-price')) || 0;
        selectedToppings.push({
            id: toppingId,
            name: cb.parentElement.querySelector('span').textContent.split('+')[0].trim(),
            price: toppingPrice
        });
    });
    
    const product = products.find(p => p.productId === productId);
    
    staffCart.push({
        productId: productId,
        productDetailId: productDetailId,
        productName: product?.name || 'Sản phẩm',
        sizeName: sizeName,
        price: basePrice,
        quantity: quantity,
        toppings: selectedToppings
    });
    
    updateCart();
    closeProductModal();
    showNotification('Đã thêm vào giỏ hàng!', 'success');
}

// Update cart display
function updateCart() {
    const cartCount = document.getElementById('cartCount');
    const cartItems = document.getElementById('cartItems');
    const cartTotal = document.getElementById('cartTotal');
    const createOrderBtn = document.getElementById('createOrderBtn');
    
    cartCount.textContent = staffCart.length;
    
    if (staffCart.length === 0) {
        cartItems.innerHTML = '<p style="text-align: center; color: #7f8c8d; padding: 40px;">Giỏ hàng trống</p>';
        cartTotal.textContent = '0 đ';
        createOrderBtn.disabled = true;
        return;
    }
    
    let total = 0;
    cartItems.innerHTML = staffCart.map((item, index) => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        
        return `
            <div style="padding: 15px; border-bottom: 1px solid #dee2e6; display: flex; justify-content: space-between; align-items: start;">
                <div style="flex: 1;">
                    <div style="font-weight: bold; margin-bottom: 5px;">${escapeHtml(item.productName)}</div>
                    <div style="font-size: 12px; color: #7f8c8d; margin-bottom: 5px;">${escapeHtml(item.sizeName)}</div>
                    ${item.toppings && item.toppings.length > 0 ? `
                        <div style="font-size: 12px; color: #7f8c8d;">
                            Topping: ${item.toppings.map(t => t.name).join(', ')}
                        </div>
                    ` : ''}
                    <div style="display: flex; align-items: center; gap: 10px; margin-top: 10px;">
                        <button onclick="changeCartQuantity(${index}, -1)" style="width: 30px; height: 30px; border: 1px solid #dee2e6; background: white; border-radius: 4px; cursor: pointer;">-</button>
                        <span style="min-width: 30px; text-align: center;">${item.quantity}</span>
                        <button onclick="changeCartQuantity(${index}, 1)" style="width: 30px; height: 30px; border: 1px solid #dee2e6; background: white; border-radius: 4px; cursor: pointer;">+</button>
                    </div>
                </div>
                <div style="text-align: right; margin-left: 15px;">
                    <div style="font-weight: bold; color: #e74c3c; margin-bottom: 5px;">${formatPrice(itemTotal)}</div>
                    <button onclick="removeFromCart(${index})" style="padding: 5px 10px; background: #e74c3c; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px;">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </div>
        `;
    }).join('');
    
    cartTotal.textContent = formatPrice(total);
    createOrderBtn.disabled = false;
}

function changeCartQuantity(index, delta) {
    const newQuantity = staffCart[index].quantity + delta;
    if (newQuantity >= 1) {
        staffCart[index].quantity = newQuantity;
        updateCart();
    } else {
        removeFromCart(index);
    }
}

function removeFromCart(index) {
    staffCart.splice(index, 1);
    updateCart();
}

function showCart() {
    document.getElementById('cartSidebar').style.right = '0';
    document.getElementById('cartOverlay').style.display = 'block';
}

function hideCart() {
    document.getElementById('cartSidebar').style.right = '-400px';
    document.getElementById('cartOverlay').style.display = 'none';
}

// Create order
async function createOrder() {
    if (staffCart.length === 0) {
        alert('Giỏ hàng trống!');
        return;
    }
    
    const customerName = prompt('Nhập tên khách hàng:');
    if (!customerName || !customerName.trim()) {
        alert('Vui lòng nhập tên khách hàng!');
        return;
    }
    
    // Số điện thoại là optional cho đơn tại quầy
    const phoneNumber = prompt('Nhập số điện thoại khách hàng (tùy chọn, có thể để trống):') || '';
    
    const address = prompt('Nhập địa chỉ (hoặc "Tại quầy" cho dine-in):', 'Tại quầy') || 'Tại quầy';
    
    try {
        // Get account ID (staff account)
        const user = JSON.parse(localStorage.getItem('user') || '{}');
        const accountId = user.id || 0;
        
        // Create order via API
        const response = await fetch('/api/staff/orders/create-dine-in', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                accountId: accountId,
                customerName: customerName.trim(),
                phoneNumber: phoneNumber.trim(),
                address: address.trim(),
                items: staffCart.map(item => ({
                    productDetailId: item.productDetailId,
                    quantity: item.quantity,
                    toppings: item.toppings.map(t => t.id)
                }))
            })
        });
        
        const data = await response.json();
        
        if (response.ok && data.success) {
            alert('Tạo đơn hàng thành công! Mã đơn: ' + (data.orderCode || ''));
            staffCart = [];
            updateCart();
            hideCart();
        } else {
            alert(data.message || 'Có lỗi xảy ra khi tạo đơn hàng!');
        }
    } catch (error) {
        console.error('Error creating order:', error);
        alert('Có lỗi xảy ra: ' + error.message);
    }
}

// Setup event listeners
function setupEventListeners() {
    document.getElementById('searchBox').addEventListener('input', debounce(loadMenu, 300));
    document.getElementById('categoryFilter').addEventListener('change', loadMenu);
}

// Utility functions
function formatPrice(amount) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(amount || 0);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function showNotification(message, type = 'info') {
    // Simple notification
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed; top: 20px; right: 20px; padding: 15px 20px; 
        background: ${type === 'success' ? '#27ae60' : '#3498db'}; 
        color: white; border-radius: 4px; z-index: 3000; box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    `;
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transition = 'opacity 0.3s';
        setTimeout(() => notification.remove(), 300);
    }, 2000);
}

