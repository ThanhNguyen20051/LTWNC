using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using FFoodsStore.ViewModels;
using static FFoodsStore.Models.OrderStatus;
using static FFoodsStore.Models.OrderStatusHelper;
using FFoodsStore.Models.Dtos;

namespace FFoodsStore.Controllers
{
    [Route("Staff")]
    public class StaffController : Controller
    {
        private readonly StoreDbContext _context;

        public StaffController(StoreDbContext context)
        {
            _context = context;
        }

        // GET: /Staff
        // GET: /Staff/Dashboard
        [HttpGet("")]
        [HttpGet("Dashboard")]
        public async Task<IActionResult> Dashboard()
        {
            var vm = new StaffDashboardVM
            {
                PendingOrders = await _context.Orders
                    .CountAsync(o => o.Status == (int)OrderStatus.Pending && (o.IsDeleted == null || o.IsDeleted == false)),
                
                InProgressOrders = await _context.Orders
                    .CountAsync(o => (o.Status == (int)OrderStatus.InProgress || o.Status == (int)OrderStatus.Preparing) 
                        && (o.IsDeleted == null || o.IsDeleted == false)),
                
                ReadyOrders = await _context.Orders
                    .CountAsync(o => o.Status == (int)OrderStatus.Ready && (o.IsDeleted == null || o.IsDeleted == false)),
                
                DeliveringOrders = await _context.Orders
                    .CountAsync(o => (o.Status == (int)OrderStatus.Delivering || o.Status == (int)OrderStatus.Shipping) 
                        && (o.IsDeleted == null || o.IsDeleted == false)),
                
                LowStockItems = 0 // TODO: Implement inventory tracking
            };

            // Recent orders
            var recentOrders = await _context.Orders
                .Where(o => (o.IsDeleted == null || o.IsDeleted == false) 
                    && o.Status != (int)OrderStatus.Completed 
                    && o.Status != (int)OrderStatus.Canceled
                    && o.Status != (int)OrderStatus.Failed)
                .OrderByDescending(o => o.CreateDate)
                .Take(10)
                .ToListAsync();

            vm.RecentOrders = recentOrders.Select(o => new StaffOrderVM
            {
                Id = o.ID,
                OrderCode = o.OrderCode ?? "",
                CustomerName = o.CustomerName ?? "",
                PhoneNumber = o.PhoneNumber ?? "",
                Address = o.Address ?? "",
                Status = o.Status,
                StatusName = GetStatusName(o.Status),
                PaymentMethod = o.PaymentMethod ?? "cod",
                CreateDate = o.CreateDate,
                Total = _context.OrderDetails
                    .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                    .Sum(od => od.TotalMoney ?? 0)
            }).ToList();

            // Alerts (low stock, payment issues, etc.)
            // TODO: Implement inventory tracking for low stock alerts
            vm.Alerts = new List<StaffAlertVM>();

            // Lấy đơn hàng đầu tiên ở trạng thái "Chờ xác nhận" để có thể link nhanh
            var firstPendingOrder = await _context.Orders
                .Where(o => o.Status == (int)OrderStatus.Pending && (o.IsDeleted == null || o.IsDeleted == false))
                .OrderBy(o => o.CreateDate)
                .FirstOrDefaultAsync();

            ViewBag.FirstPendingOrderId = firstPendingOrder?.ID;

            return View(vm);
        }

        // GET: /Staff/Orders
        [HttpGet("Orders")]
        public async Task<IActionResult> Orders(string? status = null)
        {
            var query = _context.Orders
                .Where(o => (o.IsDeleted == null || o.IsDeleted == false));

            if (!string.IsNullOrEmpty(status))
            {
                var statusInt = status switch
                {
                    "pending" => (int)OrderStatus.Pending,
                    "confirmed" => (int)OrderStatus.Confirmed,
                    "in-progress" => (int)OrderStatus.InProgress,
                    "ready" => (int)OrderStatus.Ready,
                    "delivering" => (int)OrderStatus.Delivering,
                    _ => (int?)null
                };

                if (statusInt.HasValue)
                {
                    query = query.Where(o => o.Status == statusInt.Value);
                }
            }

            var orders = await query
                .OrderByDescending(o => o.CreateDate)
                .ToListAsync();

            var orderVMs = orders.Select(o => {
                var address = o.Address ?? "";
                var isDineIn = address.Contains("Tại quầy", StringComparison.OrdinalIgnoreCase) 
                            || address.Contains("tại quầy", StringComparison.OrdinalIgnoreCase)
                            || address.Trim().ToLower() == "tại quầy";
                
                return new StaffOrderVM
                {
                    Id = o.ID,
                    OrderCode = o.OrderCode ?? "",
                    CustomerName = o.CustomerName ?? "",
                    PhoneNumber = o.PhoneNumber ?? "",
                    Address = address,
                    Status = o.Status,
                    StatusName = GetStatusName(o.Status),
                    PaymentMethod = o.PaymentMethod ?? "cod",
                    CreateDate = o.CreateDate,
                    IsDineIn = isDineIn,
                    OrderTypeName = isDineIn ? "Tại quầy" : "Online",
                    Total = _context.OrderDetails
                        .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                        .Sum(od => od.TotalMoney ?? 0)
                };
            }).ToList();

            ViewBag.StatusFilter = status;
            return View(orderVMs);
        }

        // GET: /Staff/OrderDetail/{id}
        [HttpGet("OrderDetail/{id}")]
        public async Task<IActionResult> OrderDetail(int id)
        {
            var order = await _context.Orders
                .FirstOrDefaultAsync(o => o.ID == id && (o.IsDeleted == null || o.IsDeleted == false));

            if (order == null)
            {
                return NotFound();
            }

            var orderDetails = await _context.OrderDetails
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.Product)
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.ProductSize)
                .Where(od => od.OrderID == id && (od.IsDelete == null || od.IsDelete == false))
                .ToListAsync();

            // Xác định loại đơn hàng: nếu Address = "Tại quầy" thì là DineIn, còn lại là Online/Delivery
            var address = order.Address ?? "";
            var isDineIn = address.Contains("Tại quầy", StringComparison.OrdinalIgnoreCase) 
                        || address.Contains("tại quầy", StringComparison.OrdinalIgnoreCase)
                        || address.Trim().ToLower() == "tại quầy";
            
            var vm = new StaffOrderVM
            {
                Id = order.ID,
                OrderCode = order.OrderCode ?? "",
                CustomerName = order.CustomerName ?? "",
                PhoneNumber = order.PhoneNumber ?? "",
                Address = address,
                Status = order.Status,
                StatusName = GetStatusName(order.Status),
                PaymentMethod = order.PaymentMethod ?? "cod",
                CreateDate = order.CreateDate,
                Total = orderDetails.Sum(od => od.TotalMoney ?? 0),
                IsDineIn = isDineIn,
                OrderTypeName = isDineIn ? "Tại quầy" : "Online",
                Items = orderDetails.Select(od => new StaffOrderDetailVM
                {
                    Id = od.ID,
                    ProductName = od.ProductDetail?.Product?.ProductName ?? "",
                    SizeName = od.ProductDetail?.ProductSize?.SizeName ?? "",
                    Quantity = od.Quantity ?? 0,
                    Price = od.ProductDetail?.Price ?? 0,
                    TotalMoney = od.TotalMoney ?? 0
                }).ToList()
            };

            return View(vm);
        }

        // GET: /Staff/Invoice/{id}
        [HttpGet("Invoice/{id}")]
        public async Task<IActionResult> Invoice(int id)
        {
            var order = await _context.Orders
                .FirstOrDefaultAsync(o => o.ID == id && (o.IsDeleted == null || o.IsDeleted == false));

            if (order == null)
            {
                return NotFound();
            }

            var orderDetails = await _context.OrderDetails
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.Product)
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.ProductSize)
                .Where(od => od.OrderID == id && (od.IsDelete == null || od.IsDelete == false))
                .ToListAsync();

            // Lấy toppings riêng
            var toppings = await _context.OrderDetailsToppings
                .Include(odt => odt.Topping)
                .Where(odt => orderDetails.Select(od => od.ID).Contains(odt.OrderDetailsID))
                .ToListAsync();

            // Tính tổng tiền
            var total = orderDetails.Sum(od => od.TotalMoney ?? 0);

            // Xác định loại đơn hàng
            var address = order.Address ?? "";
            var isDineIn = address.Contains("Tại quầy", StringComparison.OrdinalIgnoreCase) 
                        || address.Contains("tại quầy", StringComparison.OrdinalIgnoreCase)
                        || address.Trim().ToLower() == "tại quầy";

            var vm = new StaffOrderVM
            {
                Id = order.ID,
                OrderCode = order.OrderCode ?? "",
                CustomerName = order.CustomerName ?? "",
                PhoneNumber = order.PhoneNumber ?? "",
                Address = address,
                Status = order.Status,
                StatusName = GetStatusName(order.Status),
                PaymentMethod = order.PaymentMethod ?? "cod",
                CreateDate = order.CreateDate,
                Total = total,
                IsDineIn = isDineIn,
                OrderTypeName = isDineIn ? "Tại quầy" : "Online",
                Items = orderDetails.Select(od => new StaffOrderDetailVM
                {
                    Id = od.ID,
                    ProductName = od.ProductDetailID == null ? "Phí ship" : (od.ProductDetail?.Product?.ProductName ?? ""),
                    SizeName = od.ProductDetailID == null ? "-" : (od.ProductDetail?.ProductSize?.SizeName ?? ""),
                    Quantity = od.Quantity ?? 0,
                    Price = od.ProductDetailID == null ? (od.TotalMoney ?? 0) : (od.ProductDetail?.Price ?? 0),
                    TotalMoney = od.TotalMoney ?? 0,
                    Toppings = toppings
                        .Where(t => t.OrderDetailsID == od.ID && t.Topping != null && !t.Topping.IsDelete)
                        .Select(t => t.Topping!.ToppingName ?? "")
                        .ToList()
                }).ToList()
            };

            return View(vm);
        }

        // GET: /Staff/Kitchen
        [HttpGet("Kitchen")]
        public IActionResult Kitchen()
        {
            return View();
        }

        // GET: /Staff/Delivery
        [HttpGet("Delivery")]
        public async Task<IActionResult> Delivery()
        {
            var orders = await _context.Orders
                .Where(o => (o.Status == (int)OrderStatus.Ready 
                    || o.Status == (int)OrderStatus.Delivering 
                    || o.Status == (int)OrderStatus.Shipping)
                    && (o.IsDeleted == null || o.IsDeleted == false))
                .OrderByDescending(o => o.CreateDate)
                .ToListAsync();

            var deliveryVMs = orders.Select(o => new StaffDeliveryVM
            {
                OrderId = o.ID,
                OrderCode = o.OrderCode ?? "",
                CustomerName = o.CustomerName ?? "",
                PhoneNumber = o.PhoneNumber ?? "",
                Address = o.Address ?? "",
                Status = o.Status,
                CreateDate = o.CreateDate,
                Total = _context.OrderDetails
                    .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                    .Sum(od => od.TotalMoney ?? 0)
            }).ToList();

            return View(deliveryVMs);
        }

        // GET: /Staff/Menu
        [HttpGet("Menu")]
        public IActionResult Menu()
        {
            return View();
        }

        // GET: /Staff/Inventory
        [HttpGet("Inventory")]
        public async Task<IActionResult> Inventory()
        {
            var materials = await _context.Materials
                .Where(m => !m.IsDelete)
                .OrderBy(m => m.MaterialName)
                .ToListAsync();

            var units = await _context.Units.ToListAsync();
            var unitDict = units.ToDictionary(u => u.ID, u => u.UnitName ?? "");

            var inventoryVMs = materials.Select(m => new StaffInventoryVM
            {
                MaterialId = m.ID,
                MaterialCode = m.MaterialCode,
                MaterialName = m.MaterialName ?? "",
                CurrentQuantity = 0, // TODO: Implement inventory tracking
                MinQuantity = m.MinQuantity,
                UnitName = unitDict.ContainsKey(m.UnitID) ? unitDict[m.UnitID] : "",
                IsLowStock = false // TODO: Implement inventory tracking
            }).ToList();

            return View(inventoryVMs);
        }

        // GET: /Staff/Report
        [HttpGet("Report")]
        public IActionResult Report()
        {
            return View();
        }
    }
}

