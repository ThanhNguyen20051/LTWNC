using Microsoft.AspNetCore.Mvc;
using FFoodsStore.Data;
using FFoodsStore.Models;
using FFoodsStore.Models.Dtos;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Hosting;

namespace FFoodsStore.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProfileApiController : ControllerBase
    {
        private readonly StoreDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public ProfileApiController(StoreDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        // ========== LẤY THÔNG TIN PROFILE ==========
        [HttpGet("{accountId}")]
        public async Task<IActionResult> GetProfile(int accountId)
        {
            try
            {
                var account = await _context.Accounts
                    .FirstOrDefaultAsync(x => x.ID == accountId && !x.IsDelete);

                if (account == null)
                {
                    return NotFound("Không tìm thấy tài khoản.");
                }

                return Ok(new
                {
                    id = account.ID,
                    email = account.Email,
                    fullName = account.FullName,
                    phoneNumber = account.PhoneNumber,
                    address = account.Address,
                    avatarUrl = account.AvatarUrl,
                    gender = account.Gender
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[PROFILE] GetProfile error: {ex.Message}");
                return StatusCode(500, $"Lỗi server: {ex.Message}");
            }
        }

        // ========== CẬP NHẬT PROFILE ==========
        [HttpPut("{accountId}")]
        public async Task<IActionResult> UpdateProfile(int accountId, [FromBody] UpdateProfileDto dto)
        {
            try
            {
                if (dto == null)
                {
                    return BadRequest("Dữ liệu không hợp lệ!");
                }

                var account = await _context.Accounts
                    .FirstOrDefaultAsync(x => x.ID == accountId && !x.IsDelete);

                if (account == null)
                {
                    return NotFound("Không tìm thấy tài khoản.");
                }

                // Cập nhật thông tin
                if (!string.IsNullOrWhiteSpace(dto.FullName))
                {
                    account.FullName = dto.FullName.Trim();
                }

                if (!string.IsNullOrWhiteSpace(dto.PhoneNumber))
                {
                    account.PhoneNumber = dto.PhoneNumber.Trim();
                }

                if (dto.Address != null) // Cho phép xóa address (empty string)
                {
                    account.Address = string.IsNullOrWhiteSpace(dto.Address) ? null : dto.Address.Trim();
                }

                if (dto.Gender.HasValue)
                {
                    account.Gender = dto.Gender;
                }

                account.UpdatedDate = DateTime.Now;

                await _context.SaveChangesAsync();

                Console.WriteLine($"[PROFILE] Updated profile for account ID: {accountId}");

                return Ok(new
                {
                    message = "Cập nhật thông tin thành công!",
                    id = account.ID,
                    email = account.Email,
                    fullName = account.FullName,
                    phoneNumber = account.PhoneNumber,
                    address = account.Address,
                    avatarUrl = account.AvatarUrl,
                    gender = account.Gender
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[PROFILE] UpdateProfile error: {ex.Message}");
                return StatusCode(500, $"Lỗi server: {ex.Message}");
            }
        }

        // ========== ĐỔI MẬT KHẨU ==========
        [HttpPost("{accountId}/change-password")]
        public async Task<IActionResult> ChangePassword(int accountId, [FromBody] ChangePasswordDto dto)
        {
            try
            {
                if (dto == null || string.IsNullOrWhiteSpace(dto.OldPassword) || string.IsNullOrWhiteSpace(dto.NewPassword))
                {
                    return BadRequest("Vui lòng điền đầy đủ thông tin!");
                }

                if (dto.NewPassword.Length < 6)
                {
                    return BadRequest("Mật khẩu mới phải có ít nhất 6 ký tự!");
                }

                var account = await _context.Accounts
                    .FirstOrDefaultAsync(x => x.ID == accountId && !x.IsDelete);

                if (account == null)
                {
                    return NotFound("Không tìm thấy tài khoản.");
                }

                // Kiểm tra mật khẩu cũ (plain text)
                if (account.Password != dto.OldPassword)
                {
                    return Unauthorized("Mật khẩu cũ không đúng!");
                }

                // Cập nhật mật khẩu mới (plain text)
                account.Password = dto.NewPassword;
                account.UpdatedDate = DateTime.Now;

                await _context.SaveChangesAsync();

                Console.WriteLine($"[PROFILE] Changed password for account ID: {accountId}");

                return Ok(new
                {
                    message = "Đổi mật khẩu thành công!"
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[PROFILE] ChangePassword error: {ex.Message}");
                return StatusCode(500, $"Lỗi server: {ex.Message}");
            }
        }

        // ========== UPLOAD AVATAR ==========
        [HttpPost("{accountId}/upload-avatar")]
        public async Task<IActionResult> UploadAvatar(int accountId, IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0)
                {
                    return BadRequest("Vui lòng chọn file ảnh!");
                }

                // Kiểm tra file type
                var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
                var fileExtension = Path.GetExtension(file.FileName).ToLowerInvariant();
                
                if (!allowedExtensions.Contains(fileExtension))
                {
                    return BadRequest("Chỉ chấp nhận file ảnh (jpg, jpeg, png, gif, webp)!");
                }

                // Kiểm tra file size (max 5MB)
                if (file.Length > 5 * 1024 * 1024)
                {
                    return BadRequest("File ảnh không được vượt quá 5MB!");
                }

                var account = await _context.Accounts
                    .FirstOrDefaultAsync(x => x.ID == accountId && !x.IsDelete);

                if (account == null)
                {
                    return NotFound("Không tìm thấy tài khoản.");
                }

                // Tạo tên file unique
                var fileName = $"avatar_{accountId}_{DateTime.Now.Ticks}{fileExtension}";
                var uploadsFolder = Path.Combine(_environment.WebRootPath, "images", "avatars");
                
                // Tạo thư mục nếu chưa có
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                var filePath = Path.Combine(uploadsFolder, fileName);

                // Xóa avatar cũ nếu có
                if (!string.IsNullOrEmpty(account.AvatarUrl))
                {
                    var oldFilePath = Path.Combine(_environment.WebRootPath, account.AvatarUrl.TrimStart('/'));
                    if (System.IO.File.Exists(oldFilePath))
                    {
                        try
                        {
                            System.IO.File.Delete(oldFilePath);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"[PROFILE] Error deleting old avatar: {ex.Message}");
                        }
                    }
                }

                // Lưu file mới
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                // Cập nhật AvatarUrl trong database
                account.AvatarUrl = $"/images/avatars/{fileName}";
                account.UpdatedDate = DateTime.Now;
                await _context.SaveChangesAsync();

                Console.WriteLine($"[PROFILE] Uploaded avatar for account ID: {accountId}, Path: {account.AvatarUrl}");

                return Ok(new
                {
                    message = "Cập nhật ảnh đại diện thành công!",
                    avatarUrl = account.AvatarUrl
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[PROFILE] UploadAvatar error: {ex.Message}");
                return StatusCode(500, $"Lỗi server: {ex.Message}");
            }
        }
    }
}

