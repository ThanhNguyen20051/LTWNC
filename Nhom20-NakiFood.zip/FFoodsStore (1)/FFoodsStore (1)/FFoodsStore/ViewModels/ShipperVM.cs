using FFoodsStore.Models;

namespace FFoodsStore.ViewModels
{
    public class ShipperDashboardVM
    {
        public int AssignedOrders { get; set; }
        public int DeliveringOrders { get; set; }
        public int CompletedToday { get; set; }
        public int FailedToday { get; set; }
        public bool IsOnline { get; set; }
        public List<ShipperOrderVM> RecentOrders { get; set; } = new();
        public decimal TodayEarnings { get; set; }
    }

    public class ShipperOrderVM
    {
        public int Id { get; set; }
        public string OrderCode { get; set; } = "";
        public string CustomerName { get; set; } = "";
        public string PhoneNumber { get; set; } = "";
        public string Address { get; set; } = "";
        public string? Notes { get; set; }
        public int? Status { get; set; }
        public string StatusName { get; set; } = "";
        public string PaymentMethod { get; set; } = "";
        public bool IsPaid { get; set; }
        public decimal Total { get; set; }
        public decimal? CodAmount { get; set; } // Số tiền cần thu nếu COD
        public DateTime? CreateDate { get; set; }
        public DateTime? ReadyTime { get; set; } // Thời gian sẵn sàng
        public DateTime? Deadline { get; set; } // Deadline giao hàng
        public List<ShipperOrderDetailVM> Items { get; set; } = new();
        public string StoreAddress { get; set; } = ""; // Địa chỉ cửa hàng
        public string StorePhone { get; set; } = ""; // SĐT cửa hàng
    }

    public class ShipperOrderDetailVM
    {
        public int Id { get; set; }
        public string ProductName { get; set; } = "";
        public string SizeName { get; set; } = "";
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public decimal TotalMoney { get; set; }
    }

    public class ShipperHistoryVM
    {
        public int OrderId { get; set; }
        public string OrderCode { get; set; } = "";
        public string CustomerName { get; set; } = "";
        public string Address { get; set; } = "";
        public int? Status { get; set; }
        public string StatusName { get; set; } = "";
        public decimal Total { get; set; }
        public DateTime? CreateDate { get; set; }
        public DateTime? CompletedDate { get; set; }
        public string? FailureReason { get; set; }
    }

    public class ShipperEarningsVM
    {
        public int TotalOrdersToday { get; set; }
        public int TotalOrdersThisWeek { get; set; }
        public int TotalOrdersThisMonth { get; set; }
        public decimal EarningsToday { get; set; }
        public decimal EarningsThisWeek { get; set; }
        public decimal EarningsThisMonth { get; set; }
        public decimal TotalKmToday { get; set; }
        public decimal TotalKmThisWeek { get; set; }
        public decimal TotalKmThisMonth { get; set; }
        public List<ShipperEarningDetailVM> OrderHistory { get; set; } = new();
    }

    public class ShipperEarningDetailVM
    {
        public int OrderId { get; set; }
        public string OrderCode { get; set; } = "";
        public string CustomerName { get; set; } = "";
        public string Address { get; set; } = "";
        public decimal ShippingFee { get; set; }
        public decimal EstimatedKm { get; set; }
        public DateTime? DeliveryDate { get; set; }
        public string StatusName { get; set; } = "";
    }
}

