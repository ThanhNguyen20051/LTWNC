// ============================================
// ONBOARDING.JS - Safe Implementation
// ============================================

(function() {
    'use strict';

    // ============================================
    // Create Onboarding Frame
    // ============================================
    async function createOnboardingFrame() {
        try {
            // Ensure document.body exists
            if (!document.body) {
                console.warn('[ONBOARDING] document.body not available, retrying...');
                await new Promise(resolve => {
                    if (document.body) {
                        resolve();
                    } else {
                        document.addEventListener('DOMContentLoaded', resolve, { once: true });
                        // Fallback timeout
                        setTimeout(resolve, 1000);
                    }
                });
            }

            // Check if onboarding container already exists
            let container = document.getElementById('onboardingContainer');
            if (container) {
                console.log('[ONBOARDING] Container already exists');
                return container;
            }

            // Create container element
            container = document.createElement('div');
            container.id = 'onboardingContainer';
            container.style.cssText = 'position: fixed; top: 0; left: 0; width: 100%; height: 100%; z-index: 9998; pointer-events: none;';
            container.setAttribute('aria-hidden', 'true');

            // Ensure body exists before appending
            if (document.body) {
                document.body.appendChild(container);
                console.log('[ONBOARDING] Container created and appended');
            } else {
                console.error('[ONBOARDING] Cannot append container: document.body is null');
                return null;
            }

            return container;
        } catch (error) {
            console.error('[ONBOARDING] Error in createOnboardingFrame:', error);
            return null;
        }
    }

    // ============================================
    // Initialize Onboarding
    // ============================================
    async function initOnboarding() {
        try {
            // Wait for DOM to be ready
            if (document.readyState === 'loading') {
                await new Promise(resolve => {
                    document.addEventListener('DOMContentLoaded', resolve, { once: true });
                    // Fallback timeout
                    setTimeout(resolve, 2000);
                });
            }

            // Check if onboarding should run
            const skipOnboarding = sessionStorage.getItem('onboardingSkipped') === 'true';
            if (skipOnboarding) {
                console.log('[ONBOARDING] Skipped (user preference)');
                return;
            }

            // Create frame
            const frame = await createOnboardingFrame();
            if (!frame) {
                console.warn('[ONBOARDING] Failed to create frame, skipping initialization');
                return;
            }

            // Onboarding initialized successfully
            console.log('[ONBOARDING] Onboarding initialized OK');
        } catch (error) {
            console.error('[ONBOARDING] Error in initOnboarding:', error);
        }
    }

    // ============================================
    // Auto-initialize when DOM is ready
    // ============================================
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => {
            setTimeout(initOnboarding, 500);
        });
    } else {
        setTimeout(initOnboarding, 500);
    }

    // ============================================
    // Export functions (if needed by other scripts)
    // ============================================
    window.Onboarding = {
        createOnboardingFrame: createOnboardingFrame,
        initOnboarding: initOnboarding
    };

    // Debug log
    console.log('Onboarding initialized OK');

})();

