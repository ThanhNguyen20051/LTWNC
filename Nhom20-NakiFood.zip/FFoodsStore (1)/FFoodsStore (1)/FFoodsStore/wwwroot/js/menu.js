// ===============================
// Biến toàn cục cho pagination và filter
// ===============================
let currentPage = 1;
let currentCategory = 'all';
let currentSearch = '';
let totalPages = 1;
let pageSize = 12; // Số món mỗi trang
let searchTimeout = null;

// ===============================
// Format giá tiền VND
// ===============================
function formatVND(price) {
  return price.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// ===============================
// Escape HTML để tránh XSS
// ===============================
function escapeHtml(text) {
  if (!text) return '';
  const map = {
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#039;'
  };
  return text.replace(/[&<>"']/g, m => map[m]);
}

// ===============================
// Load menu items từ API với pagination
// ===============================
async function loadMenuItemsFromAPI() {
  const container = document.getElementById('menuContent');
  const loading = document.getElementById('menuLoading');
  if (!container) return;

  // Show Ratatouille loader (center screen)
  if (window.showRatatouilleLoader) {
    window.showRatatouilleLoader('Đang tải thực đơn...');
  } else if (loading) {
    loading.style.display = 'block';
    container.style.opacity = '0.5';
  }

  try {
    const params = new URLSearchParams({
      page: currentPage.toString(),
      pageSize: pageSize.toString()
    });

    if (currentCategory && currentCategory !== 'all') {
      params.append('cat', currentCategory);
    }

    if (currentSearch && currentSearch.trim()) {
      params.append('q', currentSearch.trim());
    }

    const res = await fetch(`/api/menu/items?${params.toString()}`);
    if (!res.ok) throw new Error('Không thể tải menu items');
    const data = await res.json();
    
    // Hide Ratatouille loader sau khi load thành công
    if (window.hideRatatouilleLoader) {
      window.hideRatatouilleLoader();
    }

    totalPages = data.totalPages || 1;
    currentPage = data.page || 1;

    // Render menu items
    if (!data.items || data.items.length === 0) {
      // Đảm bảo loader đã được ẩn
      if (window.hideRatatouilleLoader) {
        window.hideRatatouilleLoader();
      }
      container.innerHTML = '<p>Không tìm thấy món nào.</p>';
      if (loading) loading.style.display = 'none';
      container.style.opacity = '1';
      updatePagination();
      return;
    }

    // Nếu đang filter category hoặc search, hiển thị tất cả items trong 1 grid
    // Nếu không filter (all), group theo category
    let html = '';
    
    if (currentCategory !== 'all' || currentSearch.trim()) {
      // Đang filter/search -> hiển thị tất cả trong 1 grid
      html += '<div class="menu">';
      data.items.forEach(item => {
        html += `
          <div class="card" data-id="${item.productId}" data-cat="${item.typeSlug || 'other'}" 
               data-action="view-product" data-product-id="${item.productId}"
               style="cursor: pointer;">
            <div class="food-img-wrapper">
              <img class="food-img" src="${item.imageUrl || ''}" alt="${item.name || ''}"
                onerror="this.src='https://picsum.photos/seed/${item.productId}/640/420'" />
            </div>
            <div class="card-content">
              <span class="type-badge">${escapeHtml(item.typeName || 'Khác')}</span>
              <h3>${escapeHtml(item.name || '')}</h3>
              <p class="price">${formatVND(item.price || 0)}</p>
              <button class="btn-add btn-add-cart" data-action="add-to-cart" 
                      data-product-id="${item.productId}" 
                      data-product-detail-id="${item.productDetailId || 0}"
                      onclick="event.stopPropagation();">
                <span>🛒 Thêm vào giỏ</span>
              </button>
              <button class="btn-buy btn-buy-now" data-action="buy-now" 
                      data-product-id="${item.productId}"
                      data-product-detail-id="${item.productDetailId || 0}"
                      onclick="event.stopPropagation();">
                <span>⚡ Mua ngay</span>
              </button>
            </div>
          </div>
        `;
      });
      html += '</div>';
    } else {
      // Không filter -> group theo category
      const grouped = {};
      data.items.forEach(item => {
        const key = item.typeSlug || 'other';
        if (!grouped[key]) {
          grouped[key] = {
            name: item.typeName || 'Khác',
            slug: key,
            items: []
          };
        }
        grouped[key].items.push(item);
      });

      Object.values(grouped).forEach(group => {
        html += `<section class="category" data-cat="${group.slug}">`;
        html += `<div class="category-header">`;
        html += `<h2 class="category-title">${escapeHtml(group.name || 'Khác')}</h2>`;
        html += `<div class="category-divider"></div>`;
        html += `</div>`;
        html += '<div class="menu">';
        
      group.items.forEach(item => {
        html += `
          <div class="card" data-id="${item.productId}" data-cat="${group.slug}"
               data-action="view-product" data-product-id="${item.productId}"
               style="cursor: pointer;">
            <div class="food-img-wrapper">
              <img class="food-img" src="${item.imageUrl || ''}" alt="${item.name || ''}"
                onerror="this.src='https://picsum.photos/seed/${item.productId}/640/420'" />
            </div>
            <div class="card-content">
              <span class="type-badge">${escapeHtml(group.name || 'Khác')}</span>
              <h3>${escapeHtml(item.name || '')}</h3>
              <p class="price">${formatVND(item.price || 0)}</p>
              <button class="btn-add btn-add-cart" data-action="add-to-cart" 
                      data-product-id="${item.productId}"
                      data-product-detail-id="${item.productDetailId || 0}"
                      onclick="event.stopPropagation();">
                <span>🛒 Thêm vào giỏ</span>
              </button>
              <button class="btn-buy btn-buy-now" data-action="buy-now" 
                      data-product-id="${item.productId}"
                      data-product-detail-id="${item.productDetailId || 0}"
                      onclick="event.stopPropagation();">
                <span>⚡ Mua ngay</span>
              </button>
            </div>
          </div>
        `;
      });
        
        html += '</div></section>';
      });
    }

    container.innerHTML = html;
    
    // Đảm bảo loader đã được ẩn sau khi render xong
    if (window.hideRatatouilleLoader) {
      window.hideRatatouilleLoader();
    }
    
    if (loading) loading.style.display = 'none';
    container.style.opacity = '1';

    // Update pagination
    updatePagination();

  } catch (err) {
    console.error('Lỗi load menu items:', err);
    // Hide Ratatouille loader on error
    if (window.hideRatatouilleLoader) {
      window.hideRatatouilleLoader();
    }
    container.innerHTML = '<p style="color: red;">Có lỗi xảy ra khi tải dữ liệu.</p>';
    if (loading) loading.style.display = 'none';
    container.style.opacity = '1';
  }
}

// ===============================
// Update pagination UI
// ===============================
function updatePagination() {
  const pagination = document.getElementById('paginationContainer');
  const pageInfo = document.getElementById('pageInfo');
  const prevBtn = document.getElementById('prevPage');
  const nextBtn = document.getElementById('nextPage');

  if (!pagination || !pageInfo || !prevBtn || !nextBtn) return;

  // Hiện pagination khi có nhiều hơn 1 trang
  if (totalPages <= 1) {
    pagination.style.display = 'none';
    return;
  }

  pagination.style.display = 'flex';
  pageInfo.textContent = `Trang ${currentPage} / ${totalPages}`;
  prevBtn.disabled = currentPage <= 1;
  nextBtn.disabled = currentPage >= totalPages;
}

// ===============================
// Change page
// ===============================
function changePage(delta) {
  const newPage = currentPage + delta;
  if (newPage >= 1 && newPage <= totalPages) {
    currentPage = newPage;
    loadMenuItemsFromAPI();
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}

// ===============================
// Filter theo category - Luôn dùng API
// ===============================
function filterCategory(cat, btn) {
  document.querySelectorAll('.tabs button').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');

  currentCategory = cat || 'all';
  currentPage = 1; // Reset về trang đầu khi filter
  
  // Clear search box khi filter category
  const box = document.getElementById('searchBox');
  if (box) {
    box.value = '';
    currentSearch = '';
  }
  
  // Luôn dùng API để filter
  loadMenuItemsFromAPI();
}

// ===============================
// Search menu items - Luôn dùng API
// ===============================
function filterMenu() {
  const q = (document.getElementById('searchBox')?.value || '').trim();
  
  // Debounce search để tránh gọi API quá nhiều
  clearTimeout(searchTimeout);
  
  searchTimeout = setTimeout(() => {
    currentSearch = q;
    currentPage = 1; // Reset về trang đầu khi search
    
    // Reset category khi search
    if (q) {
      currentCategory = 'all';
      // Clear active category khi search
      document.querySelectorAll('.tabs button').forEach(b => b.classList.remove('active'));
      const allBtn = document.querySelector('.tabs button');
      if (allBtn && allBtn.textContent.trim() === 'Tất cả') {
        allBtn.classList.add('active');
      }
    }

    // Luôn dùng API để search
    loadMenuItemsFromAPI();
  }, 500); // Đợi 500ms sau khi user ngừng gõ
}

// ===============================
// Mở modal chi tiết món ăn
// ===============================
async function openProductModal(productId, buyNowMode = false) {
  const modal = document.getElementById('productModal');
  const modalBody = document.getElementById('productModalBody');
  
  if (!modal || !modalBody) return;

  // Lưu buyNowMode vào modal để dùng sau
  modal.dataset.buyNowMode = buyNowMode ? 'true' : 'false';

  // Hiện modal
  modal.classList.add('active');
  
  // Show Ratatouille loader (center screen)
  if (window.showRatatouilleLoader) {
    window.showRatatouilleLoader('Đang tải thông tin sản phẩm...');
  } else if (window.showCompactPageLoader) {
    window.showCompactPageLoader('Đang tải thông tin sản phẩm...');
  } else {
    modalBody.innerHTML = '<div class="loading">Đang tải...</div>';
  }

  try {
    // Load chi tiết sản phẩm từ API
    const res = await fetch(`/api/product/${productId}`);
    if (!res.ok) throw new Error('Không thể tải chi tiết sản phẩm');
    const product = await res.json();

    // Hide Ratatouille loader
    if (window.hideRatatouilleLoader) {
      window.hideRatatouilleLoader();
    } else if (window.hideCompactPageLoader) {
      window.hideCompactPageLoader();
    }
    
    // Render modal content
    let sizeOptions = '';
    let defaultPrice = 0;
    let defaultProductDetailId = null;

    if (product.productDetails && product.productDetails.length > 0) {
      product.productDetails.forEach((detail, index) => {
        if (index === 0) {
          defaultPrice = detail.price;
          defaultProductDetailId = detail.id;
        }
        sizeOptions += `<option value="${detail.id}" data-price="${detail.price}">${detail.sizeName} - ${formatVND(detail.price)}</option>`;
      });
    }

    // Hide compact loader before rendering
    if (window.hideCompactPageLoader) {
      window.hideCompactPageLoader();
    }
    
    modalBody.innerHTML = `
      <div class="product-modal-image">
        <img src="${product.imageUrl || ''}" alt="${product.name || ''}" 
             onerror="this.src='https://picsum.photos/seed/${product.id}/640/420'" />
      </div>
      <div class="product-modal-info">
        <h3>${product.name || ''}</h3>
        <p class="product-modal-type">Phân loại: ${product.typeName || 'Khác'}</p>
        <p class="product-modal-desc">${product.description || 'Món ăn đặc trưng, mang hương vị đậm đà của cửa hàng chúng tôi.'}</p>
        <ul class="product-modal-meta">
          <li><b>Nguyên liệu:</b> ${product.ingredients || 'Đang cập nhật...'}</li>
          <li><b>Hương vị:</b> ${product.flavor || 'Hấp dẫn, thơm ngon khó cưỡng'}</li>
        </ul>
        <div class="product-modal-size">
          <label for="modalSizeSelect">Chọn size:</label>
          <select id="modalSizeSelect" data-action="update-modal-price">
            ${sizeOptions || '<option value="">Không có size</option>'}
          </select>
        </div>
        <div class="product-modal-price" id="modalPrice">${formatVND(defaultPrice)}</div>
        <div class="product-modal-actions">
          <button class="btn-modal-add" id="btnModalAction" 
                  data-action="${buyNowMode ? 'buy-now-modal' : 'add-to-cart-modal'}" 
                  data-product-id="${product.id}">
            ${buyNowMode ? '⚡ Mua ngay' : '🛒 Thêm vào giỏ'}
          </button>
          <button class="btn-modal-cancel" data-action="close-modal">Hủy</button>
        </div>
      </div>
    `;
    
    // Thêm event listeners trực tiếp vào buttons trong modal sau khi render
    setTimeout(() => {
      const actionBtn = document.getElementById('btnModalAction');
      const cancelBtn = modalBody.querySelector('[data-action="close-modal"]');
      const sizeSelect = document.getElementById('modalSizeSelect');
      
      // Event listener cho button action (Thêm vào giỏ / Mua ngay)
      if (actionBtn) {
        actionBtn.addEventListener('click', function(e) {
          e.preventDefault();
          e.stopPropagation();
          const action = this.getAttribute('data-action');
          const productId = parseInt(this.getAttribute('data-product-id') || '0');
          
          // ✅ FIX: Get productDetailId from the selected size dropdown (not from attribute)
          const sizeSelect = document.getElementById('modalSizeSelect');
          const productDetailId = sizeSelect ? parseInt(sizeSelect.value) : null;
          
          console.log('Modal action button clicked directly:', { action, productId, productDetailId, sizeSelectValue: sizeSelect?.value });
          
          if (action === 'add-to-cart-modal') {
            if (productId && productDetailId && !isNaN(productDetailId)) {
              addToCartFromModal(productId, productDetailId);
            } else {
              const msg = "Vui lòng chọn size trước!";
              console.error('Missing productDetailId:', { productId, productDetailId, sizeSelectValue: sizeSelect?.value });
              if (typeof showCartNotification === 'function') {
                showCartNotification(msg, true);
              } else {
                alert(msg);
              }
            }
          } else if (action === 'buy-now-modal') {
            if (productId && productDetailId && !isNaN(productDetailId)) {
              buyNowFromModal(productId, productDetailId);
            } else {
              const msg = "Vui lòng chọn size trước!";
              console.error('Missing productDetailId:', { productId, productDetailId, sizeSelectValue: sizeSelect?.value });
              if (typeof showCartNotification === 'function') {
                showCartNotification(msg, true);
              } else {
                alert(msg);
              }
            }
          }
        });
      }
      
      // Event listener cho button cancel
      if (cancelBtn) {
        cancelBtn.addEventListener('click', function(e) {
          e.preventDefault();
          e.stopPropagation();
          closeProductModal();
        });
      }
      
      // Event listener cho select size
      if (sizeSelect) {
        // ✅ FIX: Set default selected value to first product detail
        if (sizeSelect.options.length > 0 && defaultProductDetailId) {
          sizeSelect.value = defaultProductDetailId.toString();
          console.log('✅ Set default size:', { defaultProductDetailId, selectValue: sizeSelect.value });
        }
        
        sizeSelect.addEventListener('change', function(e) {
          updateModalPrice(this);
        });
        
        // Trigger initial price update
        if (sizeSelect.options.length > 0) {
          updateModalPrice(sizeSelect);
        }
      }
    }, 100);
  } catch (err) {
    console.error('Lỗi load chi tiết sản phẩm:', err);
    // Hide Ratatouille loader on error
    if (window.hideRatatouilleLoader) {
      window.hideRatatouilleLoader();
    } else if (window.hideCompactPageLoader) {
      window.hideCompactPageLoader();
    }
    modalBody.innerHTML = '<p style="color: red; padding: 20px;">Có lỗi xảy ra khi tải chi tiết sản phẩm.</p>';
  }
}

// ===============================
// Đóng modal chi tiết món ăn
// ===============================
function closeProductModal() {
  const modal = document.getElementById('productModal');
  if (modal) {
    modal.classList.remove('active');
  }
}

// ===============================
// Xử lý click outside modal để đóng
// ===============================
function handleModalClick(event) {
  if (event.target.id === 'productModal') {
    closeProductModal();
  }
}

// ===============================
// Đóng modal bằng phím ESC
// ===============================
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeProductModal();
  }
});

// ===============================
// Cập nhật giá khi chọn size
// ===============================
function updateModalPrice(selectElement) {
  const selectedOption = selectElement.options[selectElement.selectedIndex];
  const price = parseFloat(selectedOption.getAttribute('data-price')) || 0;
  const priceElement = document.getElementById('modalPrice');
  if (priceElement) {
    priceElement.textContent = formatVND(price);
  }
  
  // Cập nhật productDetailId trong nút action (thêm vào giỏ hoặc mua ngay)
  const actionBtn = document.getElementById('btnModalAction');
  if (actionBtn) {
    const productId = actionBtn.getAttribute('data-product-id');
    const productDetailId = selectElement.value;
    actionBtn.setAttribute('data-product-detail-id', productDetailId);
  }
}

// ===============================
// Gọi API thêm sản phẩm vào giỏ hàng từ modal
// ===============================
async function addToCartFromModal(productId, productDetailId) {
  console.log('✅ addToCartFromModal called:', { productId, productDetailId });
  
  if (!productDetailId || isNaN(productDetailId) || productDetailId <= 0) {
    const msg = "Vui lòng chọn size trước!";
    console.error('Invalid productDetailId:', productDetailId);
    if (typeof showCartNotification === 'function') {
      showCartNotification(msg, true);
    } else {
      alert(msg);
    }
    return;
  }

  // Lấy account ID từ auth.js
  const accountId = window.getCurrentAccountId ? window.getCurrentAccountId() : null;
  console.log('Account ID:', accountId);
  
  if (!accountId) {
    alert('Vui lòng đăng nhập để thêm sản phẩm vào giỏ hàng!');
    window.location.href = '/AccountView/Login';
    return;
  }
  
  const addBtn = document.getElementById('btnModalAction');
  console.log('Add button:', addBtn);

  try {
    // Show button loading
    if (addBtn && window.showButtonLoading) {
      window.showButtonLoading(addBtn, 'Đang thêm...');
    }

    const res = await fetch("/api/cart/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ accountId, productDetailId })
    });

    if (!res.ok) {
      const errorText = await res.text();
      console.error('API error response:', { status: res.status, statusText: res.statusText, errorText });
      throw new Error(errorText || `API lỗi: ${res.status} ${res.statusText}`);
    }
    
    const data = await res.json();
    console.log('✅ Add to cart success:', data);

    // 🛒 Cập nhật số lượng trên icon giỏ hàng
    if (typeof loadCartCount === 'function') {
      await loadCartCount();
    }
    if (typeof refreshCartBadge === 'function') {
      refreshCartBadge();
    }

    // Hiển thị thông báo thành công
    if (typeof showCartNotification === 'function') {
      showCartNotification("✅ Đã thêm món vào giỏ hàng!");
    } else {
      alert("✅ Đã thêm món vào giỏ hàng!");
    }

    // Đóng modal sau khi thêm thành công
    setTimeout(() => {
      closeProductModal();
    }, 1000);
  } catch (err) {
    console.error('❌ Error in addToCartFromModal:', err);
    const errorMsg = err.message || "Không thể thêm vào giỏ hàng!";
    if (typeof showCartNotification === 'function') {
      showCartNotification(errorMsg, true);
    } else {
      alert(errorMsg);
    }
  } finally {
    // Hide button loading
    if (addBtn && window.hideButtonLoading) {
      window.hideButtonLoading(addBtn);
    }
  }
}

// ===============================
// Mua ngay từ modal - thêm vào giỏ và chuyển đến checkout
// ===============================
async function buyNowFromModal(productId, productDetailId) {
  console.log('✅ buyNowFromModal called:', { productId, productDetailId });
  
  if (!productDetailId || isNaN(productDetailId) || productDetailId <= 0) {
    const msg = "Vui lòng chọn size trước!";
    console.error('Invalid productDetailId:', productDetailId);
    if (typeof showCartNotification === 'function') {
      showCartNotification(msg, true);
    } else {
      alert(msg);
    }
    return;
  }

  // Lấy account ID từ auth.js
  const accountId = window.getCurrentAccountId ? window.getCurrentAccountId() : null;
  console.log('Account ID:', accountId);
  
  if (!accountId) {
    alert('Vui lòng đăng nhập để mua hàng!');
    window.location.href = '/AccountView/Login';
    return;
  }
  
  const buyBtn = document.getElementById('btnModalAction');
  console.log('Buy button:', buyBtn);

  try {
    // Show button loading
    if (buyBtn && window.showButtonLoading) {
      window.showButtonLoading(buyBtn, 'Đang xử lý...');
    }

    // Thêm sản phẩm vào giỏ hàng
    const res = await fetch("/api/cart/add", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ accountId, productDetailId })
    });

    if (!res.ok) {
      const errorText = await res.text();
      console.error('API error response:', { status: res.status, statusText: res.statusText, errorText });
      throw new Error(errorText || `API lỗi: ${res.status} ${res.statusText}`);
    }
    
    const data = await res.json();
    console.log('✅ Buy now - Add to cart success:', data);

    // 🛒 Cập nhật số lượng trên icon giỏ hàng
    if (typeof loadCartCount === 'function') {
      await loadCartCount();
    }
    if (typeof refreshCartBadge === 'function') {
      refreshCartBadge();
    }

    // Đóng modal
    closeProductModal();

    // Hiển thị thông báo ngắn
    if (typeof showCartNotification === 'function') {
      showCartNotification("✅ Đã thêm vào giỏ hàng!");
    } else {
      alert("✅ Đã thêm vào giỏ hàng!");
    }

    // ✅ FIX: Chuyển đến trang checkout sau khi thêm vào giỏ
    setTimeout(() => {
      window.location.href = '/Checkout';
    }, 500);
  } catch (err) {
    console.error('❌ Error in buyNowFromModal:', err);
    const errorMsg = err.message || "Không thể thêm vào giỏ hàng!";
    if (typeof showCartNotification === 'function') {
      showCartNotification(errorMsg, true);
    } else {
      alert(errorMsg);
    }
  } finally {
    // Hide button loading
    if (buyBtn && window.hideButtonLoading) {
      window.hideButtonLoading(buyBtn);
    }
  }
}

// ===============================
// Gọi API thêm sản phẩm vào giỏ hàng (mở modal thay vì thêm trực tiếp)
// ===============================
async function addToCart(productId) {
  console.log('✅ addToCart called:', { productId });
  
  if (!productId || productId <= 0) {
    console.error('Invalid productId:', productId);
    const msg = "Lỗi: Không tìm thấy sản phẩm!";
    if (typeof showCartNotification === 'function') {
      showCartNotification(msg, true);
    } else {
      alert(msg);
    }
    return;
  }
  
  // Mở modal chi tiết món ăn để chọn size
  await openProductModal(productId, false);
}

// ===============================
// Thông báo nhỏ khi thêm vào giỏ
// ===============================
function showCartNotification(message, isError = false) {
  let note = document.createElement("div");
  note.className = "cart-toast";
  note.innerText = message;
  Object.assign(note.style, {
    position: "fixed",
    bottom: "20px",
    right: "20px",
    padding: "10px 18px",
    borderRadius: "10px",
    background: isError ? "#dc3545" : "#28a745",
    color: "#fff",
    fontSize: "14px",
    boxShadow: "0 3px 10px rgba(0,0,0,0.2)",
    zIndex: 9999
  });
  document.body.appendChild(note);
  setTimeout(() => note.remove(), 2000);
}

// ===============================
// Load categories từ API
// ===============================
async function loadCategories() {
  try {
    const res = await fetch('/api/menu/categories');
    if (!res.ok) throw new Error('Không thể tải categories');
    const data = await res.json();
    
    const tabsContainer = document.getElementById('categoryTabs');
    if (!tabsContainer) return;

    // Giữ lại nút "Tất cả"
    tabsContainer.innerHTML = '<button class="active" data-action="filter-category" data-category="all"><span>Tất cả</span></button>';

    // Thêm các category buttons từ API
    if (data.categories && data.categories.length > 0) {
      data.categories.forEach(cat => {
        const btn = document.createElement('button');
        btn.textContent = cat.name;
        btn.setAttribute('data-action', 'filter-category');
        btn.setAttribute('data-category', cat.slug);
        tabsContainer.appendChild(btn);
      });
    }
  } catch (err) {
    console.error('Lỗi load categories:', err);
  }
}

// ===============================
// Load cart count từ API
// ===============================
async function loadCartCount() {
  try {
    const accountId = window.getCurrentAccountId ? window.getCurrentAccountId() : null;
    if (!accountId) {
      // Không login thì count = 0
      const countEl = document.getElementById('cartCount');
      if (countEl) countEl.textContent = '0';
      return;
    }
    const res = await fetch(`/api/cart/by-account/${accountId}`);
    if (!res.ok) throw new Error('Không thể tải cart count');
    const data = await res.json();
    
    const countEl = document.getElementById('cartCount');
    if (countEl) {
      countEl.textContent = data.count || 0;
    }
  } catch (err) {
    console.error('Lỗi load cart count:', err);
  }
}

// ===============================
// Handler cho nút Mua ngay
// ===============================
function buyNow(productId) {
  console.log('✅ buyNow called:', { productId });
  
  if (!productId || productId <= 0) {
    console.error('Invalid productId:', productId);
    const msg = "Lỗi: Không tìm thấy sản phẩm!";
    if (typeof showCartNotification === 'function') {
      showCartNotification(msg, true);
    } else {
      alert(msg);
    }
    return;
  }
  
  const accountId = window.getCurrentAccountId ? window.getCurrentAccountId() : null;
  if (!accountId) {
    alert('Vui lòng đăng nhập để mua hàng!');
    window.location.href = '/AccountView/Login?returnUrl=' + encodeURIComponent(window.location.pathname);
    return;
  }

  // Mở modal chọn size với mode "buyNow" (sẽ redirect đến checkout sau khi chọn)
  openProductModal(productId, true);
}

// ===============================
// Initialize khi page load
// ===============================
// ===============================
// Setup Event Delegation
// ===============================
function setupMenuEventListeners() {
  // Search box input event
  const searchBox = document.getElementById('searchBox');
  if (searchBox) {
    searchBox.addEventListener('input', filterMenu);
    searchBox.addEventListener('keyup', filterMenu);
  }

  // Event delegation cho buttons và modal
  document.addEventListener('click', function(e) {
    // Tìm element có data-action, có thể là chính element hoặc parent
    let target = e.target;
    
    // Nếu click vào text/emoji bên trong button, tìm button parent
    while (target && target !== document.body) {
      if (target.hasAttribute && target.hasAttribute('data-action')) {
        break;
      }
      target = target.parentElement;
    }
    
    if (!target || !target.hasAttribute || !target.hasAttribute('data-action')) return;

    const action = target.getAttribute('data-action');
    console.log('Menu event delegation - Action:', action, 'Target:', target);
    
    // Prevent default nếu là button
    if (target.tagName === 'BUTTON' || target.tagName === 'A') {
      e.preventDefault();
      e.stopPropagation();
    }

    switch(action) {
      case 'view-product': {
        // Navigate to product detail page - standardize to /Product/Details/{id}
        const productId = parseInt(target.getAttribute('data-product-id') || '0');
        if (productId) {
          window.location.href = `/Product/Details/${productId}`;
        }
        break;
      }
      case 'filter-category': {
        const category = target.getAttribute('data-category') || 'all';
        filterCategory(category, target);
        break;
      }
      case 'change-page': {
        const delta = parseInt(target.getAttribute('data-delta') || '0');
        changePage(delta);
        break;
      }
      case 'add-to-cart': {
        e.preventDefault();
        e.stopPropagation();
        const productId = parseInt(target.getAttribute('data-product-id') || '0');
        console.log('✅ Add to cart clicked:', { productId, target });
        if (productId && productId > 0) {
          addToCart(productId);
        } else {
          console.error('Invalid productId:', productId);
          if (typeof showCartNotification === 'function') {
            showCartNotification("Lỗi: Không tìm thấy sản phẩm!", true);
          } else {
            alert("Lỗi: Không tìm thấy sản phẩm!");
          }
        }
        break;
      }
      case 'buy-now': {
        e.preventDefault();
        e.stopPropagation();
        const productId = parseInt(target.getAttribute('data-product-id') || '0');
        console.log('✅ Buy now clicked:', { productId, target });
        if (productId && productId > 0) {
          buyNow(productId);
        } else {
          console.error('Invalid productId:', productId);
          if (typeof showCartNotification === 'function') {
            showCartNotification("Lỗi: Không tìm thấy sản phẩm!", true);
          } else {
            alert("Lỗi: Không tìm thấy sản phẩm!");
          }
        }
        break;
      }
      case 'add-to-cart-modal': {
        e.preventDefault();
        e.stopPropagation();
        const productId = parseInt(target.getAttribute('data-product-id') || '0');
        // ✅ FIX: Get productDetailId from the selected size dropdown
        const sizeSelect = document.getElementById('modalSizeSelect');
        const productDetailId = sizeSelect ? parseInt(sizeSelect.value) : null;
        console.log('Add to cart modal clicked:', { productId, productDetailId, sizeSelectValue: sizeSelect?.value, target });
        if (productId && productDetailId && !isNaN(productDetailId)) {
          addToCartFromModal(productId, productDetailId);
        } else {
          const msg = "Vui lòng chọn size trước!";
          console.error('Missing productDetailId:', { productId, productDetailId, sizeSelectValue: sizeSelect?.value });
          if (typeof showCartNotification === 'function') {
            showCartNotification(msg, true);
          } else {
            alert(msg);
          }
        }
        break;
      }
      case 'buy-now-modal': {
        e.preventDefault();
        e.stopPropagation();
        const productId = parseInt(target.getAttribute('data-product-id') || '0');
        // ✅ FIX: Get productDetailId from the selected size dropdown
        const sizeSelect = document.getElementById('modalSizeSelect');
        const productDetailId = sizeSelect ? parseInt(sizeSelect.value) : null;
        console.log('Buy now modal clicked:', { productId, productDetailId, sizeSelectValue: sizeSelect?.value, target });
        if (productId && productDetailId && !isNaN(productDetailId)) {
          buyNowFromModal(productId, productDetailId);
        } else {
          const msg = "Vui lòng chọn size trước!";
          console.error('Missing productDetailId:', { productId, productDetailId, sizeSelectValue: sizeSelect?.value });
          if (typeof showCartNotification === 'function') {
            showCartNotification(msg, true);
          } else {
            alert(msg);
          }
        }
        break;
      }
      case 'close-modal': {
        closeProductModal();
        break;
      }
    }
  });

  // Event delegation cho select size trong modal
  document.addEventListener('change', function(e) {
    const target = e.target;
    if (target && target.id === 'modalSizeSelect') {
      updateModalPrice(target);
    }
  });
}

// Export functions để có thể gọi từ HTML và các file khác
window.showCartNotification = showCartNotification;
window.loadCartCount = loadCartCount;
window.addToCart = addToCart;
window.buyNow = buyNow;
window.addToCartFromModal = addToCartFromModal;
window.buyNowFromModal = buyNowFromModal;
window.openProductModal = openProductModal;
window.closeProductModal = closeProductModal;
window.updateModalPrice = updateModalPrice;

document.addEventListener('DOMContentLoaded', () => {
  // Setup event listeners
  setupMenuEventListeners();
  // Load categories từ API
  loadCategories();
  
  // Load cart count từ API
  loadCartCount();
  
  // Load dữ liệu menu từ API ngay khi page load
  loadMenuItemsFromAPI();
});
