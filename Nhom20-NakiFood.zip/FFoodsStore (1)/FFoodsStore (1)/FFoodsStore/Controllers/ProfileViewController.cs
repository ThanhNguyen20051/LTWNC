using Microsoft.AspNetCore.Mvc;

namespace FFoodsStore.Controllers
{
    [Route("Profile")]
    public class ProfileController : Controller
    {
        // GET: /Profile
        // GET: /Profile/Index
        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
    }
}

