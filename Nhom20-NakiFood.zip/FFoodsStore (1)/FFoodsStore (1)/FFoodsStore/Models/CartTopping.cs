﻿using System;
using System.Collections.Generic;

namespace FFoodsStore.Models;

public partial class CartTopping
{
    public int ID { get; set; }

    public int? CartID { get; set; }

    public int? ToppingID { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string? UpdatedBy { get; set; }
}
