using Microsoft.AspNetCore.Mvc;
using FFoodsStore.Data;
using FFoodsStore.Models;
using System;
using System.Linq;
using Microsoft.AspNetCore.Hosting;

namespace FFoodsStore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PromotionApiController : ControllerBase
    {
        private readonly StoreDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public PromotionApiController(StoreDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        // 🟢 Lấy danh sách khuyến mãi (tất cả, không cần điều kiện ngày nữa)
        [HttpGet]
        public IActionResult GetAll()
        {
            var promos = _context.Promotion
                .Where(p => !p.IsDeleted)
                .OrderByDescending(p => p.CreatedDate) // Lấy các khuyến mãi theo ngày tạo
                .Select(p => new
                {
                    p.Id,
                    p.Name,
                    p.Description,
                    p.Value,
                    p.Type,
                    p.BannerUrl,
                    p.StartDate,
                    p.EndDate,
                    p.IsActive
                })
                .ToList();

            return Ok(promos);
        }

        // 🟢 Thêm khuyến mãi (CHỈ ADMIN)
        [HttpPost]
        public IActionResult Create([FromBody] Promotion promo)
        {
            // TODO: Thêm authentication check sau
            // Hiện tại validation được thực hiện ở client-side và PromotionController
            // Nếu gọi từ API trực tiếp, cần check authentication header hoặc token

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Chuẩn hoá ngày
            promo.StartDate = promo.StartDate == default || promo.StartDate.Year < 1753 ? DateTime.Now : promo.StartDate;
            promo.EndDate = promo.EndDate == default || promo.EndDate.Year < 1753 ? DateTime.Now.AddDays(7) : promo.EndDate;

            promo.CreatedDate = DateTime.Now;
            promo.UpdatedDate = DateTime.Now;
            promo.IsDeleted = false;
            promo.IsActive = true;

            // Thêm vào DB
            _context.Promotion.Add(promo);
            _context.SaveChanges();

            return Ok(promo); // Trả về khuyến mãi vừa thêm
        }

        // 🟡 Cập nhật khuyến mãi (CHỈ ADMIN)
        [HttpPut("{id}")]
        public IActionResult Update(int id, [FromBody] Promotion input)
        {
            // TODO: Thêm authentication check sau
            // Hiện tại validation được thực hiện ở client-side và PromotionController

            var promo = _context.Promotion.FirstOrDefault(x => x.Id == id && !x.IsDeleted);
            if (promo == null)
                return NotFound();

            promo.Name = input.Name;
            promo.Description = input.Description;
            promo.Value = input.Value;
            // Chỉ cập nhật BannerUrl nếu có giá trị (để giữ nguyên banner cũ nếu không upload mới)
            if (!string.IsNullOrEmpty(input.BannerUrl))
            {
                // Xóa banner cũ nếu có và banner mới khác banner cũ
                if (!string.IsNullOrEmpty(promo.BannerUrl) && promo.BannerUrl != input.BannerUrl)
                {
                    var oldFilePath = Path.Combine(_environment.WebRootPath, promo.BannerUrl.TrimStart('/'));
                    if (System.IO.File.Exists(oldFilePath))
                    {
                        try
                        {
                            System.IO.File.Delete(oldFilePath);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine($"[PROMOTION API] Error deleting old banner: {ex.Message}");
                        }
                    }
                }
                promo.BannerUrl = input.BannerUrl;
            }
            promo.Type = input.Type;
            promo.IsActive = input.IsActive;

            promo.StartDate = input.StartDate.Year < 1753 ? DateTime.Now : input.StartDate;
            promo.EndDate = input.EndDate.Year < 1753 ? DateTime.Now.AddDays(7) : input.EndDate;

            promo.UpdatedDate = DateTime.Now;

            _context.SaveChanges();
            return Ok(promo); // Trả về khuyến mãi đã cập nhật
        }

        // 🔴 Xóa khuyến mãi (soft delete - CHỈ ADMIN)
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            // TODO: Thêm authentication check sau
            // Hiện tại validation được thực hiện ở client-side và PromotionController

            var promo = _context.Promotion.FirstOrDefault(x => x.Id == id && !x.IsDeleted);
            if (promo == null)
                return NotFound();

            promo.IsDeleted = true;
            promo.UpdatedDate = DateTime.Now;
            _context.SaveChanges();

            return Ok(); // Xóa thành công
        }

        // 📷 Upload banner (CHỈ ADMIN)
        [HttpPost("upload-banner")]
        public async Task<IActionResult> UploadBanner(IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0)
                {
                    return BadRequest("Vui lòng chọn file ảnh!");
                }

                // Kiểm tra file type
                var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
                var fileExtension = Path.GetExtension(file.FileName).ToLowerInvariant();
                
                if (!allowedExtensions.Contains(fileExtension))
                {
                    return BadRequest("Chỉ chấp nhận file ảnh (jpg, jpeg, png, gif, webp)!");
                }

                // Kiểm tra file size (max 10MB)
                if (file.Length > 10 * 1024 * 1024)
                {
                    return BadRequest("File ảnh không được vượt quá 10MB!");
                }

                // Tạo tên file unique
                var fileName = $"banner_{DateTime.Now.Ticks}{fileExtension}";
                var uploadsFolder = Path.Combine(_environment.WebRootPath, "images", "promotions");
                
                // Tạo thư mục nếu chưa có
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                var filePath = Path.Combine(uploadsFolder, fileName);

                // Lưu file
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(stream);
                }

                var bannerUrl = $"/images/promotions/{fileName}";

                return Ok(new { bannerUrl = bannerUrl, message = "Upload thành công!" });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[PROMOTION API] UploadBanner error: {ex.Message}");
                return StatusCode(500, $"Lỗi server: {ex.Message}");
            }
        }
    }
}
