using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using FFoodsStore.ViewModels;   // <-- dùng ViewModels riêng
using System.Linq;

namespace FFoodsStore.Controllers
{
    public class HomeController : Controller
    {
        private readonly StoreDbContext _db;
        public HomeController(StoreDbContext db) => _db = db;

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            // Danh mục có ít nhất 1 sản phẩm
            var cats = await (
                from t in _db.Set<ProductType>()
                where (t.IsDelete == null || t.IsDelete == false)
                let count = _db.Set<Product>().Count(p =>
                    p.ProductTypeID == t.ID && (p.IsDeleted == null || p.IsDeleted == false))
                where count > 0
                let cover =
                    (from i in _db.Set<ProductImage>()
                     join p in _db.Set<Product>() on i.ProductID equals p.ID
                     where (i.IsDelete == null || i.IsDelete == false)
                             && (p.IsDeleted == null || p.IsDeleted == false)
                             && p.ProductTypeID == t.ID
                     orderby i.ID
                     select i.ImageUrl).FirstOrDefault()
                select new HomeCategoryVM
                {
                    Slug = Slug(t.TypeCode ?? t.TypeName ?? "other"),
                    Name = t.TypeName ?? "Khác",
                    Count = count,
                    CoverUrl = FixImage(cover, $"https://picsum.photos/seed/{Slug(t.TypeCode ?? t.TypeName ?? "other")}-cover/800/450")
                }
            ).OrderBy(x => x.Name).ToListAsync();

            // Món tiêu biểu
            var featured = await (
                from p in _db.Set<Product>()
                where (p.IsDeleted == null || p.IsDeleted == false)
                && (p.IsActive == null || p.IsActive == true)
                join pt in _db.Set<ProductType>() on p.ProductTypeID equals pt.ID
                let minPrice = _db.Set<ProductDetail>()
                                .Where(d => d.ProductID == p.ID && (d.IsDelete == null || d.IsDelete == false))
                                .Select(d => (decimal?)d.Price).Min()
                let img = _db.Set<ProductImage>()
                            .Where(i => i.ProductID == p.ID && (i.IsDelete == null || i.IsDelete == false))
                            .OrderBy(i => i.ID).Select(i => i.ImageUrl).FirstOrDefault()
                where minPrice != null
                select new FeaturedProductVM
                {
                    Id = p.ID,
                    Name = p.ProductName ?? "",
                    TypeSlug = Slug(pt.TypeCode ?? pt.TypeName ?? "other"),
                    TypeName = pt.TypeName ?? "Khác",
                    Price = minPrice ?? 0,
                    ImageUrl = FixImage(img, $"https://picsum.photos/seed/p-{p.ID}/800/450")
                }
            )
            .OrderByDescending(x => x.Id)
            .ToListAsync();

            var vm = new HomeVM { Categories = cats, Featured = featured };
            return View(vm);
        }

        // Helper Slug: C# only
        private static string Slug(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "other";
            s = s.ToLowerInvariant();
            var repl = new Dictionary<string, string> {
                    { " ", "-" }, { "/", "-" }, { "\\", "-" }, { "_", "-" },
                    { "ă","a" }, { "â","a" }, { "á","a" }, { "à","a" }, { "ả","a" }, { "ã","a" }, { "ạ","a" },
                    { "ê","e" }, { "é","e" }, { "è","e" }, { "ẻ","e" }, { "ẽ","e" }, { "ẹ","e" },
                    { "ô","o" }, { "ơ","o" }, { "ó","o" }, { "ò","o" }, { "ỏ","o" }, { "õ","o" }, { "ọ","o" },
                    { "ư","u" }, { "ú","u" }, { "ù","u" }, { "ủ","u" }, { "ũ","u" }, { "ụ","u" },
                    { "í","i" }, { "ì","i" }, { "ỉ","i" }, { "ĩ","i" }, { "ị","i" },
                    { "ý","y" }, { "ỳ","y" }, { "ỷ","y" }, { "ỹ","y" }, { "ỵ","y" },
                    { "đ","d" }
                };
            foreach (var kv in repl) s = s.Replace(kv.Key, kv.Value);
            return s;
        }

        // ✅ FIX ẢNH (local, null, hoặc sai định dạng)
        private static string FixImage(string? img, string fallback)
        {
            if (string.IsNullOrWhiteSpace(img))
                return fallback;

            img = img.Trim();

            // Nếu là đường dẫn http => giữ nguyên
            if (img.StartsWith("http", StringComparison.OrdinalIgnoreCase))
                return img;

            // Bỏ "~" nếu có
            if (img.StartsWith("~/"))
                img = img[1..];

            // Loại bỏ duplicate /images/ nếu có
            while (img.StartsWith("/images/images/", StringComparison.OrdinalIgnoreCase))
                img = img.Substring(7); // Bỏ "/images"

            // Đảm bảo bắt đầu bằng "/"
            if (!img.StartsWith("/"))
                img = "/" + img;

            // Nếu không có /images/ trong path và không phải http, thêm /images/uploads/
            if (!img.StartsWith("/images/", StringComparison.OrdinalIgnoreCase) && !img.StartsWith("http", StringComparison.OrdinalIgnoreCase))
            {
                // Nếu path bắt đầu bằng /products/ hoặc /uploads/, thêm /images
                if (img.StartsWith("/products/") || img.StartsWith("/uploads/"))
                    img = "/images" + img;
                else
                    img = "/images/uploads" + img;
            }

            return img;
        }

        [HttpGet("/api/home/featured")]
        public async Task<IActionResult> GetFeatured(int page = 1, int pageSize = 8)
        {
            if (page < 1) page = 1;
            if (pageSize < 1) pageSize = 8;

            var query = (
                from p in _db.Products
                join pt in _db.ProductTypes on p.ProductTypeID equals pt.ID
                where (p.IsDeleted == null || p.IsDeleted == false)
                      && (p.IsActive == null || p.IsActive == true)
                let minPrice = _db.ProductDetails
                    .Where(d => d.ProductID == p.ID && (d.IsDelete == null || d.IsDelete == false))
                    .Select(d => (decimal?)d.Price).Min()
                let img = _db.ProductImages
                    .Where(i => i.ProductID == p.ID && (i.IsDelete == null || i.IsDelete == false))
                    .OrderBy(i => i.ID).Select(i => i.ImageUrl).FirstOrDefault()
                where minPrice != null
                select new FeaturedProductVM
                {
                    Id = p.ID,
                    Name = p.ProductName ?? "",
                    TypeSlug = Slug(pt.TypeCode ?? pt.TypeName ?? "other"),
                    TypeName = pt.TypeName ?? "Khác",
                    Price = minPrice ?? 0,
                    ImageUrl = FixImage(img, $"https://picsum.photos/seed/p-{p.ID}/800/450")
                }
            )
            .OrderByDescending(x => x.Id);

            var total = await query.CountAsync();
            var items = await query.Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();

            return Json(new
            {
                Total = total,
                Page = page,
                PageSize = pageSize,
                Items = items
            });
        }

        // ==================== API: phân trang theo loại + lấy top N món/loại ====================
        [HttpGet("/api/home/featured-groups")]
        public async Task<IActionResult> GetFeaturedGroups(int page = 1, int pageSize = 3, int takePerGroup = 4)
        {
            if (page < 1) page = 1;
            if (pageSize < 1) pageSize = 3;
            if (takePerGroup < 1) takePerGroup = 4;

            var typeQuery =
                from t in _db.ProductTypes
                where (t.IsDelete == null || t.IsDelete == false)
                let hasAny = _db.Products.Any(p =>
                    p.ProductTypeID == t.ID &&
                    (p.IsDeleted == null || p.IsDeleted == false) &&
                    (p.IsActive == null || p.IsActive == true))
                where hasAny
                orderby t.TypeName
                select new { t.ID, t.TypeName, TypeSlug = (t.TypeCode ?? t.TypeName) };

            var totalGroups = await typeQuery.CountAsync();
            var types = await typeQuery
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            var groups = new List<object>();
            foreach (var tp in types)
            {
                var items = await (
                    from p in _db.Products
                    where p.ProductTypeID == tp.ID
                       && (p.IsDeleted == null || p.IsDeleted == false)
                       && (p.IsActive == null || p.IsActive == true)
                    let minPrice = _db.ProductDetails
                        .Where(d => d.ProductID == p.ID && (d.IsDelete == null || d.IsDelete == false))
                        .Select(d => (decimal?)d.Price).Min()
                    let img = _db.ProductImages
                        .Where(i => i.ProductID == p.ID && (i.IsDelete == null || i.IsDelete == false))
                        .OrderBy(i => i.ID)
                        .Select(i => i.ImageUrl)
                        .FirstOrDefault()
                    let imageUrl = FixImage(img, $"https://picsum.photos/seed/p-{p.ID}/800/450")
                    where minPrice != null
                    orderby p.ID descending
                    select new
                    {
                        id = p.ID,
                        name = p.ProductName ?? "",
                        price = minPrice ?? 0,
                        imageUrl = imageUrl,
                        typeSlug = Slug(tp.TypeSlug ?? "other"),
                        typeName = tp.TypeName ?? "Khác"
                    }
                ).Take(takePerGroup).ToListAsync();

                groups.Add(new
                {
                    typeSlug = Slug(tp.TypeSlug ?? "other"),
                    typeName = tp.TypeName ?? "Khác",
                    items
                });
            }

            return Json(new
            {
                totalGroups,
                page,
                pageSize,
                totalPages = (int)Math.Ceiling(totalGroups / (double)pageSize),
                groups
            });
        }
    }
}
