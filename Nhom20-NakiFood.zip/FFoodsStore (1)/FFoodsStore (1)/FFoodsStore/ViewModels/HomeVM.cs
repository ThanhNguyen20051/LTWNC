namespace FFoodsStore.ViewModels
{
    public class HomeVM
    {
        public List<HomeCategoryVM> Categories { get; set; } = new();
        public List<FeaturedProductVM> Featured { get; set; } = new();
    }

    public record HomeCategoryVM
    {
        public string Slug { get; init; } = "other";
        public string Name { get; init; } = "";
        public int Count { get; init; }
        public string CoverUrl { get; init; } = "";
    }

    public record FeaturedProductVM
    {
        public int Id { get; init; }
        public string Name { get; init; } = "";
        public string TypeSlug { get; init; } = "other";
        public string TypeName { get; init; } = "";
        public decimal Price { get; init; }
        public string ImageUrl { get; init; } = "";
    }
}
