using Microsoft.AspNetCore.Mvc;
using FFoodsStore.Data;
using FFoodsStore.Models;
using System.Linq;
using Microsoft.AspNetCore.Hosting;

namespace FFoodsStore.Controllers
{
    public class PromotionController : Controller
    {
        private readonly StoreDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public PromotionController(StoreDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        // ========== DANH SÁCH ==========
        public IActionResult Index()
        {
            var promos = _context.Promotion
                .Where(p => !p.IsDeleted)
                .OrderByDescending(p => p.StartDate)
                .ToList();
            return View(promos);
        }

        // ========== THÊM ==========
        [HttpGet]
        public IActionResult Create()
        {
            // Chỉ admin mới được truy cập
            if (!IsAdmin())
            {
                TempData["ErrorMessage"] = "Bạn không có quyền truy cập trang này!";
                return RedirectToAction(nameof(Index));
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Promotion model, IFormFile bannerFile)
        {
            // Chỉ admin mới được tạo
            if (!IsAdmin())
            {
                TempData["ErrorMessage"] = "Bạn không có quyền tạo khuyến mãi!";
                return RedirectToAction(nameof(Index));
            }

            // Xử lý upload file banner
            if (bannerFile != null && bannerFile.Length > 0)
            {
                var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
                var fileExtension = Path.GetExtension(bannerFile.FileName).ToLowerInvariant();
                
                if (!allowedExtensions.Contains(fileExtension))
                {
                    ModelState.AddModelError("BannerUrl", "Chỉ chấp nhận file ảnh (jpg, jpeg, png, gif, webp)!");
                    return View(model);
                }

                if (bannerFile.Length > 10 * 1024 * 1024) // 10MB
                {
                    ModelState.AddModelError("BannerUrl", "File ảnh không được vượt quá 10MB!");
                    return View(model);
                }

                var fileName = $"banner_{DateTime.Now.Ticks}{fileExtension}";
                var uploadsFolder = Path.Combine(_environment.WebRootPath, "images", "promotions");
                
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                var filePath = Path.Combine(uploadsFolder, fileName);
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    await bannerFile.CopyToAsync(stream);
                }

                model.BannerUrl = $"/images/promotions/{fileName}";
            }

            if (ModelState.IsValid)
            {
                model.CreatedDate = DateTime.Now;
                _context.Promotion.Add(model);
                _context.SaveChanges();
                return RedirectToAction(nameof(Manage));
            }
            return View(model);
        }

        // ========== SỬA ==========
        [HttpGet]
        public IActionResult Edit(int id)
        {
            // Chỉ admin mới được truy cập
            if (!IsAdmin())
            {
                TempData["ErrorMessage"] = "Bạn không có quyền sửa khuyến mãi!";
                return RedirectToAction(nameof(Index));
            }

            var promo = _context.Promotion.Find(id);
            if (promo == null) return NotFound();
            return View(promo);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(Promotion model, IFormFile bannerFile)
        {
            // Chỉ admin mới được sửa
            if (!IsAdmin())
            {
                TempData["ErrorMessage"] = "Bạn không có quyền sửa khuyến mãi!";
                return RedirectToAction(nameof(Index));
            }

            if (ModelState.IsValid)
            {
                var existing = _context.Promotion.Find(model.Id);
                if (existing == null) return NotFound();

                // Xử lý upload file banner mới (nếu có)
                if (bannerFile != null && bannerFile.Length > 0)
                {
                    var allowedExtensions = new[] { ".jpg", ".jpeg", ".png", ".gif", ".webp" };
                    var fileExtension = Path.GetExtension(bannerFile.FileName).ToLowerInvariant();
                    
                    if (!allowedExtensions.Contains(fileExtension))
                    {
                        ModelState.AddModelError("BannerUrl", "Chỉ chấp nhận file ảnh (jpg, jpeg, png, gif, webp)!");
                        return View(model);
                    }

                    if (bannerFile.Length > 10 * 1024 * 1024) // 10MB
                    {
                        ModelState.AddModelError("BannerUrl", "File ảnh không được vượt quá 10MB!");
                        return View(model);
                    }

                    // Xóa banner cũ nếu có
                    if (!string.IsNullOrEmpty(existing.BannerUrl))
                    {
                        var oldFilePath = Path.Combine(_environment.WebRootPath, existing.BannerUrl.TrimStart('/'));
                        if (System.IO.File.Exists(oldFilePath))
                        {
                            try
                            {
                                System.IO.File.Delete(oldFilePath);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"[PROMOTION] Error deleting old banner: {ex.Message}");
                            }
                        }
                    }

                    var fileName = $"banner_{DateTime.Now.Ticks}{fileExtension}";
                    var uploadsFolder = Path.Combine(_environment.WebRootPath, "images", "promotions");
                    
                    if (!Directory.Exists(uploadsFolder))
                    {
                        Directory.CreateDirectory(uploadsFolder);
                    }

                    var filePath = Path.Combine(uploadsFolder, fileName);
                    using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await bannerFile.CopyToAsync(stream);
                    }

                    existing.BannerUrl = $"/images/promotions/{fileName}";
                }
                else if (model.BannerUrl != existing.BannerUrl)
                {
                    // Nếu không có file mới nhưng URL thay đổi (giữ nguyên URL cũ)
                    existing.BannerUrl = model.BannerUrl;
                }

                existing.Name = model.Name;
                existing.Description = model.Description;
                existing.Code = model.Code;
                existing.Type = model.Type;
                existing.Value = model.Value;
                existing.MaxDiscount = model.MaxDiscount;
                existing.MinOrderValue = model.MinOrderValue;
                existing.StartDate = model.StartDate;
                existing.EndDate = model.EndDate;
                existing.IsActive = model.IsActive;
                existing.UpdatedDate = DateTime.Now;

                _context.SaveChanges();
                return RedirectToAction(nameof(Manage));
            }
            return View(model);
        }

        // ========== XÓA ==========
        [HttpGet]
        public IActionResult Delete(int id)
        {
            // Chỉ admin mới được xóa
            if (!IsAdmin())
            {
                TempData["ErrorMessage"] = "Bạn không có quyền xóa khuyến mãi!";
                return RedirectToAction(nameof(Index));
            }

            var promo = _context.Promotion.Find(id);
            if (promo == null) return NotFound();

            promo.IsDeleted = true;
            promo.UpdatedDate = DateTime.Now;
            _context.SaveChanges();
            return RedirectToAction(nameof(Manage));
        }
        
        public IActionResult Manage()
        {
            // Chỉ admin mới được truy cập
            if (!IsAdmin())
            {
                TempData["ErrorMessage"] = "Bạn không có quyền truy cập trang quản lý!";
                return RedirectToAction(nameof(Index));
            }

            var promos = _context.Promotion
                .Where(p => !p.IsDeleted)
                .OrderByDescending(p => p.StartDate)
                .ToList();
            return View(promos);
        }

        // ========== HELPER METHOD ==========
        private bool IsAdmin()
        {
            // Kiểm tra user từ localStorage qua JavaScript
            // Vì authentication dùng localStorage ở client-side,
            // nên server-side không thể check trực tiếp
            // Cần check ở client-side (JavaScript) và API
            // Tạm thời return true, sẽ được validate ở client-side và API endpoint
            return true; // Validation thực tế sẽ ở client-side và API
        }
    }
}
