using FFoodsStore.Models;

namespace FFoodsStore.ViewModels
{
    public class StaffDashboardVM
    {
        public int PendingOrders { get; set; }
        public int InProgressOrders { get; set; }
        public int ReadyOrders { get; set; }
        public int DeliveringOrders { get; set; }
        public int LowStockItems { get; set; }
        public List<StaffOrderVM> RecentOrders { get; set; } = new();
        public List<StaffAlertVM> Alerts { get; set; } = new();
    }

    public class StaffOrderVM
    {
        public int Id { get; set; }
        public string OrderCode { get; set; } = "";
        public string CustomerName { get; set; } = "";
        public string PhoneNumber { get; set; } = "";
        public string Address { get; set; } = "";
        public int? Status { get; set; }
        public string StatusName { get; set; } = "";
        public int? OrderType { get; set; }
        public string OrderTypeName { get; set; } = "";
        public bool IsDineIn { get; set; } // True nếu là đơn tại quầy
        public string PaymentMethod { get; set; } = "";
        public bool IsPaid { get; set; }
        public decimal Total { get; set; }
        public DateTime? CreateDate { get; set; }
        public List<StaffOrderDetailVM> Items { get; set; } = new();
    }

    public class StaffOrderDetailVM
    {
        public int Id { get; set; }
        public string ProductName { get; set; } = "";
        public string SizeName { get; set; } = "";
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public decimal TotalMoney { get; set; }
        public List<string> Toppings { get; set; } = new();
    }

    public class StaffKitchenItemVM
    {
        public int OrderId { get; set; }
        public string OrderCode { get; set; } = "";
        public int OrderDetailId { get; set; }
        public string ProductName { get; set; } = "";
        public string SizeName { get; set; } = "";
        public int Quantity { get; set; }
        public DateTime? CreateDate { get; set; }
        public int? Status { get; set; }
        public string SpecialRequest { get; set; } = "";
        public List<string> Toppings { get; set; } = new();
        public bool IsUrgent { get; set; }
    }

    public class StaffDeliveryVM
    {
        public int OrderId { get; set; }
        public string OrderCode { get; set; } = "";
        public string CustomerName { get; set; } = "";
        public string PhoneNumber { get; set; } = "";
        public string Address { get; set; } = "";
        public decimal Total { get; set; }
        public DateTime? CreateDate { get; set; }
        public int? Status { get; set; }
        public string ShipperName { get; set; } = "";
        public string ShipperPhone { get; set; } = "";
    }

    public class StaffInventoryVM
    {
        public int MaterialId { get; set; }
        public string MaterialCode { get; set; } = "";
        public string MaterialName { get; set; } = "";
        public decimal CurrentQuantity { get; set; }
        public decimal MinQuantity { get; set; }
        public string UnitName { get; set; } = "";
        public bool IsLowStock { get; set; }
    }

    public class StaffAlertVM
    {
        public string Type { get; set; } = ""; // "low_stock", "order_issue", "payment_issue"
        public string Message { get; set; } = "";
        public DateTime CreatedDate { get; set; }
        public bool IsRead { get; set; }
    }
}

