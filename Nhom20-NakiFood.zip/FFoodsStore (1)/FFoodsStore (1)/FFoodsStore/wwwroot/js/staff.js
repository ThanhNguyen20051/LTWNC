// ============================================
// STAFF JAVASCRIPT
// ============================================

// Toggle sidebar
function toggleSidebar() {
    const sidebar = document.querySelector('.staff-sidebar');
    if (sidebar) {
        sidebar.classList.toggle('open');
    }
}

// Load staff info
function loadStaffInfo() {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    
    // Kiểm tra đăng nhập và role staff
    if (!user || !user.id) {
        alert('Vui lòng đăng nhập!');
        window.location.href = '/AccountView/Login';
        return;
    }
    
    // Cho phép cả admin và staff truy cập trang staff
    if (user.role !== 1 && user.role !== 2) {
        alert('Bạn không có quyền truy cập trang nhân viên!');
        window.location.href = '/Home/Index';
        return;
    }
    
    // Load thông tin staff
    const staffNameEl = document.getElementById('staff-name');
    if (staffNameEl && user.fullName) {
        staffNameEl.textContent = user.fullName;
    }
    
    const staffAvatarEl = document.querySelector('.staff-avatar');
    if (staffAvatarEl && user.avatarUrl) {
        staffAvatarEl.src = user.avatarUrl;
    }
}

// Logout
function logout() {
    if (confirm('Bạn có chắc muốn đăng xuất?')) {
        localStorage.removeItem('user');
        localStorage.removeItem('role');
        localStorage.removeItem('accountId');
        window.location.href = '/AccountView/Login';
    }
}

// Format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(amount || 0);
}

// Format date
function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('vi-VN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    }).format(date);
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    loadStaffInfo();
    
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });
});

