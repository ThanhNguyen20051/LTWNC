namespace FFoodsStore.Models
{
    /// <summary>
    /// Enum representing order type values
    /// </summary>
    public enum OrderType
    {
        /// <summary>
        /// Ăn tại chỗ
        /// </summary>
        DineIn = 1,

        /// <summary>
        /// Mang đi
        /// </summary>
        Takeaway = 2,

        /// <summary>
        /// Giao hàng
        /// </summary>
        Delivery = 3
    }

    /// <summary>
    /// Helper methods for OrderType
    /// </summary>
    public static class OrderTypeHelper
    {
        /// <summary>
        /// Get type name in Vietnamese
        /// </summary>
        public static string GetTypeName(int? type)
        {
            return type switch
            {
                (int)OrderType.DineIn => "Ăn tại chỗ",
                (int)OrderType.Takeaway => "Mang đi",
                (int)OrderType.Delivery => "Giao hàng",
                _ => "Không xác định"
            };
        }

        /// <summary>
        /// Get type badge CSS class
        /// </summary>
        public static string GetTypeBadgeClass(int? type)
        {
            return type switch
            {
                (int)OrderType.DineIn => "badge-primary",
                (int)OrderType.Takeaway => "badge-info",
                (int)OrderType.Delivery => "badge-success",
                _ => "badge-secondary"
            };
        }

        /// <summary>
        /// Get type icon class
        /// </summary>
        public static string GetTypeIcon(int? type)
        {
            return type switch
            {
                (int)OrderType.DineIn => "fas fa-utensils",
                (int)OrderType.Takeaway => "fas fa-shopping-bag",
                (int)OrderType.Delivery => "fas fa-truck",
                _ => "fas fa-question-circle"
            };
        }
    }
}

