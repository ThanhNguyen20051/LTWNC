using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using FFoodsStore.Models.Dtos;
using FFoodsStore.ViewModels;
using System.Linq;

namespace FFoodsStore.Controllers
{
    [Route("Product")]
    public class ProductController : Controller
    {
        private readonly StoreDbContext _db;
        public ProductController(StoreDbContext db) => _db = db;

        // GET: /Product/Index - Thực đơn page
        [HttpGet]
        public async Task<IActionResult> Index(string? q, string? cat)
        {
            // Lấy ID loại theo slug
            List<int> filterTypeIds = new();
            if (!string.IsNullOrWhiteSpace(cat))
            {
                var typeRows = await _db.Set<ProductType>()
                    .Where(t => t.IsDelete == null || t.IsDelete == false)
                    .Select(t => new { t.ID, t.TypeCode, t.TypeName })
                    .ToListAsync();

                filterTypeIds = typeRows
                    .Select(t => new { t.ID, Slug = Slug(t.TypeCode ?? t.TypeName ?? "other") })
                    .Where(x => x.Slug == cat)
                    .Select(x => x.ID)
                    .ToList();
            }

            // JOIN Product + Type + Detail + Image
            var baseQuery =
                from p in _db.Set<Product>()
                join pt in _db.Set<ProductType>() on p.ProductTypeID equals pt.ID
                join pd in _db.Set<ProductDetail>() on p.ID equals pd.ProductID
                join pi in _db.Set<ProductImage>() on p.ID equals pi.ProductID into imgGroup
                from pi in imgGroup.DefaultIfEmpty()
                where (p.IsDeleted == null || p.IsDeleted == false)
                      && (p.IsActive == true)
                      && (pd.IsDelete == null || pd.IsDelete == false)
                      && (pd.Price != null && pd.Price > 0)
                      && (pt.IsDelete == null || pt.IsDelete == false)
                select new
                {
                    Product = p,
                    Type = pt,
                    Detail = pd,
                    Image = pi
                };

            // Lọc theo tên
            if (!string.IsNullOrWhiteSpace(q))
            {
                baseQuery = baseQuery.Where(x => EF.Functions.Like(x.Product.ProductName ?? "", $"%{q}%"));
            }

            // Lọc theo loại
            if (filterTypeIds.Count > 0)
            {
                baseQuery = baseQuery.Where(x => filterTypeIds.Contains(x.Type.ID));
            }
            else if (!string.IsNullOrWhiteSpace(cat))
            {
                baseQuery = baseQuery.Where(x => false);
            }

            // Chuyển sang LINQ thuần
            var list = await baseQuery.ToListAsync();

            Console.WriteLine($"[PRODUCT] Index - Found {list.Count} raw items after query (q={q}, cat={cat})");

            var items = list
                .GroupBy(x => new { x.Product, x.Type })
                .Select(g => new MenuItemVM
                {
                    ProductDetailId = g.Min(x => x.Detail.ID),
                    ProductId = g.Key.Product.ID,
                    Name = g.Key.Product.ProductName ?? "",
                    TypeName = g.Key.Type.TypeName ?? "Khác",
                    TypeSlug = Slug(g.Key.Type.TypeCode ?? g.Key.Type.TypeName ?? "other"),
                    Price = g.Min(x => x.Detail.Price) ?? 0,
                    // Get the most recent non-deleted image from the group (from join)
                    ImageUrl = FixImage(
                        g.Where(x => x.Image != null && (x.Image.IsDelete == null || x.Image.IsDelete == false))
                         .Select(x => x.Image)
                         .OrderByDescending(pi => pi.ID)
                         .FirstOrDefault()?.ImageUrl,
                        $"https://picsum.photos/seed/p-{g.Key.Product.ID}/800/450")
                })
                .OrderBy(x => x.Name)
                .ToList();

            Console.WriteLine($"[PRODUCT] Index - Returning {items.Count} grouped items");
            if (items.Count > 0)
            {
                Console.WriteLine($"[PRODUCT] Sample products: {string.Join(", ", items.Take(3).Select(i => $"{i.Name}(ID:{i.ProductId})"))}");
            }

            var vm = new MenuVM { Q = q, Cat = cat, Items = items };
            return View(vm);
        }

        // Helper tạo slug tiếng Việt
        private static string Slug(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "other";
            s = s.ToLowerInvariant();
            var repl = new Dictionary<string, string> {
                { " ", "-" }, { "/", "-" }, { "\\", "-" }, { "_", "-" },
                { "ă","a" }, { "â","a" }, { "á","a" }, { "à","a" }, { "ả","a" }, { "ã","a" }, { "ạ","a" },
                { "ê","e" }, { "é","e" }, { "è","e" }, { "ẻ","e" }, { "ẽ","e" }, { "ẹ","e" },
                { "ô","o" }, { "ơ","o" }, { "ó","o" }, { "ò","o" }, { "ỏ","o" }, { "õ","o" }, { "ọ","o" },
                { "ư","u" }, { "ú","u" }, { "ù","u" }, { "ủ","u" }, { "ũ","u" }, { "ụ","u" },
                { "í","i" }, { "ì","i" }, { "ỉ","i" }, { "ĩ","i" }, { "ị","i" },
                { "ý","y" }, { "ỳ","y" }, { "ỷ","y" }, { "ỹ","y" }, { "ỵ","y" },
                { "đ","d" }
            };
            foreach (var kv in repl) s = s.Replace(kv.Key, kv.Value);
            return s;
        }

        // Fix ảnh
        private static string FixImage(string? img, string fallback)
        {
            if (string.IsNullOrWhiteSpace(img))
                return fallback;

            img = img.Trim();

            // Nếu là đường dẫn http => giữ nguyên
            if (img.StartsWith("http", StringComparison.OrdinalIgnoreCase))
                return img;

            // Bỏ "~" nếu có
            if (img.StartsWith("~/"))
                img = img[1..];

            // Loại bỏ duplicate /images/ nếu có
            while (img.StartsWith("/images/images/", StringComparison.OrdinalIgnoreCase))
                img = img.Substring(7); // Bỏ "/images"

            // Đảm bảo bắt đầu bằng "/"
            if (!img.StartsWith("/"))
                img = "/" + img;

            // Nếu không có /images/ trong path và không phải http, thêm /images/uploads/
            if (!img.StartsWith("/images/", StringComparison.OrdinalIgnoreCase) && !img.StartsWith("http", StringComparison.OrdinalIgnoreCase))
            {
                // Nếu path bắt đầu bằng /products/ hoặc /uploads/, thêm /images
                if (img.StartsWith("/products/") || img.StartsWith("/uploads/"))
                    img = "/images" + img;
                else
                    img = "/images/uploads" + img;
            }

            return img;
        }

        // GET: /Product/Details/5 - Standardized route
        [HttpGet("Details/{id}")]
        public async Task<IActionResult> Details(int id)
        {
            var product = await _db.Products
                .Include(p => p.ProductType)
                .Include(p => p.ProductDetails)
                .Include(p => p.ProductImages)
                .FirstOrDefaultAsync(p => p.ID == id && (p.IsDeleted == null || p.IsDeleted == false));

            if (product == null)
                return NotFound(); // Nếu không tìm thấy sản phẩm

            // Get the most recent non-deleted image (same logic as list pages)
            var img = product.ProductImages?
                .Where(pi => pi.IsDelete == null || pi.IsDelete == false)
                .OrderByDescending(pi => pi.ID)
                .FirstOrDefault()?.ImageUrl;
            
            // Apply FixImage to normalize path (same as list pages)
            img = FixImage(img, $"https://picsum.photos/seed/p-{id}/800/450");

            ViewData["ImageUrl"] = img;
            ViewData["TypeName"] = product.ProductType?.TypeName ?? "Khác"; // Hiển thị loại sản phẩm
            ViewData["Ingredients"] = product.Ingredients ?? "Đang cập nhật..."; // Hiển thị Nguyên liệu
            ViewData["Flavor"] = product.Flavor ?? "Hấp dẫn, thơm ngon khó cưỡng";  // Hương vị

            return View("Details", product); // Trả về Details view
        }

        // GET: /Product/Detail/5 - Keep for backward compatibility
        [HttpGet("Detail/{id}")]
        public async Task<IActionResult> Detail(int id)
        {
            var product = await _db.Products
                .Include(p => p.ProductType)
                .Include(p => p.ProductDetails)
                .Include(p => p.ProductImages)
                .FirstOrDefaultAsync(p => p.ID == id && (p.IsDeleted == null || p.IsDeleted == false));

            if (product == null)
                return NotFound(); // Nếu không tìm thấy sản phẩm

            // Get the most recent non-deleted image (same logic as list pages)
            var img = product.ProductImages?
                .Where(pi => pi.IsDelete == null || pi.IsDelete == false)
                .OrderByDescending(pi => pi.ID)
                .FirstOrDefault()?.ImageUrl;
            
            // Apply FixImage to normalize path (same as list pages)
            img = FixImage(img, $"https://picsum.photos/seed/p-{id}/800/450");

            ViewData["ImageUrl"] = img;
            ViewData["TypeName"] = product.ProductType?.TypeName ?? "Khác"; // Hiển thị loại sản phẩm
            ViewData["Ingredients"] = product.Ingredients ?? "Đang cập nhật..."; // Hiển thị Nguyên liệu
            ViewData["Flavor"] = product.Flavor ?? "Hấp dẫn, thơm ngon khó cưỡng";  // Hương vị

            return View(product); // Trả về Detail view (backward compatibility)
        }

        // ===== API: Lấy chi tiết sản phẩm cho modal =====
        [HttpGet("/api/product/{id}")]
        public async Task<IActionResult> GetProductDetail(int id)
        {
            try
            {
                var product = await _db.Products
                    .Include(p => p.ProductType)
                    .Include(p => p.ProductDetails!)
                        .ThenInclude(pd => pd.ProductSize)
                    .Include(p => p.ProductImages)
                    .FirstOrDefaultAsync(p => p.ID == id && (p.IsDeleted == null || p.IsDeleted == false));

                if (product == null)
                {
                    return NotFound(new { message = "Không tìm thấy sản phẩm" });
                }

                // Get the most recent non-deleted image (same logic as list pages)
                var img = product.ProductImages?
                    .Where(pi => pi.IsDelete == null || pi.IsDelete == false)
                    .OrderByDescending(pi => pi.ID)
                    .FirstOrDefault()?.ImageUrl;
                
                // Apply FixImage to normalize path (same as list pages)
                img = FixImage(img, $"https://picsum.photos/seed/p-{id}/800/450");

                var productDetailsList = product.ProductDetails?
                    .Where(pd => pd != null && (pd.IsDelete == null || pd.IsDelete == false))
                    .OrderBy(pd => pd.Price ?? 0)
                    .Select(pd => new ProductDetailDto
                    {
                        Id = pd.ID,
                        ProductId = pd.ProductID ?? 0,
                        SizeId = pd.ProductSizeID ?? 0,
                        SizeName = pd.ProductSizeID switch
                        {
                            1 => "S",
                            2 => "M",
                            3 => "L",
                            _ => pd.ProductSize?.SizeName ?? "Khác"
                        },
                        Price = pd.Price ?? 0
                    })
                    .ToList();

                var productDetails = productDetailsList ?? new List<ProductDetailDto>();

                return Json(new
                {
                    id = product.ID,
                    name = product.ProductName ?? "",
                    description = product.Description ?? "Món ăn đặc trưng, mang hương vị đậm đà của cửa hàng chúng tôi.",
                    typeName = product.ProductType?.TypeName ?? "Khác",
                    imageUrl = img,
                    ingredients = product.Ingredients ?? "Đang cập nhật...",
                    flavor = product.Flavor ?? "Hấp dẫn, thơm ngon khó cưỡng",
                    productDetails = productDetails
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error in GetProductDetail: {ex.Message}");
                Console.WriteLine($"Stack trace: {ex.StackTrace}");
                return StatusCode(500, new { message = "Có lỗi xảy ra khi tải chi tiết sản phẩm" });
            }
        }
    }
}
