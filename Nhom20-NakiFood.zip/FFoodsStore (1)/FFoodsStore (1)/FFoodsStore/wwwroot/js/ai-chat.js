// ============================================
// GROQ AI CHATBOT
// ============================================
// This file integrates GROQ AI for chat functionality
// DO NOT MODIFY existing code - only ADD new functionality

(function() {
    'use strict';

    // GROQ API Configuration
    const GROQ_API_KEY = "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";
    const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
    const GROQ_MODEL = "llama3-8b-8192";
    
    // Chat history (preserved across messages)
    let messages = [];

    // Rat GIF path for loading animation
    const RAT_GIF_PATH = "/images/thanksgiving rat GIF by Disney Pixar.gif";

    // ============================================
    // MAIN: Send message to GROQ AI
    // ============================================
    async function sendMessage(userMessage) {
        if (!userMessage || !userMessage.trim()) {
            return;
        }

        const messageText = userMessage.trim();

        // 1. Render user message
        renderUserMessage(messageText);

        // 2. Show typing indicator
        showTypingEffect();

        // 3. Show loading animation
        showLoadingAnimation();

        try {
            // 4. Call GROQ API
            const aiResponse = await sendGroqMessage(messageText);

            // 5. Hide loading indicators
            hideTypingEffect();
            hideLoadingAnimation();

            // 6. Render AI response
            renderAIMessage(aiResponse);

            // 7. Save to conversation history
            saveToContext(messageText, aiResponse);

            // 8. Auto-scroll to bottom
            scrollToBottom();

        } catch (error) {
            console.error('GROQ API Error:', error);
            
            // Hide indicators
            hideTypingEffect();
            hideLoadingAnimation();

            // Show error message
            renderAIMessage("Xin lỗi, tôi đang gặp sự cố. Vui lòng thử lại sau.");
            
            scrollToBottom();
        }
    }

    // ============================================
    // Send message to GROQ AI
    // ============================================
    async function sendGroqMessage(userMessage) {
        try {
            // Add user message to history
            messages.push({
                role: "user",
                content: userMessage
            });

            // Call GROQ API
            const response = await fetch(GROQ_API_URL, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${GROQ_API_KEY}`
                },
                body: JSON.stringify({
                    model: GROQ_MODEL,
                    messages: messages,
                    temperature: 0.7,
                    max_tokens: 1024
                })
            });

            if (!response.ok) {
                const errorText = await response.text();
                console.error('GROQ API Error:', response.status, errorText);
                throw new Error(`Lỗi ${response.status}`);
            }

            const data = await response.json();
            
            // Extract reply from response
            const reply = data.choices?.[0]?.message?.content || "Xin lỗi, tôi không thể trả lời câu hỏi này.";
            
            // Add assistant reply to history
            messages.push({
                role: "assistant",
                content: reply
            });

            // Keep only last 20 messages (10 exchanges) to avoid token limit
            if (messages.length > 20) {
                messages = messages.slice(-20);
            }
            
            console.log('GROQ AI Reply received:', reply.substring(0, 50) + '...');
            return reply;

        } catch (error) {
            console.error('sendGroqMessage Error:', error);
            throw error;
        }
    }

    // ============================================
    // Render User Message
    // ============================================
    function renderUserMessage(messageText) {
        const messagesContainer = document.getElementById('chatMessages');
        if (!messagesContainer) return;

        // Remove welcome message if exists
        const welcomeMsg = messagesContainer.querySelector('.welcome-message');
        if (welcomeMsg) welcomeMsg.remove();

        // Create message div
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message user';

        const time = new Date().toLocaleTimeString('vi-VN', {
            hour: '2-digit',
            minute: '2-digit'
        });

        // User avatar (right side)
        const avatarHtml = `
            <div class="message-avatar user-avatar">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                    <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
                </svg>
            </div>
        `;

        messageDiv.innerHTML = `
            ${avatarHtml}
            <div class="message-content">
                <div class="message-text">${escapeHtml(messageText)}</div>
                <div class="message-time">${time}</div>
            </div>
        `;

        messagesContainer.appendChild(messageDiv);
        scrollToBottom();
    }

    // ============================================
    // Render AI Message with Typing Effect
    // ============================================
    function renderAIMessage(messageText) {
        const messagesContainer = document.getElementById('chatMessages');
        if (!messagesContainer) return;

        // Remove welcome message if exists
        const welcomeMsg = messagesContainer.querySelector('.welcome-message');
        if (welcomeMsg) welcomeMsg.remove();

        // Create message div
        const messageDiv = document.createElement('div');
        messageDiv.className = 'message bot';

        const time = new Date().toLocaleTimeString('vi-VN', {
            hour: '2-digit',
            minute: '2-digit'
        });

        // AI avatar (left side)
        const avatarHtml = `
            <div class="message-avatar ai-avatar">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z"/>
                </svg>
            </div>
        `;

        // Unique ID for this message
        const messageId = 'ai-msg-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
        
        messageDiv.innerHTML = `
            ${avatarHtml}
            <div class="message-content">
                <div class="message-text" id="${messageId}"></div>
                <div class="message-time">${time}</div>
            </div>
        `;

        messagesContainer.appendChild(messageDiv);
        scrollToBottom();

        // Apply typing effect
        const messageElement = document.getElementById(messageId);
        if (messageElement) {
            typeMessage(messageElement, messageText, 15);
        }
    }

    // ============================================
    // Typing Effect Animation
    // ============================================
    function typeMessage(element, text, speed = 15) {
        element.innerHTML = '';
        let i = 0;
        const timer = setInterval(() => {
            if (i < text.length) {
                // Escape HTML for typing
                const char = text.charAt(i);
                if (char === '\n') {
                    element.innerHTML += '<br>';
                } else {
                    element.innerHTML += escapeHtml(char);
                }
                i++;
                scrollToBottom();
            } else {
                clearInterval(timer);
                // After typing completes, format the message properly
                formatMessage(element, text);
            }
        }, speed);
    }

    // ============================================
    // Format message with line breaks
    // ============================================
    function formatMessage(element, text) {
        // Convert newlines to <br>
        let formatted = escapeHtml(text)
            .replace(/\n/g, '<br>');
        
        element.innerHTML = formatted;
        scrollToBottom();
    }

    // ============================================
    // Show Typing Effect ("AI đang trả lời…" với 3 chấm)
    // ============================================
    function showTypingEffect() {
        const messagesContainer = document.getElementById('chatMessages');
        if (!messagesContainer) return;

        // Remove existing typing indicator
        hideTypingEffect();

        const typingDiv = document.createElement('div');
        typingDiv.className = 'message bot typing-indicator-wrapper';
        typingDiv.id = 'aiTypingIndicator';

        const avatarHtml = `
            <div class="message-avatar ai-avatar">
                <svg viewBox="0 0 24 24" width="24" height="24" fill="currentColor">
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm-1-13h2v6h-2zm0 8h2v2h-2z"/>
                </svg>
            </div>
        `;

        typingDiv.innerHTML = `
            ${avatarHtml}
            <div class="message-content">
                <div class="typing-indicator">
                    <span>AI đang trả lời</span>
                    <span class="typing-dots">
                        <span>.</span>
                        <span>.</span>
                        <span>.</span>
                    </span>
                </div>
            </div>
        `;

        messagesContainer.appendChild(typingDiv);
        scrollToBottom();
    }

    // ============================================
    // Hide Typing Effect
    // ============================================
    function hideTypingEffect() {
        const typingIndicator = document.getElementById('aiTypingIndicator');
        if (typingIndicator) {
            typingIndicator.remove();
        }
    }

    // ============================================
    // Show Loading Animation (Rat GIF)
    // ============================================
    function showLoadingAnimation() {
        const messagesContainer = document.getElementById('chatMessages');
        if (!messagesContainer) return;

        // Remove existing loading indicator
        hideLoadingAnimation();

        // Create loading overlay with rat GIF
        const loadingDiv = document.createElement('div');
        loadingDiv.className = 'ai-loading-overlay';
        loadingDiv.id = 'aiLoadingOverlay';
        loadingDiv.innerHTML = `
            <div class="loading-content">
                <img src="${RAT_GIF_PATH}" alt="Loading" class="loading-rat-gif" />
                <span class="loading-text">Đang xử lý...</span>
            </div>
        `;

        messagesContainer.appendChild(loadingDiv);
    }

    // ============================================
    // Hide Loading Animation
    // ============================================
    function hideLoadingAnimation() {
        const loadingOverlay = document.getElementById('aiLoadingOverlay');
        if (loadingOverlay) {
            loadingOverlay.remove();
        }
    }

    // ============================================
    // Save to Conversation Context
    // ============================================
    function saveToContext(userMessage, aiResponse) {
        // Messages are already saved in sendGroqMessage()
        // This function is kept for compatibility
        // Chat history is preserved in messages[] array
    }

    // ============================================
    // Auto-scroll to Bottom
    // ============================================
    function scrollToBottom() {
        const messagesContainer = document.getElementById('chatMessages');
        if (messagesContainer) {
            messagesContainer.scrollTop = messagesContainer.scrollHeight;
        }
    }

    // ============================================
    // Escape HTML
    // ============================================
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // ============================================
    // Initialize: Hook into existing chatbox
    // ============================================
    function initAIChat() {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', hookIntoChatbox);
        } else {
            hookIntoChatbox();
        }
    }

    // ============================================
    // Hook into existing chatbox sendMessage function
    // ============================================
    function hookIntoChatbox() {
        // Wait for DOM and chatbox.js to initialize
        let attempts = 0;
        const maxAttempts = 20;
        
        const tryHook = setInterval(() => {
            attempts++;
            const chatInput = document.getElementById('chatInput');
            const chatSend = document.getElementById('chatSend');
            const chatMessages = document.getElementById('chatMessages');
            
            if (chatInput && chatSend && chatMessages) {
                clearInterval(tryHook);
                
                // Intercept all click events on send button
                chatSend.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopImmediatePropagation();
                    
                    const message = chatInput.value.trim();
                    if (message) {
                        chatInput.value = '';
                        // Use our Gemini AI sendMessage
                        sendMessage(message);
                    }
                    return false;
                }, true); // Use capture phase to intercept first

                // Intercept Enter key
                chatInput.addEventListener('keypress', function(e) {
                    if (e.key === 'Enter' && !e.shiftKey) {
                        e.preventDefault();
                        e.stopImmediatePropagation();
                        
                        const message = chatInput.value.trim();
                        if (message) {
                            chatInput.value = '';
                            // Use our GROQ AI sendMessage
                            sendMessage(message);
                        }
                        return false;
                    }
                }, true); // Use capture phase

                // Handle suggestion chips
                setTimeout(() => {
                    const suggestionChips = document.querySelectorAll('.suggestion-chip');
                    suggestionChips.forEach(chip => {
                        chip.addEventListener('click', function(e) {
                            e.preventDefault();
                            e.stopImmediatePropagation();
                            
                            const message = this.getAttribute('data-message');
                            if (message && chatInput) {
                                chatInput.value = '';
                                // Use our Gemini AI sendMessage
                                sendMessage(message);
                            }
                            return false;
                        }, true); // Use capture phase
                    });
                }, 300);
                
                console.log('✅ GROQ AI Chat integrated successfully!');
            } else if (attempts >= maxAttempts) {
                clearInterval(tryHook);
                console.warn('⚠️ GROQ AI Chat: Could not find chatbox elements after', maxAttempts, 'attempts');
            }
        }, 200);
    }

    // ============================================
    // Export functions for global access
    // ============================================
    window.GroqAIChat = {
        sendMessage: sendMessage,
        sendGroqMessage: sendGroqMessage,
        renderUserMessage: renderUserMessage,
        renderAIMessage: renderAIMessage,
        showTypingEffect: showTypingEffect,
        hideTypingEffect: hideTypingEffect,
        showLoadingAnimation: showLoadingAnimation,
        hideLoadingAnimation: hideLoadingAnimation
    };

    // Initialize on load
    initAIChat();

})();
