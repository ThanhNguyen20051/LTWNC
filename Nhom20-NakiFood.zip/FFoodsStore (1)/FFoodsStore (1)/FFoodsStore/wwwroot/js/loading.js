// ===============================
// LOADING UTILITY - Reusable Loading Functions
// ===============================

(function() {
    'use strict';
    
    // ===============================
    // Show full page loading overlay
    // ===============================
    function showFullPageLoading(message = 'Đang xử lý...') {
        // Remove existing overlay if any
        const existing = document.getElementById('loadingOverlay');
        if (existing) existing.remove();
        
        const overlay = document.createElement('div');
        overlay.id = 'loadingOverlay';
        overlay.className = 'loading-overlay';
        overlay.innerHTML = `
            <div style="display: flex; flex-direction: column; align-items: center;">
                <div class="loading-spinner-large"></div>
                <div class="loading-text">${escapeHtml(message)}</div>
            </div>
        `;
        document.body.appendChild(overlay);
    }
    
    // ===============================
    // Hide full page loading overlay
    // ===============================
    function hideFullPageLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.style.opacity = '0';
            overlay.style.transition = 'opacity 0.3s';
            setTimeout(() => overlay.remove(), 300);
        }
    }
    
    // ===============================
    // Show button loading state
    // ===============================
    function showButtonLoading(button, originalText = null) {
        if (!button) return;
        
        // Store original text if not provided
        if (!originalText) {
            button.dataset.originalText = button.textContent || button.innerHTML;
        } else {
            button.dataset.originalText = originalText;
        }
        
        button.disabled = true;
        button.classList.add('btn-loading');
        
        // Add spinner to button
        const spinner = document.createElement('span');
        spinner.className = 'inline-loading';
        button.insertBefore(spinner, button.firstChild);
        
        // Update text if needed
        if (button.dataset.loadingText) {
            button.innerHTML = `<span class="inline-loading"></span>${button.dataset.loadingText}`;
        }
    }
    
    // ===============================
    // Hide button loading state
    // ===============================
    function hideButtonLoading(button) {
        if (!button) return;
        
        button.disabled = false;
        button.classList.remove('btn-loading');
        
        // Restore original text
        const originalText = button.dataset.originalText || button.textContent;
        if (originalText) {
            button.innerHTML = originalText;
        }
        
        // Remove spinner
        const spinner = button.querySelector('.inline-loading');
        if (spinner) spinner.remove();
    }
    
    // ===============================
    // Show container loading
    // ===============================
    function showContainerLoading(container, message = 'Đang tải...') {
        if (!container) return;
        
        container.innerHTML = `
            <div class="container-loading">
                <div class="loading-spinner"></div>
                <div class="loading-text">${escapeHtml(message)}</div>
            </div>
        `;
    }
    
    // ===============================
    // Wrap async function with loading
    // ===============================
    async function withLoading(asyncFn, options = {}) {
        const {
            showFullPage = false,
            fullPageMessage = 'Đang xử lý...',
            button = null,
            buttonLoadingText = null,
            container = null,
            containerMessage = 'Đang tải...'
        } = options;
        
        try {
            // Show loading
            if (showFullPage) {
                showFullPageLoading(fullPageMessage);
            } else if (button) {
                showButtonLoading(button, buttonLoadingText);
            } else if (container) {
                showContainerLoading(container, containerMessage);
            }
            
            // Execute async function
            const result = await asyncFn();
            
            return result;
        } catch (error) {
            throw error;
        } finally {
            // Hide loading
            if (showFullPage) {
                hideFullPageLoading();
            } else if (button) {
                hideButtonLoading(button);
            }
        }
    }
    
    // ===============================
    // Escape HTML
    // ===============================
    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    // ===============================
    // Show compact page loader (top center)
    // ===============================
    function showCompactPageLoader(message = 'Đang tải...') {
        // Remove existing loader if any
        const existing = document.getElementById('compactPageLoader');
        if (existing) existing.remove();
        
        const loader = document.createElement('div');
        loader.id = 'compactPageLoader';
        loader.className = 'page-loader-compact';
        loader.innerHTML = `
            <img src="https://media3.giphy.com/media/v1.Y2lkPTc5MGI3NjExNnd3b3V4ejVjZ3F4MjQwMHMxem41aHh4ZWp6bDdjMzZvYmtuNTZ3ZyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/Iv5BPnvKRKLZu/giphy.gif" 
                 alt="Loading" 
                 class="loading-gif-small" />
            <span>${escapeHtml(message)}</span>
        `;
        document.body.appendChild(loader);
    }
    
    // ===============================
    // Hide compact page loader
    // ===============================
    function hideCompactPageLoader() {
        const loader = document.getElementById('compactPageLoader');
        if (loader) {
            loader.style.opacity = '0';
            loader.style.transform = 'translateX(-50%) translateY(-20px)';
            loader.style.transition = 'all 0.3s ease-out';
            setTimeout(() => loader.remove(), 300);
        }
    }
    
    // ===============================
    // Show button loading with GIF
    // ===============================
    function showButtonLoadingGif(button, originalText = null) {
        if (!button) return;
        
        // Store original text if not provided
        if (!originalText) {
            button.dataset.originalText = button.textContent || button.innerHTML;
        } else {
            button.dataset.originalText = originalText;
        }
        
        button.disabled = true;
        button.classList.add('btn-loading');
        
        // Add GIF spinner to button
        const gifSpinner = document.createElement('img');
        gifSpinner.src = 'https://media3.giphy.com/media/v1.Y2lkPTc5MGI3NjExNnd3b3V4ejVjZ3F4MjQwMHMxem41aHh4ZWp6bDdjMzZvYmtuNTZ3ZyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/Iv5BPnvKRKLZu/giphy.gif';
        gifSpinner.className = 'loading-gif-small';
        gifSpinner.alt = 'Loading';
        
        // Update button content
        if (button.dataset.loadingText) {
            button.innerHTML = '';
            button.appendChild(gifSpinner);
            button.appendChild(document.createTextNode(button.dataset.loadingText));
        } else {
            button.innerHTML = '';
            button.appendChild(gifSpinner);
            button.appendChild(document.createTextNode(button.dataset.originalText));
        }
    }
    
    // ===============================
    // Show container loading with GIF
    // ===============================
    function showContainerLoadingGif(container, message = 'Đang tải...') {
        if (!container) return;
        
        container.innerHTML = `
            <div class="container-loading">
                <img src="https://media3.giphy.com/media/v1.Y2lkPTc5MGI3NjExNnd3b3V4ejVjZ3F4MjQwMHMxem41aHh4ZWp6bDdjMzZvYmtuNTZ3ZyZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/Iv5BPnvKRKLZu/giphy.gif" 
                     alt="Loading" 
                     class="loading-gif-medium" />
                <div class="loading-text">${escapeHtml(message)}</div>
            </div>
        `;
    }
    
    // ===============================
    // Show Ratatouille loader (center screen)
    // ===============================
    function showRatatouilleLoader(message = 'Đang tải...', gifUrl = null) {
        // Remove existing loader if any (force remove)
        const existing = document.getElementById('ratatouilleLoader');
        if (existing) {
            existing.style.display = 'none';
            existing.style.opacity = '0';
            existing.remove();
        }
        
        // Clear any pending timeout
        if (window._ratatouilleLoaderTimeout) {
            clearTimeout(window._ratatouilleLoaderTimeout);
            window._ratatouilleLoaderTimeout = null;
        }
        
        // Clear any pending minimum display timeout
        if (window._ratatouilleLoaderMinDisplayTimeout) {
            clearTimeout(window._ratatouilleLoaderMinDisplayTimeout);
            window._ratatouilleLoaderMinDisplayTimeout = null;
        }
        
        // Lưu thời gian bắt đầu hiển thị loader (để đảm bảo hiển thị tối thiểu 4-5 giây)
        window._ratatouilleLoaderStartTime = Date.now();
        
        // Default GIF path - dùng file GIF mới
        let defaultGifPath = gifUrl;
        if (!defaultGifPath) {
            // Tên file mới: "thanksgiving rat GIF by Disney Pixar.gif"
            // Encode URL đúng cách (spaces -> %20)
            const fileName = 'thanksgiving rat GIF by Disney Pixar.gif';
            defaultGifPath = '/images/' + encodeURIComponent(fileName);
        }
        
        console.log('Loading Ratatouille GIF from:', defaultGifPath);
        
        const loader = document.createElement('div');
        loader.id = 'ratatouilleLoader';
        loader.className = 'ratatouille-loader';
        
        const content = document.createElement('div');
        content.className = 'ratatouille-loader-content';
        
        // Create image element
        const img = document.createElement('img');
        // Thêm cache busting để đảm bảo load file mới nhất
        const cacheBuster = '?t=' + Date.now();
        img.src = defaultGifPath + cacheBuster;
        img.alt = 'Loading';
        img.className = 'ratatouille-gif';
        img.loading = 'eager';
        // Kích thước đã được set trong CSS (300% = 1140px), không cần inline style
        
        // Add fallback emoji (hidden by default, will show if GIF fails to load)
        const fallback = document.createElement('div');
        fallback.className = 'ratatouille-character';
        fallback.textContent = '🐭';
        fallback.style.display = 'none';
        
        // Add image and fallback to content
        content.appendChild(img);
        content.appendChild(fallback);
        
        // Add text
        const text = document.createElement('div');
        text.className = 'ratatouille-loader-text';
        text.textContent = message;
        content.appendChild(text);
        
        // Add dots
        const dots = document.createElement('div');
        dots.className = 'ratatouille-loader-dots';
        for (let i = 0; i < 3; i++) {
            const dot = document.createElement('span');
            dots.appendChild(dot);
        }
        content.appendChild(dots);
        
        loader.appendChild(content);
        document.body.appendChild(loader);
        
        // Set up error handler after DOM is appended
        img.onerror = function() {
            console.error('Failed to load GIF:', defaultGifPath);
            console.error('Attempted URL:', this.src);
            console.error('Trying alternative paths...');
            
            // Thử các đường dẫn khác (với tên file mới)
            const fileName = 'thanksgiving rat GIF by Disney Pixar.gif';
            const altPaths = [
                window.location.origin + '/images/' + encodeURIComponent(fileName),
                '/images/' + encodeURIComponent(fileName),
                '/images/' + fileName.replace(/ /g, '%20'),
                window.location.origin + '/images/ratatouille-loader.gif',
                '/images/ratatouille-loader.gif'
            ];
            
            let triedPath = 0;
            const tryNextPath = () => {
                if (triedPath < altPaths.length) {
                    console.log('Trying alternative path:', altPaths[triedPath]);
                    this.src = altPaths[triedPath] + '?t=' + Date.now();
                    triedPath++;
                } else {
                    console.error('All paths failed. Using emoji fallback.');
                    this.style.display = 'none';
                    fallback.style.display = 'block';
                }
            };
            
            // Thử lại với đường dẫn khác
            tryNextPath();
            
            // Nếu tất cả đều fail, hiển thị emoji
            this.onerror = function() {
                if (triedPath >= altPaths.length) {
                    console.error('All paths exhausted. Using emoji fallback.');
                    this.style.display = 'none';
                    fallback.style.display = 'block';
                } else {
                    tryNextPath();
                }
            };
        };
        
        // Set up load handler
        img.onload = function() {
            console.log('GIF loaded successfully:', defaultGifPath);
            fallback.style.display = 'none';
        };
    }
    
    // ===============================
    // Hide Ratatouille loader
    // ===============================
    function hideRatatouilleLoader() {
        const loader = document.getElementById('ratatouilleLoader');
        if (!loader) return;
        
        // Clear any pending timeout
        if (window._ratatouilleLoaderTimeout) {
            clearTimeout(window._ratatouilleLoaderTimeout);
            window._ratatouilleLoaderTimeout = null;
        }
        
        // Kiểm tra xem loader đã hiển thị đủ 1-2 giây chưa
        const minDisplayTime = 1500; // 1.5 giây (để GIF chạy hết)
        const startTime = window._ratatouilleLoaderStartTime || 0;
        const elapsedTime = Date.now() - startTime;
        const remainingTime = Math.max(0, minDisplayTime - elapsedTime);
        
        console.log('Loader display time:', elapsedTime, 'ms, Remaining:', remainingTime, 'ms');
        
        // Hàm thực sự hide loader
        const actuallyHideLoader = function() {
            if (!loader || !loader.parentNode) return;
            
            loader.style.opacity = '0';
            loader.style.transition = 'opacity 0.3s ease-out';
            loader.style.pointerEvents = 'none'; // Disable pointer events
            
            // Force remove after animation
            window._ratatouilleLoaderTimeout = setTimeout(() => {
                if (loader && loader.parentNode) {
                    loader.remove();
                }
                window._ratatouilleLoaderTimeout = null;
                window._ratatouilleLoaderStartTime = null;
            }, 300);
        };
        
        // Nếu đã đủ thời gian, hide ngay. Nếu chưa, đợi đến khi đủ
        if (remainingTime > 0) {
            console.log('Waiting', remainingTime, 'ms more to ensure GIF plays fully...');
            window._ratatouilleLoaderMinDisplayTimeout = setTimeout(actuallyHideLoader, remainingTime);
        } else {
            actuallyHideLoader();
        }
    }
    
    // ===============================
    // Export to window
    // ===============================
    window.showFullPageLoading = showFullPageLoading;
    window.hideFullPageLoading = hideFullPageLoading;
    window.showButtonLoading = showButtonLoading;
    window.hideButtonLoading = hideButtonLoading;
    window.showContainerLoading = showContainerLoading;
    window.showCompactPageLoader = showCompactPageLoader;
    window.hideCompactPageLoader = hideCompactPageLoader;
    window.showButtonLoadingGif = showButtonLoadingGif;
    window.showContainerLoadingGif = showContainerLoadingGif;
    
    // Ratatouille loader (center screen)
    window.showRatatouilleLoader = showRatatouilleLoader;
    window.hideRatatouilleLoader = hideRatatouilleLoader;
    
    // Legacy duck loaders (backward compatibility)
    window.showCompactDuckLoader = showRatatouilleLoader;
    window.hideCompactDuckLoader = hideRatatouilleLoader;
    window.showFullPageDuckLoader = showRatatouilleLoader;
    window.hideFullPageDuckLoader = hideRatatouilleLoader;
    window.showContainerDuckLoader = function(container, message, gifUrl = '/images/ratatouille-loader.gif') {
        if (!container) return;
        container.innerHTML = `
            <div class="ratatouille-loader" style="position: relative; height: 300px;">
                <div class="ratatouille-loader-content">
                    <img src="${escapeHtml(gifUrl)}" 
                         alt="Loading" 
                         class="ratatouille-gif"
                         style="width: 100px; height: 100px;"
                         onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                    <div class="ratatouille-character" style="display: none; font-size: 80px;">🐭</div>
                    <div class="ratatouille-loader-text">${escapeHtml(message)}</div>
                    <div class="ratatouille-loader-dots">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </div>
            </div>
        `;
    };
    
    window.withLoading = withLoading;
    
})();

