using Microsoft.AspNetCore.Mvc;
using FFoodsStore.Data;
using FFoodsStore.Models;

namespace FFoodsStore.Controllers
{
    public class ContactController : Controller
    {
        private readonly StoreDbContext _context;

        public ContactController(StoreDbContext context)
        {
            _context = context;
        }

        // GET: Contact
        public IActionResult Index()
        {
            return View();
        }

        // POST: Contact/Submit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Submit(Contact model)
        {
            if (ModelState.IsValid)
            {
                model.CreatedDate = DateTime.Now;
                model.Status = 0; // Chưa đọc
                model.IsDelete = false;

                _context.Contact.Add(model);
                _context.SaveChanges();

                TempData["SuccessMessage"] = "Cảm ơn bạn đã liên hệ! Chúng tôi sẽ phản hồi sớm nhất có thể.";
                return RedirectToAction(nameof(Index));
            }

            return View("Index", model);
        }
    }
}







