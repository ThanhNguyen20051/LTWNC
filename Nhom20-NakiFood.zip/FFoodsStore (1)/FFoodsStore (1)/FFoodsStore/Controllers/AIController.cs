using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using System.Text;
using System.Text.Json;

namespace FFoodsStore.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AIController : ControllerBase
    {
        private readonly StoreDbContext _context;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;

        public AIController(
            StoreDbContext context,
            IHttpClientFactory httpClientFactory,
            IConfiguration configuration)
        {
            _context = context;
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
        }

        // POST: /api/ai/chat
        [HttpPost("chat")]
        public async Task<IActionResult> Chat([FromBody] AIChatRequest request)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(request.Message))
                {
                    return BadRequest(new { error = "Tin nhắn không được để trống!" });
                }

                // Get AI provider from config
                var provider = _configuration["AI:Provider"] ?? "OpenAI";
                
                // Prepare context from database
                var context = await PrepareContextAsync();

                // Generate AI response
                string reply;
                if (provider.Equals("Gemini", StringComparison.OrdinalIgnoreCase))
                {
                    reply = await GenerateGeminiResponseAsync(request.Message, context);
                }
                else
                {
                    reply = await GenerateOpenAIResponseAsync(request.Message, context);
                }

                return Ok(new { reply = reply });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = "Đã xảy ra lỗi khi xử lý tin nhắn: " + ex.Message });
            }
        }

        // Prepare context from database
        private async Task<string> PrepareContextAsync()
        {
            var contextBuilder = new StringBuilder();

            // Get products with prices
            var productsList = await _context.Products
                .Include(p => p.ProductDetails!)
                    .ThenInclude(pd => pd.ProductSize)
                .Include(p => p.ProductType)
                .Where(p => (p.IsDeleted == null || p.IsDeleted == false) 
                         && (p.IsActive == null || p.IsActive == true))
                .ToListAsync();

            var products = productsList.Select(p =>
            {
                var activeDetails = p.ProductDetails?
                    .Where(pd => pd.IsDelete == null || pd.IsDelete == false)
                    .ToList() ?? new List<ProductDetail>();
                
                var prices = activeDetails
                    .Where(pd => pd.Price.HasValue)
                    .Select(pd => pd.Price!.Value)
                    .ToList();

                return new
                {
                    Id = p.ID,
                    Name = p.ProductName ?? "",
                    Type = p.ProductType != null ? p.ProductType.TypeName ?? "" : "",
                    Description = p.Description ?? "",
                    MinPrice = prices.Any() ? prices.Min() : 0m,
                    MaxPrice = prices.Any() ? prices.Max() : 0m
                };
            }).ToList();

            if (products.Any())
            {
                contextBuilder.AppendLine("=== DANH SÁCH SẢN PHẨM ===");
                foreach (var product in products.Take(50)) // Limit to 50 products
                {
                    var priceInfo = product.MinPrice == product.MaxPrice 
                        ? $"{product.MinPrice:N0}đ" 
                        : $"{product.MinPrice:N0}đ - {product.MaxPrice:N0}đ";
                    contextBuilder.AppendLine($"- ID {product.Id}: {product.Name} ({product.Type}) - Giá: {priceInfo}");
                    if (!string.IsNullOrWhiteSpace(product.Description))
                    {
                        contextBuilder.AppendLine($"  Mô tả: {product.Description}");
                    }
                }
                contextBuilder.AppendLine();
            }

            // Get promotions
            var promotions = await _context.Promotion
                .Where(p => p.IsActive && !p.IsDeleted 
                         && p.StartDate <= DateTime.Now 
                         && p.EndDate >= DateTime.Now)
                .OrderByDescending(p => p.CreatedDate)
                .Take(10)
                .Select(p => new
                {
                    Name = p.Name,
                    Description = p.Description ?? "",
                    Type = p.Type == 1 ? "%" : "đ",
                    Value = p.Value,
                    StartDate = p.StartDate,
                    EndDate = p.EndDate
                })
                .ToListAsync();

            if (promotions.Any())
            {
                contextBuilder.AppendLine("=== KHUYẾN MÃI HIỆN TẠI ===");
                foreach (var promo in promotions)
                {
                    var discountValue = promo.Type == "%" ? $"{promo.Value}%" : $"{promo.Value:N0}đ";
                    contextBuilder.AppendLine($"- {promo.Name}: Giảm {discountValue}");
                    if (!string.IsNullOrWhiteSpace(promo.Description))
                    {
                        contextBuilder.AppendLine($"  {promo.Description}");
                    }
                    contextBuilder.AppendLine($"  Thời gian: {promo.StartDate:dd/MM/yyyy} - {promo.EndDate:dd/MM/yyyy}");
                }
                contextBuilder.AppendLine();
            }

            // Get categories
            var categories = await _context.Set<ProductType>()
                .Where(t => t.IsDelete == null || t.IsDelete == false)
                .Select(t => new
                {
                    Name = t.TypeName ?? "",
                    Code = t.TypeCode ?? "",
                    Description = t.Description ?? ""
                })
                .ToListAsync();

            if (categories.Any())
            {
                contextBuilder.AppendLine("=== DANH MỤC SẢN PHẨM ===");
                foreach (var category in categories)
                {
                    contextBuilder.AppendLine($"- {category.Name}");
                    if (!string.IsNullOrWhiteSpace(category.Description))
                    {
                        contextBuilder.AppendLine($"  {category.Description}");
                    }
                }
                contextBuilder.AppendLine();
            }

            return contextBuilder.ToString();
        }

        // Generate OpenAI response
        private async Task<string> GenerateOpenAIResponseAsync(string userMessage, string context)
        {
            var apiKey = _configuration["AI:OpenAI:ApiKey"];
            if (string.IsNullOrWhiteSpace(apiKey))
            {
                return "Xin lỗi, AI service chưa được cấu hình. Vui lòng liên hệ admin.";
            }

            try
            {
                var client = _httpClientFactory.CreateClient();
                client.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}");
                client.Timeout = TimeSpan.FromSeconds(30);

                // Build system prompt with context
                var systemPrompt = $@"Bạn là NakiFood AI Assistant - trợ lý AI của cửa hàng thức ăn nhanh NakiFood.

NHIỆM VỤ:
- Luôn trả lời bằng tiếng Việt
- Luôn thân thiện và nhiệt tình
- Khi người dùng hỏi về sản phẩm, hãy gợi ý các món dựa trên dữ liệu trong cơ sở dữ liệu
- Nếu người dùng hỏi về giá, hãy tham khảo thông tin giá trong dữ liệu
- Nếu người dùng hỏi về khuyến mãi, hãy tham khảo các khuyến mãi hiện tại

DỮ LIỆU CƠ SỞ DỮ LIỆU:
{context}

HƯỚNG DẪN:
- Khi người dùng hỏi về menu hoặc món ăn, hãy liệt kê một số món phổ biến từ danh sách trên
- Khi người dùng hỏi về khuyến mãi, hãy thông báo các chương trình khuyến mãi hiện tại
- Khi người dùng hỏi về giá, hãy cung cấp thông tin giá từ dữ liệu
- Nếu không có thông tin trong dữ liệu, hãy trả lời một cách chung chung nhưng vẫn hữu ích
- Luôn khuyến khích người dùng xem chi tiết tại trang web của chúng tôi

Hãy trả lời câu hỏi của người dùng một cách tự nhiên và hữu ích.";

                var requestBody = new
                {
                    model = "gpt-4o-mini",
                    messages = new[]
                    {
                        new { role = "system", content = systemPrompt },
                        new { role = "user", content = userMessage }
                    },
                    max_tokens = 500,
                    temperature = 0.7
                };

                var jsonContent = JsonSerializer.Serialize(requestBody);
                var httpContent = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await client.PostAsync(
                    "https://api.openai.com/v1/chat/completions",
                    httpContent
                );

                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    throw new Exception($"OpenAI API error: {response.StatusCode} - {errorContent}");
                }

                var jsonString = await response.Content.ReadAsStringAsync();
                var result = JsonSerializer.Deserialize<OpenAIResponse>(jsonString, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                return result?.choices?.FirstOrDefault()?.message?.content 
                    ?? "Xin lỗi, tôi không thể trả lời câu hỏi này. Vui lòng thử lại sau.";
            }
            catch (Exception ex)
            {
                throw new Exception($"Error calling OpenAI API: {ex.Message}", ex);
            }
        }

        // Generate Gemini response
        private async Task<string> GenerateGeminiResponseAsync(string userMessage, string context)
        {
            var apiKey = _configuration["AI:Gemini:ApiKey"];
            if (string.IsNullOrWhiteSpace(apiKey))
            {
                return "Xin lỗi, AI service chưa được cấu hình. Vui lòng liên hệ admin.";
            }

            try
            {
                var client = _httpClientFactory.CreateClient();
                client.Timeout = TimeSpan.FromSeconds(30);

                // Build system prompt with context
                var systemPrompt = $@"Bạn là NakiFood AI Assistant - trợ lý AI của cửa hàng thức ăn nhanh NakiFood.

NHIỆM VỤ:
- Luôn trả lời bằng tiếng Việt
- Luôn thân thiện và nhiệt tình
- Khi người dùng hỏi về sản phẩm, hãy gợi ý các món dựa trên dữ liệu trong cơ sở dữ liệu
- Nếu người dùng hỏi về giá, hãy tham khảo thông tin giá trong dữ liệu
- Nếu người dùng hỏi về khuyến mãi, hãy tham khảo các khuyến mãi hiện tại

DỮ LIỆU CƠ SỞ DỮ LIỆU:
{context}

HƯỚNG DẪN:
- Khi người dùng hỏi về menu hoặc món ăn, hãy liệt kê một số món phổ biến từ danh sách trên
- Khi người dùng hỏi về khuyến mãi, hãy thông báo các chương trình khuyến mãi hiện tại
- Khi người dùng hỏi về giá, hãy cung cấp thông tin giá từ dữ liệu
- Nếu không có thông tin trong dữ liệu, hãy trả lời một cách chung chung nhưng vẫn hữu ích
- Luôn khuyến khích người dùng xem chi tiết tại trang web của chúng tôi

Hãy trả lời câu hỏi của người dùng một cách tự nhiên và hữu ích.";

                var fullPrompt = $"{systemPrompt}\n\nNgười dùng hỏi: {userMessage}\n\nHãy trả lời:";

                var requestBody = new
                {
                    contents = new[]
                    {
                        new
                        {
                            parts = new[]
                            {
                                new { text = fullPrompt }
                            }
                        }
                    },
                    generationConfig = new
                    {
                        temperature = 0.7,
                        topK = 40,
                        topP = 0.95,
                        maxOutputTokens = 1024
                    }
                };

                var jsonContent = JsonSerializer.Serialize(requestBody);
                var httpContent = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                var response = await client.PostAsync(
                    $"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={apiKey}",
                    httpContent
                );

                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    throw new Exception($"Gemini API error: {response.StatusCode} - {errorContent}");
                }

                var jsonString = await response.Content.ReadAsStringAsync();
                var result = JsonSerializer.Deserialize<GeminiResponse>(jsonString, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                return result?.candidates?.FirstOrDefault()?.content?.parts?.FirstOrDefault()?.text
                    ?? "Xin lỗi, tôi không thể trả lời câu hỏi này. Vui lòng thử lại sau.";
            }
            catch (Exception ex)
            {
                throw new Exception($"Error calling Gemini API: {ex.Message}", ex);
            }
        }

        // Request/Response Models
        public class AIChatRequest
        {
            public string Message { get; set; } = string.Empty;
            public int? UserId { get; set; }
        }

        // OpenAI Response Models
        private class OpenAIResponse
        {
            public List<OpenAIChoice>? choices { get; set; }
        }

        private class OpenAIChoice
        {
            public OpenAIMessage? message { get; set; }
        }

        private class OpenAIMessage
        {
            public string? content { get; set; }
        }

        // Gemini Response Models
        private class GeminiResponse
        {
            public List<GeminiCandidate>? candidates { get; set; }
        }

        private class GeminiCandidate
        {
            public GeminiContent? content { get; set; }
        }

        private class GeminiContent
        {
            public List<GeminiPart>? parts { get; set; }
        }

        private class GeminiPart
        {
            public string? text { get; set; }
        }
    }
}

