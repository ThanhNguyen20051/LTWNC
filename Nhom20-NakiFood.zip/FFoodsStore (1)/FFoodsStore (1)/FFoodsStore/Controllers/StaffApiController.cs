using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using FFoodsStore.ViewModels;
using static FFoodsStore.Models.OrderStatus;
using static FFoodsStore.Models.OrderStatusHelper;

namespace FFoodsStore.Controllers
{
    [ApiController]
    [Route("api/staff")]
    public class StaffApiController : ControllerBase
    {
        private readonly StoreDbContext _context;

        public StaffApiController(StoreDbContext context)
        {
            _context = context;
        }

        // GET: api/staff/orders?status=pending
        [HttpGet("orders")]
        public async Task<IActionResult> GetOrders([FromQuery] string? status = null)
        {
            var query = _context.Orders
                .Where(o => (o.IsDeleted == null || o.IsDeleted == false));

            if (!string.IsNullOrEmpty(status))
            {
                var statusInt = status switch
                {
                    "pending" => (int)OrderStatus.Pending,
                    "confirmed" => (int)OrderStatus.Confirmed,
                    "in-progress" => (int)OrderStatus.InProgress,
                    "preparing" => (int)OrderStatus.Preparing,
                    "ready" => (int)OrderStatus.Ready,
                    "delivering" => (int)OrderStatus.Delivering,
                    "shipping" => (int)OrderStatus.Shipping,
                    _ => (int?)null
                };

                if (statusInt.HasValue)
                {
                    query = query.Where(o => o.Status == statusInt.Value);
                }
            }

            var orders = await query
                .OrderByDescending(o => o.CreateDate)
                .ToListAsync();

            var orderVMs = orders.Select(o => new
            {
                id = o.ID,
                orderCode = o.OrderCode ?? "",
                customerName = o.CustomerName ?? "",
                phoneNumber = o.PhoneNumber ?? "",
                address = o.Address ?? "",
                status = o.Status,
                statusName = GetStatusName(o.Status),
                paymentMethod = o.PaymentMethod ?? "cod",
                createDate = o.CreateDate,
                total = _context.OrderDetails
                    .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                    .Sum(od => od.TotalMoney ?? 0)
            }).ToList();

            return Ok(new { orders = orderVMs });
        }

        // GET: api/staff/orders/{id}
        [HttpGet("orders/{id}")]
        public async Task<IActionResult> GetOrderDetail(int id)
        {
            var order = await _context.Orders
                .FirstOrDefaultAsync(o => o.ID == id && (o.IsDeleted == null || o.IsDeleted == false));

            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            var orderDetails = await _context.OrderDetails
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.Product)
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.ProductSize)
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.Product!)
                        .ThenInclude(p => p.ProductImages)
                .Where(od => od.OrderID == id && (od.IsDelete == null || od.IsDelete == false))
                .ToListAsync();

            var toppings = await _context.OrderDetailsToppings
                .Include(odt => odt.Topping)
                .Where(odt => orderDetails.Select(od => od.ID).Contains(odt.OrderDetailsID))
                .ToListAsync();

            var items = orderDetails.Select(od => new
            {
                id = od.ID,
                productName = od.ProductDetail?.Product?.ProductName ?? "",
                sizeName = od.ProductDetail?.ProductSize?.SizeName ?? "",
                quantity = od.Quantity ?? 0,
                price = od.ProductDetail?.Price ?? 0,
                totalMoney = od.TotalMoney ?? 0,
                imageUrl = od.ProductDetail?.Product?.ProductImages?
                    .FirstOrDefault(img => img.IsDelete != true)?.ImageUrl ?? "",
                toppings = toppings
                    .Where(t => t.OrderDetailsID == od.ID)
                    .Select(t => t.Topping?.ToppingName ?? "")
                    .ToList()
            }).ToList();

            return Ok(new
            {
                id = order.ID,
                orderCode = order.OrderCode ?? "",
                customerName = order.CustomerName ?? "",
                phoneNumber = order.PhoneNumber ?? "",
                address = order.Address ?? "",
                status = order.Status,
                statusName = GetStatusName(order.Status),
                paymentMethod = order.PaymentMethod ?? "cod",
                createDate = order.CreateDate,
                total = orderDetails.Sum(od => od.TotalMoney ?? 0),
                items = items
            });
        }

        // POST: api/staff/orders/{id}/confirm
        [HttpPost("orders/{id}/confirm")]
        public async Task<IActionResult> ConfirmOrder(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            if (order.Status != (int)OrderStatus.Pending)
            {
                return BadRequest(new { message = "Chỉ có thể xác nhận đơn hàng đang chờ xác nhận" });
            }

            order.Status = (int)OrderStatus.Confirmed;
            order.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Xác nhận đơn hàng thành công", orderId = order.ID });
        }

        // POST: api/staff/orders/{id}/reject
        [HttpPost("orders/{id}/reject")]
        public async Task<IActionResult> RejectOrder(int id, [FromBody] RejectOrderRequest request)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            if (order.Status != (int)OrderStatus.Pending)
            {
                return BadRequest(new { message = "Chỉ có thể từ chối đơn hàng đang chờ xác nhận" });
            }

            order.Status = (int)OrderStatus.Canceled;
            order.ReasonCancel = request.Reason ?? "Đơn hàng bị từ chối bởi nhân viên";
            order.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Từ chối đơn hàng thành công", orderId = order.ID });
        }

        // POST: api/staff/orders/{id}/start-preparing
        [HttpPost("orders/{id}/start-preparing")]
        public async Task<IActionResult> StartPreparing(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            if (order.Status != (int)OrderStatus.Confirmed && order.Status != (int)OrderStatus.Preparing)
            {
                return BadRequest(new { message = "Chỉ có thể bắt đầu chế biến đơn hàng đã xác nhận" });
            }

            order.Status = (int)OrderStatus.InProgress;
            order.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Bắt đầu chế biến đơn hàng", orderId = order.ID });
        }

        // POST: api/staff/kitchen/complete-item/{orderDetailId}
        [HttpPost("kitchen/complete-item/{orderDetailId}")]
        public async Task<IActionResult> CompleteKitchenItem(int orderDetailId)
        {
            var orderDetail = await _context.OrderDetails
                .Include(od => od.ProductDetail)
                .FirstOrDefaultAsync(od => od.ID == orderDetailId && (od.IsDelete == null || od.IsDelete == false));

            if (orderDetail == null)
            {
                return NotFound(new { message = "Không tìm thấy chi tiết đơn hàng" });
            }

            var order = await _context.Orders.FindAsync(orderDetail.OrderID);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            // Mark this specific order detail as completed by setting UpdatedDate
            // This will be used to filter completed items from kitchen queue
            orderDetail.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            // Check if all items in this order are completed
            // Get all order details for this order (excluding shipping fee - ProductDetailID is null)
            var allOrderDetails = await _context.OrderDetails
                .Where(od => od.OrderID == order.ID 
                    && (od.IsDelete == null || od.IsDelete == false)
                    && od.ProductDetailID != null) // Exclude shipping fee
                .ToListAsync();

            // Count items that are NOT completed (UpdatedDate is null or very old)
            // An item is considered completed if UpdatedDate is recent (within last minute)
            var completedItems = allOrderDetails.Count(od => 
                od.UpdatedDate.HasValue && 
                (DateTime.Now - od.UpdatedDate.Value).TotalMinutes < 1);
            
            var totalItems = allOrderDetails.Count;
            
            // Only mark order as Ready if ALL items are completed
            if (completedItems >= totalItems && totalItems > 0)
            {
                if (order.Status == (int)OrderStatus.InProgress || order.Status == (int)OrderStatus.Preparing)
                {
                    order.Status = (int)OrderStatus.Ready;
                    order.UpdatedDate = DateTime.Now;
                    await _context.SaveChangesAsync();
                }
            }

            return Ok(new { 
                message = "Hoàn thành món thành công", 
                orderId = order.ID,
                orderDetailId = orderDetail.ID,
                completedItems = completedItems,
                totalItems = totalItems,
                allCompleted = completedItems >= totalItems
            });
        }

        // POST: api/staff/orders/{id}/ready
        [HttpPost("orders/{id}/ready")]
        public async Task<IActionResult> MarkReady(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            if (order.Status != (int)OrderStatus.InProgress && order.Status != (int)OrderStatus.Preparing)
            {
                return BadRequest(new { message = "Chỉ có thể đánh dấu sẵn sàng cho đơn hàng đang chế biến" });
            }

            order.Status = (int)OrderStatus.Ready;
            order.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Đánh dấu đơn hàng sẵn sàng thành công", orderId = order.ID });
        }

        // POST: api/staff/orders/{id}/assign-shipper
        [HttpPost("orders/{id}/assign-shipper")]
        public async Task<IActionResult> AssignShipper(int id, [FromBody] AssignShipperRequest request)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            if (order.Status != (int)OrderStatus.Ready
                && order.Status != (int)OrderStatus.Confirmed)
            {
                return BadRequest(new { message = "Chỉ có thể giao cho shipper khi đơn hàng đã sẵn sàng hoặc đã xác nhận" });
            }

            // Change status to Assigned so shipper can see and accept
            order.Status = (int)OrderStatus.Assigned;
            order.UpdatedDate = DateTime.Now;
            // TODO: Store shipper info in Order model or separate table
            await _context.SaveChangesAsync();

            return Ok(new { message = "Giao đơn hàng cho shipper thành công", orderId = order.ID });
        }

        // POST: api/staff/orders/{id}/complete
        [HttpPost("orders/{id}/complete")]
        public async Task<IActionResult> CompleteOrder(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            if (order.Status != (int)OrderStatus.Delivering && order.Status != (int)OrderStatus.Ready)
            {
                return BadRequest(new { message = "Chỉ có thể hoàn thành đơn hàng đang giao hoặc đã sẵn sàng" });
            }

            order.Status = (int)OrderStatus.Completed;
            order.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Hoàn thành đơn hàng thành công", orderId = order.ID });
        }

        // POST: api/staff/orders/{id}/mark-paid
        [HttpPost("orders/{id}/mark-paid")]
        public async Task<IActionResult> MarkPaid(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            // TODO: Add IsPaid field to Order model or use PaymentMethod status
            order.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Đánh dấu đã thanh toán thành công", orderId = order.ID });
        }

        // GET: api/staff/kitchen/queue
        [HttpGet("kitchen/queue")]
        public async Task<IActionResult> GetKitchenQueue()
        {
            var orders = await _context.Orders
                .Where(o => (o.Status == (int)OrderStatus.Confirmed 
                    || o.Status == (int)OrderStatus.Preparing 
                    || o.Status == (int)OrderStatus.InProgress)
                    && (o.IsDeleted == null || o.IsDeleted == false))
                .OrderBy(o => o.CreateDate)
                .ToListAsync();

            var kitchenItems = new List<object>();

            foreach (var order in orders)
            {
                var orderDetails = await _context.OrderDetails
                    .Include(od => od.ProductDetail!)
                        .ThenInclude(pd => pd.Product)
                    .Include(od => od.ProductDetail!)
                        .ThenInclude(pd => pd.ProductSize)
                    .Where(od => od.OrderID == order.ID 
                        && (od.IsDelete == null || od.IsDelete == false)
                        && od.ProductDetailID != null) // Exclude shipping fee
                    .ToListAsync();

                foreach (var od in orderDetails)
                {
                    // Filter out completed items (UpdatedDate is recent, meaning it was just completed)
                    // An item is considered completed if UpdatedDate is within last minute
                    if (od.UpdatedDate.HasValue && (DateTime.Now - od.UpdatedDate.Value).TotalMinutes < 1)
                    {
                        continue; // Skip completed items
                    }

                    var timeDiff = DateTime.Now - (order.CreateDate ?? DateTime.Now);
                    var isUrgent = timeDiff.TotalMinutes > 30; // Urgent if older than 30 minutes

                    kitchenItems.Add(new
                    {
                        orderId = order.ID,
                        orderCode = order.OrderCode ?? "",
                        orderDetailId = od.ID,
                        productName = od.ProductDetail?.Product?.ProductName ?? "",
                        sizeName = od.ProductDetail?.ProductSize?.SizeName ?? "",
                        quantity = od.Quantity ?? 0,
                        createDate = order.CreateDate,
                        status = order.Status,
                        isUrgent = isUrgent,
                        minutesWaiting = (int)timeDiff.TotalMinutes
                    });
                }
            }

            return Ok(new { items = kitchenItems });
        }

        // POST: api/staff/orders/create-dine-in
        [HttpPost("orders/create-dine-in")]
        public async Task<IActionResult> CreateDineInOrder([FromBody] CreateDineInOrderRequest request)
        {
            try
            {
                if (request.AccountId <= 0)
                {
                    return Unauthorized(new { message = "Vui lòng đăng nhập!" });
                }

                if (string.IsNullOrWhiteSpace(request.CustomerName))
                {
                    return BadRequest(new { message = "Vui lòng nhập tên khách hàng!" });
                }

                // Số điện thoại là optional cho đơn tại quầy
                // if (string.IsNullOrWhiteSpace(request.PhoneNumber))
                // {
                //     return BadRequest(new { message = "Vui lòng nhập số điện thoại!" });
                // }

                if (request.Items == null || request.Items.Count == 0)
                {
                    return BadRequest(new { message = "Giỏ hàng trống!" });
                }

                // Validate items
                decimal calculatedTotal = 0;
                foreach (var item in request.Items)
                {
                    var productDetail = await _context.ProductDetails
                        .Include(pd => pd.Product)
                        .FirstOrDefaultAsync(pd => pd.ID == item.ProductDetailId && (pd.IsDelete == null || pd.IsDelete == false));

                    if (productDetail == null)
                    {
                        return BadRequest(new { message = $"Không tìm thấy sản phẩm với ID: {item.ProductDetailId}" });
                    }

                    var price = productDetail.Price ?? 0;
                    var quantity = item.Quantity > 0 ? item.Quantity : 1;
                    calculatedTotal += price * quantity;
                }

                if (calculatedTotal <= 0)
                {
                    return BadRequest(new { message = "Tổng tiền đơn hàng không hợp lệ!" });
                }

                // Create order code
                var orderCode = "ORD" + DateTime.Now.ToString("yyyyMMddHHmmss") + request.AccountId;

                // Create order
                var order = new Order
                {
                    AccountID = request.AccountId,
                    OrderCode = orderCode,
                    CustomerName = request.CustomerName.Trim(),
                    PhoneNumber = string.IsNullOrWhiteSpace(request.PhoneNumber) ? null : request.PhoneNumber.Trim(),
                    Address = request.Address?.Trim() ?? "Tại quầy",
                    PaymentMethod = "cod", // Dine-in orders are COD
                    Status = (int)OrderStatus.Confirmed, // Auto-confirm dine-in orders
                    CreateDate = DateTime.Now,
                    CreateBy = request.AccountId.ToString(),
                    IsDeleted = false
                };

                _context.Orders.Add(order);
                await _context.SaveChangesAsync();

                // Create order details
                foreach (var item in request.Items)
                {
                    var productDetail = await _context.ProductDetails
                        .FirstOrDefaultAsync(pd => pd.ID == item.ProductDetailId);

                    if (productDetail == null) continue;

                    var price = productDetail.Price ?? 0;
                    var quantity = item.Quantity > 0 ? item.Quantity : 1;
                    var totalMoney = price * quantity;

                    var orderDetail = new OrderDetail
                    {
                        OrderID = order.ID,
                        ProductDetailID = item.ProductDetailId,
                        Quantity = quantity,
                        TotalMoney = totalMoney,
                        CreatedDate = DateTime.Now,
                        CreatedBy = request.AccountId.ToString(),
                        IsDelete = false
                    };

                    _context.OrderDetails.Add(orderDetail);
                    await _context.SaveChangesAsync();

                    // Add toppings if any
                    if (item.Toppings != null && item.Toppings.Count > 0)
                    {
                        foreach (var toppingId in item.Toppings)
                        {
                            var topping = await _context.Toppings
                                .FirstOrDefaultAsync(t => t.ID == toppingId && !t.IsDelete);

                            if (topping != null)
                            {
                                var toppingPrice = topping.ToppingPrice ?? 0;
                                
                                var orderDetailTopping = new OrderDetailsTopping
                                {
                                    OrderDetailsID = orderDetail.ID,
                                    ToppingID = toppingId,
                                    ToppingPrice = toppingPrice,
                                    CreatedDate = DateTime.Now,
                                    CreatedBy = request.AccountId.ToString()
                                };

                                _context.OrderDetailsToppings.Add(orderDetailTopping);
                                
                                // Update order detail total
                                orderDetail.TotalMoney = (orderDetail.TotalMoney ?? 0) + toppingPrice;
                            }
                        }
                        await _context.SaveChangesAsync();
                    }
                }

                // Add shipping fee (for dine-in, can be 0 or small fee)
                var shippingFee = 0m; // Dine-in usually has no shipping fee
                if (shippingFee > 0)
                {
                    var shippingDetail = new OrderDetail
                    {
                        OrderID = order.ID,
                        ProductDetailID = null,
                        Quantity = 1,
                        TotalMoney = shippingFee,
                        CreatedDate = DateTime.Now,
                        CreatedBy = request.AccountId.ToString(),
                        IsDelete = false
                    };
                    _context.OrderDetails.Add(shippingDetail);
                    await _context.SaveChangesAsync();
                }

                // Verify total
                var orderTotalFromDetails = await _context.OrderDetails
                    .Where(od => od.OrderID == order.ID && (od.IsDelete == null || od.IsDelete == false))
                    .SumAsync(od => od.TotalMoney ?? 0);

                return Ok(new
                {
                    success = true,
                    orderId = order.ID,
                    orderCode = order.OrderCode,
                    total = orderTotalFromDetails,
                    message = "Tạo đơn hàng tại quầy thành công!"
                });
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[STAFF API] CreateDineInOrder error: {ex.Message}");
                return StatusCode(500, new { message = $"Lỗi server: {ex.Message}" });
            }
        }

        // GET: api/staff/dashboard/stats
        [HttpGet("dashboard/stats")]
        public async Task<IActionResult> GetDashboardStats()
        {
            var stats = new
            {
                pendingOrders = await _context.Orders
                    .CountAsync(o => o.Status == (int)OrderStatus.Pending && (o.IsDeleted == null || o.IsDeleted == false)),
                
                inProgressOrders = await _context.Orders
                    .CountAsync(o => (o.Status == (int)OrderStatus.InProgress || o.Status == (int)OrderStatus.Preparing) 
                        && (o.IsDeleted == null || o.IsDeleted == false)),
                
                readyOrders = await _context.Orders
                    .CountAsync(o => o.Status == (int)OrderStatus.Ready && (o.IsDeleted == null || o.IsDeleted == false)),
                
                deliveringOrders = await _context.Orders
                    .CountAsync(o => (o.Status == (int)OrderStatus.Delivering || o.Status == (int)OrderStatus.Shipping) 
                        && (o.IsDeleted == null || o.IsDeleted == false)),
                
                lowStockItems = 0 // TODO: Implement inventory tracking
            };

            return Ok(stats);
        }

        // Request Models
        public class RejectOrderRequest
        {
            public string? Reason { get; set; }
        }

        public class AssignShipperRequest
        {
            public string ShipperName { get; set; } = "";
            public string ShipperPhone { get; set; } = "";
        }

        public class CreateDineInOrderRequest
        {
            public int AccountId { get; set; }
            public string CustomerName { get; set; } = "";
            public string PhoneNumber { get; set; } = "";
            public string? Address { get; set; }
            public List<DineInOrderItem> Items { get; set; } = new();
        }

        public class DineInOrderItem
        {
            public int ProductDetailId { get; set; }
            public int Quantity { get; set; }
            public List<int> Toppings { get; set; } = new();
        }
    }
}

