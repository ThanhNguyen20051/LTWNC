using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using static FFoodsStore.Models.OrderStatus;
using static FFoodsStore.Models.OrderStatusHelper;

namespace FFoodsStore.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ShipperApiController : ControllerBase
    {
        private readonly StoreDbContext _context;

        public ShipperApiController(StoreDbContext context)
        {
            _context = context;
        }

        // GET: api/shipper/orders?status=assigned
        [HttpGet("orders")]
        public async Task<IActionResult> GetOrders([FromQuery] string? status = null)
        {
            var query = _context.Orders
                .Where(o => (o.IsDeleted == null || o.IsDeleted == false)
                    // Loại bỏ đơn tại quầy - chỉ lấy đơn cần giao hàng
                    && (o.Address == null || (!EF.Functions.Like(o.Address, "%Tại quầy%") && o.Address.ToLower() != "tại quầy")));

            if (!string.IsNullOrEmpty(status))
            {
                var statusInt = status switch
                {
                    "assigned" => (int)OrderStatus.Assigned,
                    "accepted" => (int)OrderStatus.Accepted,
                    "pickedup" => (int)OrderStatus.PickedUp,
                    "ontheway" => (int)OrderStatus.OnTheWay,
                    "arrived" => (int)OrderStatus.Arrived,
                    "delivering" => (int)OrderStatus.Delivering,
                    "delivered" => (int)OrderStatus.Delivered,
                    "failed" => (int)OrderStatus.DeliveryFailed,
                    _ => (int?)null
                };

                if (statusInt.HasValue)
                {
                    query = query.Where(o => o.Status == statusInt.Value);
                }
            }
            else
            {
                query = query.Where(o => o.Status == (int)OrderStatus.Assigned
                    || o.Status == (int)OrderStatus.Accepted
                    || o.Status == (int)OrderStatus.PickedUp
                    || o.Status == (int)OrderStatus.OnTheWay
                    || o.Status == (int)OrderStatus.Arrived
                    || o.Status == (int)OrderStatus.Delivering
                    || o.Status == (int)OrderStatus.Ready);
            }

            var orders = await query
                .OrderByDescending(o => o.CreateDate)
                .ToListAsync();

            var orderVMs = orders.Select(o => new
            {
                id = o.ID,
                orderCode = o.OrderCode ?? "",
                customerName = o.CustomerName ?? "",
                phoneNumber = o.PhoneNumber ?? "",
                address = o.Address ?? "",
                status = o.Status,
                statusName = GetStatusName(o.Status),
                paymentMethod = o.PaymentMethod ?? "cod",
                isPaid = o.PaymentMethod != "cod",
                createDate = o.CreateDate,
                total = _context.OrderDetails
                    .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                    .Sum(od => od.TotalMoney ?? 0),
                codAmount = o.PaymentMethod == "cod"
                    ? _context.OrderDetails
                        .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                        .Sum(od => od.TotalMoney ?? 0)
                    : 0
            }).ToList();

            return Ok(new { orders = orderVMs });
        }

        // GET: api/shipper/orders/{id}
        [HttpGet("orders/{id}")]
        public async Task<IActionResult> GetOrderDetail(int id)
        {
            var order = await _context.Orders
                .FirstOrDefaultAsync(o => o.ID == id && (o.IsDeleted == null || o.IsDeleted == false));

            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            var orderDetails = await _context.OrderDetails
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.Product)
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.ProductSize)
                .Where(od => od.OrderID == id && (od.IsDelete == null || od.IsDelete == false))
                .ToListAsync();

            var items = orderDetails.Select(od => new
            {
                id = od.ID,
                productName = od.ProductDetail?.Product?.ProductName ?? "",
                sizeName = od.ProductDetail?.ProductSize?.SizeName ?? "",
                quantity = od.Quantity ?? 0,
                price = od.ProductDetail?.Price ?? 0,
                totalMoney = od.TotalMoney ?? 0
            }).ToList();

            return Ok(new
            {
                id = order.ID,
                orderCode = order.OrderCode ?? "",
                customerName = order.CustomerName ?? "",
                phoneNumber = order.PhoneNumber ?? "",
                address = order.Address ?? "",
                status = order.Status,
                statusName = GetStatusName(order.Status),
                paymentMethod = order.PaymentMethod ?? "cod",
                isPaid = order.PaymentMethod != "cod",
                createDate = order.CreateDate,
                total = orderDetails.Sum(od => od.TotalMoney ?? 0),
                codAmount = order.PaymentMethod == "cod"
                    ? orderDetails.Sum(od => od.TotalMoney ?? 0)
                    : 0,
                items = items,
                storeAddress = "828 Sư Vạn Hạnh, Phường Hòa Hưng, TP. Hồ Chí Minh",
                storePhone = "0123 456 789"
            });
        }

        // POST: api/shipper/orders/{id}/accept
        [HttpPost("orders/{id}/accept")]
        public async Task<IActionResult> AcceptOrder(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            if (order.Status != (int)OrderStatus.Assigned && order.Status != (int)OrderStatus.Ready)
            {
                return BadRequest(new { message = "Chỉ có thể chấp nhận đơn hàng đã được gán" });
            }

            order.Status = (int)OrderStatus.Accepted;
            order.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Chấp nhận đơn hàng thành công", orderId = order.ID });
        }

        // POST: api/shipper/orders/{id}/reject
        [HttpPost("orders/{id}/reject")]
        public async Task<IActionResult> RejectOrder(int id, [FromBody] RejectOrderRequest request)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            if (order.Status != (int)OrderStatus.Assigned && order.Status != (int)OrderStatus.Ready)
            {
                return BadRequest(new { message = "Chỉ có thể từ chối đơn hàng đã được gán" });
            }

            // Reject order - change status back to Ready so staff can assign to another shipper
            order.Status = (int)OrderStatus.Ready;
            order.ReasonCancel = request.Reason ?? "Shipper từ chối đơn hàng";
            order.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Từ chối đơn hàng thành công", orderId = order.ID });
        }

        // POST: api/shipper/orders/{id}/pickup
        [HttpPost("orders/{id}/pickup")]
        public async Task<IActionResult> PickupOrder(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            if (order.Status != (int)OrderStatus.Accepted)
            {
                return BadRequest(new { message = "Chỉ có thể lấy hàng sau khi đã chấp nhận đơn" });
            }

            order.Status = (int)OrderStatus.PickedUp;
            order.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Đã lấy hàng thành công", orderId = order.ID });
        }

        // POST: api/shipper/orders/{id}/on-the-way
        [HttpPost("orders/{id}/on-the-way")]
        public async Task<IActionResult> OnTheWay(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            if (order.Status != (int)OrderStatus.PickedUp)
            {
                return BadRequest(new { message = "Chỉ có thể đánh dấu 'Đang trên đường' sau khi đã lấy hàng" });
            }

            order.Status = (int)OrderStatus.OnTheWay;
            order.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Đã đánh dấu đang trên đường", orderId = order.ID });
        }

        // POST: api/shipper/orders/{id}/arrived
        [HttpPost("orders/{id}/arrived")]
        public async Task<IActionResult> Arrived(int id)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            if (order.Status != (int)OrderStatus.OnTheWay && order.Status != (int)OrderStatus.PickedUp)
            {
                return BadRequest(new { message = "Chỉ có thể đánh dấu 'Đã đến nơi' khi đang trên đường" });
            }

            order.Status = (int)OrderStatus.Arrived;
            order.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Đã đánh dấu đến nơi", orderId = order.ID });
        }

        // POST: api/shipper/orders/{id}/deliver
        [HttpPost("orders/{id}/deliver")]
        public async Task<IActionResult> DeliverOrder(int id, [FromBody] DeliverOrderRequest? request = null)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            if (order.Status != (int)OrderStatus.Arrived 
                && order.Status != (int)OrderStatus.OnTheWay
                && order.Status != (int)OrderStatus.PickedUp)
            {
                return BadRequest(new { message = "Chỉ có thể giao hàng khi đã đến nơi hoặc đang trên đường" });
            }

            // TODO: Validate OTP if provided
            if (request != null && !string.IsNullOrEmpty(request.Otp))
            {
                // Validate OTP logic here
            }

            order.Status = (int)OrderStatus.Delivered;
            order.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Giao hàng thành công", orderId = order.ID });
        }

        // POST: api/shipper/orders/{id}/fail
        [HttpPost("orders/{id}/fail")]
        public async Task<IActionResult> FailDelivery(int id, [FromBody] FailDeliveryRequest request)
        {
            var order = await _context.Orders.FindAsync(id);
            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            if (order.Status == (int)OrderStatus.Delivered || order.Status == (int)OrderStatus.Completed)
            {
                return BadRequest(new { message = "Không thể đánh dấu thất bại cho đơn đã giao thành công" });
            }

            order.Status = (int)OrderStatus.DeliveryFailed;
            order.ReasonCancel = request.Reason ?? "Giao hàng thất bại";
            order.UpdatedDate = DateTime.Now;
            await _context.SaveChangesAsync();

            return Ok(new { message = "Đánh dấu giao hàng thất bại thành công", orderId = order.ID });
        }

        // GET: api/shipper/dashboard/stats
        [HttpGet("dashboard/stats")]
        public async Task<IActionResult> GetDashboardStats()
        {
            var today = DateTime.Today;
            var tomorrow = today.AddDays(1);

            var stats = new
            {
                assignedOrders = await _context.Orders
                    .CountAsync(o => (o.Status == (int)OrderStatus.Assigned || o.Status == (int)OrderStatus.Ready)
                        && (o.IsDeleted == null || o.IsDeleted == false)),
                
                deliveringOrders = await _context.Orders
                    .CountAsync(o => (o.Status == (int)OrderStatus.Accepted
                        || o.Status == (int)OrderStatus.PickedUp
                        || o.Status == (int)OrderStatus.OnTheWay
                        || o.Status == (int)OrderStatus.Arrived
                        || o.Status == (int)OrderStatus.Delivering)
                        && (o.IsDeleted == null || o.IsDeleted == false)),
                
                completedToday = await _context.Orders
                    .CountAsync(o => (o.Status == (int)OrderStatus.Delivered || o.Status == (int)OrderStatus.Completed)
                        && o.UpdatedDate >= today
                        && o.UpdatedDate < tomorrow
                        && (o.IsDeleted == null || o.IsDeleted == false)),
                
                failedToday = await _context.Orders
                    .CountAsync(o => (o.Status == (int)OrderStatus.DeliveryFailed || o.Status == (int)OrderStatus.FailedDelivery)
                        && o.UpdatedDate >= today
                        && o.UpdatedDate < tomorrow
                        && (o.IsDeleted == null || o.IsDeleted == false))
            };

            return Ok(stats);
        }

        // POST: api/shipper/toggle-online
        [HttpPost("toggle-online")]
        public IActionResult ToggleOnline([FromBody] ToggleOnlineRequest request)
        {
            // TODO: Save online status to database (create Shipper table or use Account.IsActive)
            return Ok(new { 
                isOnline = request.IsOnline,
                message = request.IsOnline ? "Đã bật chế độ Online" : "Đã tắt chế độ Online"
            });
        }


        // Request Models
        public class RejectOrderRequest
        {
            public string? Reason { get; set; }
        }

        public class DeliverOrderRequest
        {
            public string? Otp { get; set; }
            public string? ImageUrl { get; set; } // Photo confirmation
        }

        public class FailDeliveryRequest
        {
            public string Reason { get; set; } = "";
        }

        public class ToggleOnlineRequest
        {
            public bool IsOnline { get; set; }
        }

        // GET: api/shipper/maps/directions?origin={origin}&destination={destination}
        [HttpGet("maps/directions")]
        public IActionResult GetDirections([FromQuery] string origin, [FromQuery] string destination)
        {
            if (string.IsNullOrEmpty(origin) || string.IsNullOrEmpty(destination))
            {
                return BadRequest(new { message = "Địa chỉ xuất phát và đích không được để trống" });
            }

            // Encode addresses for URL
            var originEncoded = Uri.EscapeDataString(origin);
            var destinationEncoded = Uri.EscapeDataString(destination);

            // Generate multiple map provider URLs
            var googleMapsUrl = $"https://www.google.com/maps/dir/?api=1&origin={originEncoded}&destination={destinationEncoded}";
            var appleMapsUrl = $"https://maps.apple.com/?daddr={destinationEncoded}&saddr={originEncoded}";
            var wazeUrl = $"https://waze.com/ul?q={destinationEncoded}&navigate=yes";

            return Ok(new
            {
                origin = origin,
                destination = destination,
                urls = new
                {
                    googleMaps = googleMapsUrl,
                    appleMaps = appleMapsUrl,
                    waze = wazeUrl
                },
                embedUrl = $"https://www.google.com/maps/embed/v1/directions?key=YOUR_API_KEY&origin={originEncoded}&destination={destinationEncoded}"
            });
        }

        // GET: api/shipper/maps/geocode?address={address}
        [HttpGet("maps/geocode")]
        public IActionResult GeocodeAddress([FromQuery] string address)
        {
            if (string.IsNullOrEmpty(address))
            {
                return BadRequest(new { message = "Địa chỉ không được để trống" });
            }

            // TODO: Implement geocoding using Google Maps Geocoding API or other service
            // For now, return placeholder
            return Ok(new
            {
                address = address,
                latitude = 0,
                longitude = 0,
                formattedAddress = address
            });
        }

        // GET: api/shipper/earnings?mode=daily&date=2025-11-23
        [HttpGet("earnings")]
        public async Task<IActionResult> GetEarnings([FromQuery] string mode = "daily", [FromQuery] DateTime? date = null)
        {
            try
            {
                DateTime startDate, endDate;
                var today = date ?? DateTime.Today;

                if (mode == "daily")
                {
                    startDate = today.Date;
                    endDate = startDate.AddDays(1);
                }
                else if (mode == "weekly")
                {
                    var dayOfWeek = (int)today.DayOfWeek;
                    if (dayOfWeek == 0) dayOfWeek = 7;
                    startDate = today.AddDays(-(dayOfWeek - 1)).Date;
                    endDate = startDate.AddDays(7);
                }
                else // monthly
                {
                    startDate = new DateTime(today.Year, today.Month, 1).Date;
                    endDate = startDate.AddMonths(1);
                }

                // Lấy các đơn đã giao thành công (Delivered hoặc Completed)
                var orders = await _context.Orders
                    .Where(o => (o.Status == (int)OrderStatus.Delivered || o.Status == (int)OrderStatus.Completed)
                        && o.UpdatedDate >= startDate
                        && o.UpdatedDate < endDate
                        && (o.IsDeleted == null || o.IsDeleted == false)
                        && (o.Address == null || (!EF.Functions.Like(o.Address, "%Tại quầy%") && o.Address.ToLower() != "tại quầy")))
                    .ToListAsync();

                var orderIds = orders.Select(o => o.ID).ToList();

                // Lấy shipping fee từ OrderDetail (ProductDetailID = null là shipping fee)
                Dictionary<int, decimal> shippingFees;
                if (orderIds.Any())
                {
                    var shippingDetails = await _context.OrderDetails
                        .Where(od => od.OrderID.HasValue && orderIds.Contains(od.OrderID.Value)
                            && od.ProductDetailID == null // Shipping fee
                            && (od.IsDelete == null || od.IsDelete == false))
                        .ToListAsync();
                    
                    shippingFees = shippingDetails
                        .GroupBy(od => od.OrderID)
                        .ToDictionary(g => g.Key ?? 0, g => g.Sum(od => od.TotalMoney ?? 0));
                }
                else
                {
                    shippingFees = new Dictionary<int, decimal>();
                }

                // Tính tổng tiền ship
                var totalEarnings = shippingFees.Values.Sum();

                // Tính số đơn
                var totalOrders = orders.Count;

                // Tính số km (ước lượng: mỗi đơn trung bình 5km - có thể cải thiện sau)
                var estimatedKm = totalOrders * 5.0m;

                // Lịch sử từng đơn
                var orderHistory = orders.Select(o => new
                {
                    orderId = o.ID,
                    orderCode = o.OrderCode ?? "",
                    customerName = o.CustomerName ?? "",
                    address = o.Address ?? "",
                    shippingFee = shippingFees.GetValueOrDefault(o.ID, 0),
                    estimatedKm = 5.0m, // Ước lượng
                    deliveryDate = o.UpdatedDate,
                    statusName = GetStatusName(o.Status)
                }).OrderByDescending(x => x.deliveryDate).ToList();

                return Ok(new
                {
                    mode = mode,
                    startDate = startDate.ToString("yyyy-MM-dd"),
                    endDate = endDate.ToString("yyyy-MM-dd"),
                    totalOrders = totalOrders,
                    totalEarnings = totalEarnings,
                    totalKm = estimatedKm,
                    orderHistory = orderHistory
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Lỗi khi lấy dữ liệu doanh thu", error = ex.Message });
            }
        }
    }
}

