// ============================================
// SHIPPER JAVASCRIPT
// ============================================

// Load shipper info
function loadShipperInfo() {
    const user = JSON.parse(localStorage.getItem('user') || '{}');
    
    // Kiểm tra đăng nhập và role shipper
    if (!user || !user.id) {
        alert('Vui lòng đăng nhập!');
        window.location.href = '/AccountView/Login';
        return;
    }
    
    // Cho phép cả admin, staff và shipper truy cập trang shipper
    if (user.role !== 1 && user.role !== 2 && user.role !== 3) {
        alert('Bạn không có quyền truy cập trang shipper!');
        window.location.href = '/Home/Index';
        return;
    }
    
    // Load thông tin shipper (nếu có element)
    const shipperNameEl = document.getElementById('shipper-name');
    if (shipperNameEl && user.fullName) {
        shipperNameEl.textContent = user.fullName;
    }
    
    const shipperAvatarEl = document.querySelector('.shipper-avatar');
    if (shipperAvatarEl && user.avatarUrl) {
        shipperAvatarEl.src = user.avatarUrl;
    }
}

// Logout
function logout() {
    if (confirm('Bạn có chắc muốn đăng xuất?')) {
        localStorage.removeItem('user');
        localStorage.removeItem('role');
        localStorage.removeItem('accountId');
        window.location.href = '/AccountView/Login';
    }
}

// Format currency
function formatCurrency(amount) {
    return new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND'
    }).format(amount || 0);
}

// Format date
function formatDate(dateString) {
    if (!dateString) return '-';
    const date = new Date(dateString);
    return new Intl.DateTimeFormat('vi-VN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    }).format(date);
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    loadShipperInfo();
    
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        }, 5000);
    });
});

