using Microsoft.AspNetCore.Mvc;
using System;

namespace FFoodsStore.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PaymentController : ControllerBase
    {
        // GET: api/payment/methods
        [HttpGet("methods")]
        public IActionResult GetPaymentMethods()
        {
            var methods = new[]
            {
                new
                {
                    code = "cod",
                    name = "Thanh toán khi nhận hàng (COD)",
                    description = "Thanh toán bằng tiền mặt khi nhận hàng",
                    icon = "💵"
                },
                new
                {
                    code = "bank",
                    name = "Thanh toán qua ngân hàng",
                    description = "Chuyển khoản qua QR Code hoặc ngân hàng",
                    icon = "🏦"
                }
            };

            return Ok(new { methods });
        }

        // GET: api/payment/bank-info
        [HttpGet("bank-info")]
        public IActionResult GetBankInfo()
        {
            var bankInfo = new
            {
                bankName = "MBank",
                accountNumber = "076836043",
                accountHolder = "Nguyễn Công Danh",
                branch = "TP. Hồ Chí Minh"
            };

            return Ok(bankInfo);
        }

        // GET: api/payment/qr-code?orderCode=ORD123&amount=100000
        [HttpGet("qr-code")]
        public IActionResult GetQRCode([FromQuery] string orderCode, [FromQuery] decimal amount, [FromQuery] int accountId = 1)
        {
            if (string.IsNullOrEmpty(orderCode))
            {
                orderCode = "FF" + DateTime.Now.ToString("yyyyMMddHHmmss");
            }

            // Tạo dữ liệu QR code
            var qrData = $"FastFood-Payment-{orderCode}-{amount}-{accountId}";
            
            // URL QR code generator API
            var qrCodeUrl = $"https://api.qrserver.com/v1/create-qr-code/?size=250x250&data={Uri.EscapeDataString(qrData)}";

            return Ok(new
            {
                qrCodeUrl,
                qrData,
                orderCode,
                transferContent = orderCode
            });
        }
    }
}

