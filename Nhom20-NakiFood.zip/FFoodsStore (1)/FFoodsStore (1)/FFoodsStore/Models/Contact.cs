using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace FFoodsStore.Models
{
    [Table("Contact")]
    public class Contact
    {
        [Key]
        public int ID { get; set; }

        [Required]
        [StringLength(250)]
        [Display(Name = "Tên")]
        public string Name { get; set; } = string.Empty;

        [Required]
        [StringLength(250)]
        [EmailAddress]
        [Display(Name = "Email")]
        public string Email { get; set; } = string.Empty;

        [StringLength(250)]
        [Display(Name = "Số điện thoại")]
        public string? PhoneNumber { get; set; }

        [StringLength(500)]
        [Display(Name = "Địa chỉ")]
        public string? Address { get; set; }

        [Required]
        [Display(Name = "Nội dung")]
        public string Content { get; set; } = string.Empty;

        [Display(Name = "Trạng thái")] // 0: Chưa đọc, 1: Đã đọc, 2: Đã phản hồi
        public int Status { get; set; } = 0;

        [Display(Name = "Ngày tạo")]
        public DateTime? CreatedDate { get; set; } = DateTime.Now;

        [StringLength(150)]
        [Display(Name = "Người tạo")]
        public string? CreatedBy { get; set; }

        [Display(Name = "Ngày cập nhật")]
        public DateTime? UpdatedDate { get; set; }

        [StringLength(150)]
        [Display(Name = "Người cập nhật")]
        public string? UpdatedBy { get; set; }

        [Display(Name = "Đã xóa")]
        public bool? IsDelete { get; set; } = false;
    }
}

