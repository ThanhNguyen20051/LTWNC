namespace FFoodsStore.Models
{
    /// <summary>
    /// Enum representing order status values
    /// </summary>
    public enum OrderStatus
    {
        /// <summary>
        /// Chờ xác nhận
        /// </summary>
        Pending = 1,

        /// <summary>
        /// Đã xác nhận
        /// </summary>
        Confirmed = 2,

        /// <summary>
        /// Đang chuẩn bị
        /// </summary>
        Preparing = 3,

        /// <summary>
        /// Đang chế biến (In Progress)
        /// </summary>
        InProgress = 7,

        /// <summary>
        /// Sẵn sàng giao/nhận (Ready)
        /// </summary>
        Ready = 8,

        /// <summary>
        /// Đang giao hàng
        /// </summary>
        Shipping = 4,

        /// <summary>
        /// Đang giao hàng (Delivering)
        /// </summary>
        Delivering = 9,

        /// <summary>
        /// Giao hàng thành công
        /// </summary>
        Completed = 5,

        /// <summary>
        /// Giao hàng thất bại (Khách không nhận hàng)
        /// </summary>
        Failed = 6,

        /// <summary>
        /// Giao hàng thất bại (Failed Delivery)
        /// </summary>
        FailedDelivery = 10,

        /// <summary>
        /// Đã hủy
        /// </summary>
        Canceled = 11,

        /// <summary>
        /// Đã được gán cho shipper (Assigned)
        /// </summary>
        Assigned = 12,

        /// <summary>
        /// Shipper đã chấp nhận đơn (Accepted)
        /// </summary>
        Accepted = 13,

        /// <summary>
        /// Đã lấy hàng tại quán (PickedUp)
        /// </summary>
        PickedUp = 14,

        /// <summary>
        /// Đang trên đường giao (OnTheWay)
        /// </summary>
        OnTheWay = 15,

        /// <summary>
        /// Đã đến nơi (Arrived)
        /// </summary>
        Arrived = 16,

        /// <summary>
        /// Giao thành công (Delivered) - tương đương Completed
        /// </summary>
        Delivered = 17,

        /// <summary>
        /// Giao thất bại (DeliveryFailed) - tương đương FailedDelivery
        /// </summary>
        DeliveryFailed = 18
    }

    /// <summary>
    /// Helper methods for OrderStatus
    /// </summary>
    public static class OrderStatusHelper
    {
        /// <summary>
        /// Get status name in Vietnamese
        /// </summary>
        public static string GetStatusName(int? status)
        {
            return status switch
            {
                (int)OrderStatus.Pending => "Chờ xác nhận",
                (int)OrderStatus.Confirmed => "Đã xác nhận",
                (int)OrderStatus.Preparing => "Đang chuẩn bị",
                (int)OrderStatus.InProgress => "Đang chế biến",
                (int)OrderStatus.Ready => "Sẵn sàng giao/nhận",
                (int)OrderStatus.Shipping => "Đang giao hàng",
                (int)OrderStatus.Delivering => "Đang giao hàng",
                (int)OrderStatus.Completed => "Giao hàng thành công",
                (int)OrderStatus.Failed => "Giao hàng thất bại",
                (int)OrderStatus.FailedDelivery => "Giao hàng thất bại",
                (int)OrderStatus.Canceled => "Đã hủy",
                (int)OrderStatus.Assigned => "Đã được gán",
                (int)OrderStatus.Accepted => "Đã chấp nhận",
                (int)OrderStatus.PickedUp => "Đã lấy hàng",
                (int)OrderStatus.OnTheWay => "Đang trên đường",
                (int)OrderStatus.Arrived => "Đã đến nơi",
                (int)OrderStatus.Delivered => "Giao thành công",
                (int)OrderStatus.DeliveryFailed => "Giao thất bại",
                _ => "Không xác định"
            };
        }

        /// <summary>
        /// Get status badge CSS class
        /// </summary>
        public static string GetStatusBadgeClass(int? status)
        {
            return status switch
            {
                (int)OrderStatus.Pending => "badge-warning",
                (int)OrderStatus.Confirmed => "badge-info",
                (int)OrderStatus.Preparing => "badge-info",
                (int)OrderStatus.InProgress => "badge-primary",
                (int)OrderStatus.Ready => "badge-success",
                (int)OrderStatus.Shipping => "badge-info",
                (int)OrderStatus.Delivering => "badge-info",
                (int)OrderStatus.Completed => "badge-success",
                (int)OrderStatus.Failed => "badge-danger",
                (int)OrderStatus.FailedDelivery => "badge-danger",
                (int)OrderStatus.Canceled => "badge-secondary",
                (int)OrderStatus.Assigned => "badge-warning",
                (int)OrderStatus.Accepted => "badge-info",
                (int)OrderStatus.PickedUp => "badge-primary",
                (int)OrderStatus.OnTheWay => "badge-info",
                (int)OrderStatus.Arrived => "badge-primary",
                (int)OrderStatus.Delivered => "badge-success",
                (int)OrderStatus.DeliveryFailed => "badge-danger",
                _ => "badge-secondary"
            };
        }

        /// <summary>
        /// Get status icon class
        /// </summary>
        public static string GetStatusIcon(int? status)
        {
            return status switch
            {
                (int)OrderStatus.Pending => "fas fa-clock",
                (int)OrderStatus.Confirmed => "fas fa-check-circle",
                (int)OrderStatus.Preparing => "fas fa-utensils",
                (int)OrderStatus.InProgress => "fas fa-spinner fa-spin",
                (int)OrderStatus.Ready => "fas fa-check-double",
                (int)OrderStatus.Shipping => "fas fa-truck",
                (int)OrderStatus.Delivering => "fas fa-truck-moving",
                (int)OrderStatus.Completed => "fas fa-check-circle",
                (int)OrderStatus.Failed => "fas fa-times-circle",
                (int)OrderStatus.FailedDelivery => "fas fa-exclamation-triangle",
                (int)OrderStatus.Canceled => "fas fa-ban",
                (int)OrderStatus.Assigned => "fas fa-user-check",
                (int)OrderStatus.Accepted => "fas fa-hand-paper",
                (int)OrderStatus.PickedUp => "fas fa-shopping-bag",
                (int)OrderStatus.OnTheWay => "fas fa-route",
                (int)OrderStatus.Arrived => "fas fa-map-marker-alt",
                (int)OrderStatus.Delivered => "fas fa-check-circle",
                (int)OrderStatus.DeliveryFailed => "fas fa-times-circle",
                _ => "fas fa-question-circle"
            };
        }

        /// <summary>
        /// Check if status is a final status (Completed, Failed, or Canceled)
        /// </summary>
        public static bool IsFinalStatus(int? status)
        {
            return status == (int)OrderStatus.Completed 
                || status == (int)OrderStatus.Failed 
                || status == (int)OrderStatus.FailedDelivery
                || status == (int)OrderStatus.Canceled
                || status == (int)OrderStatus.Delivered
                || status == (int)OrderStatus.DeliveryFailed;
        }

        /// <summary>
        /// Get all statuses that shipper can work with
        /// </summary>
        public static List<int> GetShipperWorkableStatuses()
        {
            return new List<int>
            {
                (int)OrderStatus.Assigned,
                (int)OrderStatus.Accepted,
                (int)OrderStatus.PickedUp,
                (int)OrderStatus.OnTheWay,
                (int)OrderStatus.Arrived,
                (int)OrderStatus.Delivering,
                (int)OrderStatus.Ready // Ready orders can be assigned to shipper
            };
        }

        /// <summary>
        /// Get all statuses that staff can work with
        /// </summary>
        public static List<int> GetStaffWorkableStatuses()
        {
            return new List<int>
            {
                (int)OrderStatus.Pending,
                (int)OrderStatus.Confirmed,
                (int)OrderStatus.Preparing,
                (int)OrderStatus.InProgress,
                (int)OrderStatus.Ready,
                (int)OrderStatus.Shipping,
                (int)OrderStatus.Delivering
            };
        }
    }
}

