// ===============================
// CẤU HÌNH CƠ BẢN
// ===============================
const API_BASE = "/api/cart";

// Helper function để lấy account ID từ auth.js
function getAccountId() {
    if (window.getCurrentAccountId) {
        return window.getCurrentAccountId();
    }
    return null; // Trả về null nếu chưa login
}

let cartItems = [];
let cartTotalPrice = 0;

// ===============================
// ĐỊNH NGHĨA goToCheckout SỚM ĐỂ TRÁNH UNDEFINED
// ===============================
window.goToCheckout = function() {
    console.log('goToCheckout() called');
    
    try {
        // Kiểm tra đăng nhập trước
        const accountId = getAccountId();
        console.log('Account ID:', accountId);
        
        if (!accountId || accountId <= 0) {
            alert("Vui lòng đăng nhập để thanh toán!");
            window.location.href = '/AccountView/Login?returnUrl=' + encodeURIComponent(window.location.pathname);
            return false;
        }

        // Kiểm tra giỏ hàng có sản phẩm không
        if (!cartItems || cartItems.length === 0) {
            alert("Giỏ hàng trống! Vui lòng thêm sản phẩm vào giỏ hàng trước khi thanh toán.");
            return false;
        }

        const checkoutBtn = document.getElementById('btnCheckout') || document.querySelector('.btn-checkout');
        
        // Show button loading
        if (checkoutBtn) {
            if (window.showButtonLoading) {
                window.showButtonLoading(checkoutBtn, 'Đang chuyển...');
            } else {
                checkoutBtn.disabled = true;
                checkoutBtn.textContent = 'Đang chuyển...';
            }
        }

        // Chuyển đến trang checkout
        console.log('Redirecting to /Checkout');
        window.location.href = "/Checkout";
        return true;
    } catch (error) {
        console.error('❌ Error in goToCheckout:', error);
        alert('Có lỗi xảy ra khi chuyển đến trang thanh toán. Vui lòng thử lại!');
        
        // Re-enable button on error
        const checkoutBtn = document.getElementById('btnCheckout') || document.querySelector('.btn-checkout');
        if (checkoutBtn && window.hideButtonLoading) {
            window.hideButtonLoading(checkoutBtn);
        } else if (checkoutBtn) {
            checkoutBtn.disabled = false;
            checkoutBtn.textContent = 'Thanh toán';
        }
        
        return false;
    }
};

// ===============================
// ĐỊNH DẠNG SỐ TIỀN VND
// ===============================
function formatPrice(amount) {
    return new Intl.NumberFormat('vi-VN').format(amount) + 'đ';
}

// ===============================
// TẢI DỮ LIỆU GIỎ HÀNG TỪ API
// ===============================
async function loadCart(forceRefresh = false) {
    const cartListEl = document.getElementById("cartList");
    const totalPriceEl = document.getElementById("totalPrice");
    const cartTotalDiv = document.getElementById("cartTotal");
    const cartActionsDiv = document.getElementById("cartActions");

    // Show Ratatouille loader (center screen)
    if (window.showRatatouilleLoader) {
        window.showRatatouilleLoader(forceRefresh ? 'Đang tải lại dữ liệu...' : 'Đang tải dữ liệu...');
    } else if (window.showCompactPageLoader) {
        window.showCompactPageLoader(forceRefresh ? 'Đang tải lại dữ liệu...' : 'Đang tải dữ liệu...');
    } else if (cartListEl) {
        cartListEl.innerHTML = "<p>Đang tải dữ liệu...</p>";
    }

    try {
        const accountId = getAccountId();
        if (!accountId) {
            if (window.hideRatatouilleLoader) window.hideRatatouilleLoader();
            if (cartListEl) cartListEl.innerHTML = '<p style="color: #e31d14;">Vui lòng đăng nhập để xem giỏ hàng!</p>';
            hideCartFooter();
            return;
        }
        
        // Thêm cache-busting parameter để đảm bảo load data mới nhất
        const cacheBuster = forceRefresh ? `?t=${Date.now()}` : `?t=${Math.floor(Date.now() / 1000)}`; // Refresh mỗi giây khi force
        const response = await fetch(`${API_BASE}/by-account/${accountId}${cacheBuster}`, {
            cache: 'no-store', // Không cache response
            headers: {
                'Cache-Control': 'no-cache'
            }
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        
        // Lưu dữ liệu vào biến toàn cục
        cartItems = data.items || [];
        cartTotalPrice = data.total || 0;

        // Debug log - chi tiết hơn
        console.log("=== CART DATA LOADED ===");
        console.log("Items count:", cartItems.length);
        console.log("Items:", cartItems);
        console.log("Total:", cartTotalPrice);
        
        // Log từng item để debug
        if (cartItems.length > 0) {
            console.log("First item structure:", cartItems[0]);
            if (cartItems[0].productDetail) {
                console.log("First item productDetail:", cartItems[0].productDetail);
                if (cartItems[0].productDetail.product) {
                    console.log("First item product:", cartItems[0].productDetail.product);
                }
                if (cartItems[0].productDetail.productSize) {
                    console.log("First item productSize:", cartItems[0].productDetail.productSize);
                }
            }
        }

        // Render giỏ hàng
        renderCart();

        // Cập nhật badge giỏ hàng nếu có
        if (window.refreshCartBadge) {
            refreshCartBadge();
        }

    } catch (error) {
        console.error("Lỗi khi tải giỏ hàng:", error);
        
        if (cartListEl) {
            cartListEl.innerHTML = "<p style='color: red;'>Không thể tải dữ liệu giỏ hàng!</p>";
        }
        
        // Ẩn tổng tiền và các nút khi có lỗi
        hideCartFooter();
    } finally {
        // Hide Ratatouille loader when done
        if (window.hideRatatouilleLoader) {
            window.hideRatatouilleLoader();
        } else if (window.hideCompactPageLoader) {
            window.hideCompactPageLoader();
        }
    }
}

// ===============================
// RENDER GIỎ HÀNG
// ===============================
function renderCart() {
    const cartListEl = document.getElementById("cartList");
    const totalPriceEl = document.getElementById("totalPrice");
    const cartTotalDiv = document.getElementById("cartTotal");
    const cartActionsDiv = document.getElementById("cartActions");

    if (!cartListEl) {
        console.error("Không tìm thấy element cartList!");
        return;
    }

    // Kiểm tra giỏ hàng có sản phẩm không
    if (!cartItems || cartItems.length === 0) {
        cartListEl.innerHTML = "<p style='text-align: center; padding: 40px;'>Giỏ hàng trống!</p>";
        
        // Ẩn tổng tiền và các nút
        hideCartFooter();
        
        if (totalPriceEl) {
            totalPriceEl.textContent = "0đ";
        }
        return;
    }

    // Render header với checkbox chọn tất cả
    let itemsHTML = `
        <div class="cart-header">
            <label class="select-all-checkbox">
                <input type="checkbox" id="selectAllItems" onchange="toggleSelectAll(this)" />
                <span>Chọn tất cả</span>
            </label>
        </div>
    `;
    
    // Render từng sản phẩm
    for (let i = 0; i < cartItems.length; i++) {
        const item = cartItems[i];
        const html = buildCartItemHTML(item);
        itemsHTML += html;
    }

    // Gán HTML vào container
    cartListEl.innerHTML = itemsHTML;

    // Hiển thị tổng tiền
    if (totalPriceEl) {
        totalPriceEl.textContent = formatPrice(cartTotalPrice);
    }

    // Hiển thị tổng tiền và các nút
    showCartFooter();
    
    // Bind lại nút checkout sau khi render (với delay nhỏ để đảm bảo DOM đã update)
    setTimeout(() => {
        bindCheckoutButton();
    }, 100);
}

// ===============================
// XÂY DỰNG HTML CHO TỪNG SẢN PHẨM
// ===============================
function buildCartItemHTML(item) {
    // Debug: Log item để xem cấu trúc
    console.log("Building cart item HTML for:", item);
    
    // Lấy thông tin từ API response - hỗ trợ cả PascalCase và camelCase
    const itemId = item.ID || item.id || 0;
    const quantity = item.Quantity || item.quantity || 0;
    
    // Lấy productDetail - có thể là camelCase hoặc PascalCase
    const productDetail = item.productDetail || item.ProductDetail;
    
    if (!productDetail) {
        console.warn("Missing productDetail in item:", item);
        return "";
    }

    // Thông tin sản phẩm - hỗ trợ cả camelCase và PascalCase
    const product = productDetail.product || productDetail.Product;
    const productName = product?.ProductName || product?.productName || 
                       product?.Name || product?.name || 
                       "Sản phẩm không tên";
    
    // Thông tin size - hỗ trợ cả camelCase và PascalCase
    const productSize = productDetail.productSize || productDetail.ProductSize;
    const sizeName = productSize?.SizeName || productSize?.sizeName || 
                    productSize?.Name || productSize?.name || 
                    "Không xác định";
    
    // Giá - hỗ trợ cả PascalCase và camelCase
    const priceValue = productDetail.Price || productDetail.price || 
                      productDetail.PriceValue || productDetail.priceValue || 0;
    const price = parseFloat(priceValue);
    const subtotal = price * quantity;
    
    // Debug log
    console.log(`Item ${itemId}:`, {
        productName,
        sizeName,
        price,
        quantity,
        subtotal
    });
    
    // Lấy hình ảnh - hỗ trợ cả camelCase và PascalCase
    let imageUrl = "";
    const productImages = product?.productImages || product?.ProductImages || product?.product_images || [];
    
    if (productImages && productImages.length > 0) {
        const firstImage = productImages[0];
        imageUrl = firstImage?.ImageUrl || firstImage?.imageUrl || 
                  firstImage?.Url || firstImage?.url || 
                  firstImage?.imageUrl || "";
    }
    
    // Nếu không có hình ảnh, dùng placeholder
    if (!imageUrl) {
        const productId = productDetail.ProductID || productDetail.productID || 
                         productDetail.ProductId || productDetail.productId || 
                         product?.ID || product?.id || itemId;
        imageUrl = `https://picsum.photos/seed/${productId}/300/200`;
    }

    // Xây dựng HTML
    return `
        <div class="cart-item" data-item-id="${itemId}">
            <label class="item-checkbox">
                <input type="checkbox" class="item-checkbox-input" value="${itemId}" onchange="updateSelectAllCheckbox()" />
            </label>
            
            <img src="${imageUrl}" class="cart-thumb" alt="${productName}" onerror="this.src='https://picsum.photos/seed/${itemId}/300/200'" />
            
            <div class="cart-info">
                <h4>${productName}</h4>
                
                <p class="cart-item-size">
                    <strong>Size:</strong> <span class="size-value">${sizeName}</span>
                </p>
                
                <p class="cart-item-price">
                    <strong>Giá:</strong> ${formatPrice(price)}
                </p>
                
                <p class="cart-item-subtotal">
                    <strong>Thành tiền:</strong> <span class="subtotal-value">${formatPrice(subtotal)}</span>
                </p>
                
                <div class="qty-control">
                    <button type="button" class="qty-btn qty-minus" onclick="updateQuantity(${itemId}, -1)">-</button>
                    <span class="qty-value">${quantity}</span>
                    <button type="button" class="qty-btn qty-plus" onclick="updateQuantity(${itemId}, 1)">+</button>
                </div>
            </div>
            
            <button type="button" class="btn-remove" onclick="removeCartItem(${itemId})" title="Xóa sản phẩm">
                🗑 Xóa
            </button>
        </div>
    `;
}

// ===============================
// HIỂN THỊ FOOTER GIỎ HÀNG (Tổng tiền + Nút)
// ===============================
function showCartFooter() {
    const cartTotalDiv = document.getElementById("cartTotal");
    const cartActionsDiv = document.getElementById("cartActions");

    if (cartTotalDiv) {
        cartTotalDiv.style.display = "block";
        cartTotalDiv.style.visibility = "visible";
    }

    if (cartActionsDiv) {
        cartActionsDiv.style.display = "flex";
        cartActionsDiv.style.visibility = "visible";
    }
}

// ===============================
// ẨN FOOTER GIỎ HÀNG
// ===============================
function hideCartFooter() {
    const cartTotalDiv = document.getElementById("cartTotal");
    const cartActionsDiv = document.getElementById("cartActions");

    if (cartTotalDiv) {
        cartTotalDiv.style.display = "none";
    }

    if (cartActionsDiv) {
        cartActionsDiv.style.display = "none";
    }
}

// ===============================
// CẬP NHẬT SỐ LƯỢNG SẢN PHẨM
// ===============================
async function updateQuantity(itemId, delta) {
    // Tìm sản phẩm trong mảng - hỗ trợ cả PascalCase và camelCase
    const item = cartItems.find(x => (x.ID || x.id) === itemId);
    if (!item) {
        console.error("Không tìm thấy sản phẩm với ID:", itemId);
        return;
    }

    // Tính số lượng mới - hỗ trợ cả PascalCase và camelCase
    const currentQty = item.Quantity || item.quantity || 0;
    const newQty = currentQty + delta;

    // Kiểm tra số lượng hợp lệ
    if (newQty < 1) {
        alert("Số lượng không thể nhỏ hơn 1!");
        return;
    }

    // Cập nhật số lượng trong mảng - cả hai cách
    item.Quantity = newQty;
    item.quantity = newQty;

    // Tính lại tổng tiền
    recalculateTotal();

    // Render lại giỏ hàng
    renderCart();

    // Gửi request cập nhật lên server
    const qtyBtn = event?.target?.closest('.qty-btn');
    try {
        // Show button loading
        if (qtyBtn && window.showButtonLoading) {
            window.showButtonLoading(qtyBtn);
        }

        const response = await fetch(`${API_BASE}/update-qty/${itemId}?qty=${newQty}`, {
            method: "PUT"
        });

        if (!response.ok) {
            throw new Error("Cập nhật số lượng thất bại");
        }

        // Cập nhật badge
        if (window.refreshCartBadge) {
            refreshCartBadge();
        }

    } catch (error) {
        console.error("Lỗi khi cập nhật số lượng:", error);
        alert("Không thể cập nhật số lượng! Vui lòng thử lại.");
        // Reload lại để đồng bộ với server
        loadCart();
    } finally {
        // Hide button loading
        if (qtyBtn && window.hideButtonLoading) {
            window.hideButtonLoading(qtyBtn);
        }
    }
}

// ===============================
// XÓA SẢN PHẨM KHỎI GIỎ HÀNG
// ===============================
async function removeCartItem(itemId) {
    // Xác nhận xóa
    if (!confirm("Bạn có chắc chắn muốn xóa sản phẩm này khỏi giỏ hàng?")) {
        return;
    }

    const removeBtn = event?.target?.closest('.btn-remove');

    try {
        // Show button loading
        if (removeBtn && window.showButtonLoading) {
            window.showButtonLoading(removeBtn, 'Đang xóa...');
        }

        const response = await fetch(`${API_BASE}/delete/${itemId}`, {
            method: "DELETE"
        });

        if (!response.ok) {
            throw new Error("Xóa sản phẩm thất bại");
        }

        // Xóa khỏi mảng local - hỗ trợ cả PascalCase và camelCase
        cartItems = cartItems.filter(x => (x.ID || x.id) !== itemId);

        // Tính lại tổng tiền
        recalculateTotal();

        // Render lại giỏ hàng
        renderCart();

        // Cập nhật badge
        if (window.refreshCartBadge) {
            refreshCartBadge();
        }

    } catch (error) {
        console.error("Lỗi khi xóa sản phẩm:", error);
        alert("Không thể xóa sản phẩm! Vui lòng thử lại.");
        // Reload lại để đồng bộ với server
        loadCart();
    } finally {
        // Hide button loading
        if (removeBtn && window.hideButtonLoading) {
            window.hideButtonLoading(removeBtn);
        }
    }
}

// ===============================
// TÍNH LẠI TỔNG TIỀN
// ===============================
function recalculateTotal() {
    cartTotalPrice = 0;
    
    for (let i = 0; i < cartItems.length; i++) {
        const item = cartItems[i];
        const productDetail = item.productDetail || item.ProductDetail;
        
        if (productDetail) {
            const price = parseFloat(productDetail.Price || productDetail.price || 0);
            const quantity = item.Quantity || item.quantity || 0;
            cartTotalPrice += price * quantity;
        }
    }
}

// ===============================
// CHỌN/BỎ CHỌN TẤT CẢ
// ===============================
function toggleSelectAll(checkbox) {
    const isChecked = checkbox.checked;
    const itemCheckboxes = document.querySelectorAll('.item-checkbox-input');
    
    itemCheckboxes.forEach(cb => {
        cb.checked = isChecked;
    });
}

// ===============================
// CẬP NHẬT CHECKBOX "CHỌN TẤT CẢ"
// ===============================
function updateSelectAllCheckbox() {
    const itemCheckboxes = document.querySelectorAll('.item-checkbox-input');
    const selectAllCheckbox = document.getElementById('selectAllItems');
    
    if (!selectAllCheckbox || itemCheckboxes.length === 0) {
        return;
    }
    
    // Kiểm tra xem tất cả items đã được chọn chưa
    const allChecked = Array.from(itemCheckboxes).every(cb => cb.checked);
    const someChecked = Array.from(itemCheckboxes).some(cb => cb.checked);
    
    selectAllCheckbox.checked = allChecked;
    selectAllCheckbox.indeterminate = someChecked && !allChecked;
}

// ===============================
// LẤY DANH SÁCH ID CỦA CÁC ITEM ĐÃ CHỌN
// ===============================
function getSelectedItemIds() {
    const itemCheckboxes = document.querySelectorAll('.item-checkbox-input:checked');
    return Array.from(itemCheckboxes).map(cb => parseInt(cb.value));
}

// ===============================
// XÓA CÁC ITEMS ĐÃ CHỌN
// ===============================
async function deleteSelectedItems() {
    const selectedIds = getSelectedItemIds();
    
    if (selectedIds.length === 0) {
        alert("Vui lòng chọn ít nhất một sản phẩm để xóa!");
        return;
    }
    
    // Xác nhận xóa
    if (!confirm(`Bạn có chắc chắn muốn xóa ${selectedIds.length} sản phẩm đã chọn?`)) {
        return;
    }
    
    const deleteBtn = document.querySelector('.btn-delete-selected');
    
    try {
        // Show button loading
        if (deleteBtn && window.showButtonLoading) {
            window.showButtonLoading(deleteBtn, 'Đang xóa...');
        }
        
        // Xóa từng item
        let successCount = 0;
        let failCount = 0;
        
        for (const itemId of selectedIds) {
            try {
                const response = await fetch(`${API_BASE}/delete/${itemId}`, {
                    method: "DELETE"
                });
                
                if (response.ok) {
                    successCount++;
                } else {
                    failCount++;
                    console.error(`Failed to delete item ${itemId}`);
                }
            } catch (error) {
                failCount++;
                console.error(`Error deleting item ${itemId}:`, error);
            }
        }
        
        // Reload giỏ hàng
        await loadCart();
        
        // Thông báo kết quả
        if (failCount === 0) {
            alert(`Đã xóa thành công ${successCount} sản phẩm!`);
        } else {
            alert(`Đã xóa ${successCount} sản phẩm. ${failCount} sản phẩm không thể xóa.`);
        }
        
        // Cập nhật badge
        if (window.refreshCartBadge) {
            refreshCartBadge();
        }
    } finally {
        // Hide button loading
        if (deleteBtn && window.hideButtonLoading) {
            window.hideButtonLoading(deleteBtn);
        }
    }
}

// ===============================
// XÓA TẤT CẢ ITEMS
// ===============================
async function deleteAllItems() {
    if (!cartItems || cartItems.length === 0) {
        alert("Giỏ hàng trống!");
        return;
    }
    
    // Xác nhận xóa
    if (!confirm(`Bạn có chắc chắn muốn xóa TẤT CẢ ${cartItems.length} sản phẩm trong giỏ hàng?`)) {
        return;
    }
    
    const deleteAllBtn = document.querySelector('.btn-delete-all');
    
    try {
        // Show button loading
        if (deleteAllBtn && window.showButtonLoading) {
            window.showButtonLoading(deleteAllBtn, 'Đang xóa...');
        }
        
        // Xóa từng item
        let successCount = 0;
        let failCount = 0;
    
    for (const item of cartItems) {
        const itemId = item.ID || item.id;
        if (!itemId) continue;
        
        try {
            const response = await fetch(`${API_BASE}/delete/${itemId}`, {
                method: "DELETE"
            });
            
            if (response.ok) {
                successCount++;
            } else {
                failCount++;
                console.error(`Failed to delete item ${itemId}`);
            }
        } catch (error) {
            failCount++;
            console.error(`Error deleting item ${itemId}:`, error);
        }
    }
    
    // Reload giỏ hàng
    await loadCart();
    
    // Thông báo kết quả
    if (failCount === 0) {
        alert(`Đã xóa thành công ${successCount} sản phẩm!`);
    } else {
        alert(`Đã xóa ${successCount} sản phẩm. ${failCount} sản phẩm không thể xóa.`);
    }
    
    // Cập nhật badge
    if (window.refreshCartBadge) {
        refreshCartBadge();
    }
    } finally {
        // Hide button loading
        if (deleteAllBtn && window.hideButtonLoading) {
            window.hideButtonLoading(deleteAllBtn);
        }
    }
}

// ===============================
// CHUYỂN ĐẾN TRANG THANH TOÁN
// ===============================
// Function này đã được định nghĩa ở đầu file như window.goToCheckout
// Giữ lại function này để code khác có thể gọi
function goToCheckout() {
    // Gọi window.goToCheckout để đảm bảo consistency
    if (window.goToCheckout) {
        window.goToCheckout();
    } else {
        // Fallback nếu không có
        window.location.href = "/Checkout";
    }
}

// ===============================
// BIND NÚT CHECKOUT
// ===============================
function bindCheckoutButton() {
    const checkoutBtn = document.getElementById('btnCheckout') || document.querySelector('.btn-checkout');
    if (checkoutBtn) {
        console.log('Found checkout button:', checkoutBtn);
        console.log('Button style:', window.getComputedStyle(checkoutBtn));
        console.log('Button disabled:', checkoutBtn.disabled);
        console.log('Button pointer-events:', window.getComputedStyle(checkoutBtn).pointerEvents);
        
        // Đảm bảo nút có thể click
        checkoutBtn.style.pointerEvents = 'auto';
        checkoutBtn.disabled = false;
        checkoutBtn.style.cursor = 'pointer';
        
        // Remove onclick cũ nếu có
        checkoutBtn.removeAttribute('onclick');
        
        // Remove old event listeners by cloning and replacing
        const newBtn = checkoutBtn.cloneNode(true);
        checkoutBtn.parentNode?.replaceChild(newBtn, checkoutBtn);
        const finalBtn = newBtn;
        
        // Bind event listener mới
        finalBtn.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            console.log('✅ Checkout button clicked');
            window.goToCheckout();
            return false;
        }, false);
        
        // Also set onclick for compatibility
        finalBtn.onclick = function(e) {
            e.preventDefault();
            e.stopPropagation();
            e.stopImmediatePropagation();
            console.log('✅ Checkout button clicked (onclick)');
            window.goToCheckout();
            return false;
        };
        
        // Test click programmatically để đảm bảo nút hoạt động
        console.log('Checkout button bound successfully:', checkoutBtn);
        console.log('Button is visible:', checkoutBtn.offsetParent !== null);
        console.log('Button is in viewport:', checkoutBtn.getBoundingClientRect());
    } else {
        console.error('Checkout button not found!');
        console.log('Available buttons:', document.querySelectorAll('button'));
    }
}

// ===============================
// SETUP EVENT DELEGATION
// ===============================
function setupCartEventListeners() {
    // Bind nút checkout
    bindCheckoutButton();
    
    // Event delegation cho các buttons khác
    document.addEventListener('click', function(e) {
        // Tìm element có data-action
        let target = e.target;
        while (target && target !== document.body) {
            if (target.hasAttribute && target.hasAttribute('data-action')) {
                break;
            }
            target = target.parentElement;
        }
        
        if (!target || !target.hasAttribute || !target.hasAttribute('data-action')) return;

        const action = target.getAttribute('data-action');
        
        // Bỏ qua nút checkout vì đã bind trực tiếp
        if (action === 'go-to-checkout') {
            return;
        }
        
        // Prevent default nếu là button
        if (target.tagName === 'BUTTON') {
            e.preventDefault();
        }
    });
}

// ===============================
// KHỞI TẠO KHI TRANG ĐƯỢC TẢI
// ===============================
document.addEventListener("DOMContentLoaded", function() {
    console.log("Cart page loaded, initializing...");
    
    // Setup event listeners ngay lập tức
    setupCartEventListeners();
    
    // Load cart data
    loadCart(true); // Force refresh khi vào trang
    
    // Bind lại nút checkout sau khi load xong (backup)
    setTimeout(() => {
        bindCheckoutButton();
    }, 1000);
    
    // Reload cart khi trang được focus lại (khi user quay lại từ tab khác hoặc từ trang success)
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden) {
            // Trang được hiển thị lại, reload cart để đảm bảo data mới nhất
            console.log("Page visible again, reloading cart...");
            loadCart(true);
        }
    });
    
    // Reload cart khi window được focus lại
    window.addEventListener('focus', function() {
        console.log("Window focused, reloading cart...");
        loadCart(true);
    });
});

// Export functions để có thể gọi từ HTML
window.updateQuantity = updateQuantity;
window.removeCartItem = removeCartItem;
// window.goToCheckout đã được định nghĩa ở đầu file
window.toggleSelectAll = toggleSelectAll;
window.updateSelectAllCheckbox = updateSelectAllCheckbox;
window.deleteSelectedItems = deleteSelectedItems;
window.deleteAllItems = deleteAllItems;
