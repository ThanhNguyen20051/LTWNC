using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using System.Linq;
using static FFoodsStore.Models.OrderStatusHelper;

namespace FFoodsStore.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly StoreDbContext _db;
        public OrderController(StoreDbContext db) => _db = db;

        // GET: api/order/by-account/1
        [HttpGet("by-account/{accountId}")]
        public async Task<IActionResult> GetOrders(int accountId)
        {
            var orders = await _db.Orders
                .Where(o => o.AccountID == accountId && (o.IsDeleted == null || o.IsDeleted == false))
                .OrderByDescending(o => o.CreateDate)
                .Select(o => new
                {
                    id = o.ID,
                    orderCode = o.OrderCode ?? "",
                    customerName = o.CustomerName ?? "",
                    phoneNumber = o.PhoneNumber ?? "",
                    address = o.Address ?? "",
                    status = o.Status ?? 1,
                    statusName = OrderStatusHelper.GetStatusName(o.Status),
                    createDate = o.CreateDate,
                    total = _db.OrderDetails
                        .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                        .Sum(od => od.TotalMoney ?? 0)
                })
                .ToListAsync();

            return Ok(new { orders });
        }

        // GET: api/order/{orderId}
        [HttpGet("{orderId}")]
        public async Task<IActionResult> GetOrder(int orderId)
        {
            var order = await _db.Orders
                .Where(o => o.ID == orderId && (o.IsDeleted == null || o.IsDeleted == false))
                .Select(o => new
                {
                    id = o.ID,
                    orderCode = o.OrderCode ?? "",
                    customerName = o.CustomerName ?? "",
                    phoneNumber = o.PhoneNumber ?? "",
                    address = o.Address ?? "",
                    paymentMethod = o.PaymentMethod ?? "cod",
                    status = o.Status ?? 1,
                    statusName = OrderStatusHelper.GetStatusName(o.Status),
                    createDate = o.CreateDate,
                    total = _db.OrderDetails
                        .Where(od => od.OrderID == o.ID && (od.IsDelete == null || od.IsDelete == false))
                        .Sum(od => od.TotalMoney ?? 0)
                })
                .FirstOrDefaultAsync();

            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            return Ok(new { order });
        }

        // GET: api/order/{orderId}/details
        [HttpGet("{orderId}/details")]
        public async Task<IActionResult> GetOrderDetails(int orderId)
        {
            var details = await _db.OrderDetails
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.Product!)
                        .ThenInclude(p => p.ProductImages)
                .Include(od => od.ProductDetail!)
                    .ThenInclude(pd => pd.ProductSize)
                .Where(od => od.OrderID == orderId && (od.IsDelete == null || od.IsDelete == false))
                .Select(od => new
                {
                    id = od.ID,
                    quantity = od.Quantity ?? 0,
                    totalMoney = od.TotalMoney ?? 0,
                    productDetail = od.ProductDetail == null ? null : new
                    {
                        id = od.ProductDetail.ID,
                        productId = od.ProductDetail.ProductID,
                        price = od.ProductDetail.Price ?? 0,
                        productSize = od.ProductDetail.ProductSize == null ? null : new
                        {
                            id = od.ProductDetail.ProductSize.ID,
                            sizeName = od.ProductDetail.ProductSize.SizeName ?? "",
                            sizeCode = od.ProductDetail.ProductSize.SizeCode ?? ""
                        },
                        product = od.ProductDetail.Product == null ? null : new
                        {
                            id = od.ProductDetail.Product.ID,
                            productName = od.ProductDetail.Product.ProductName ?? "",
                            productCode = od.ProductDetail.Product.ProductCode ?? "",
                            productImages = (od.ProductDetail.Product.ProductImages != null 
                                ? od.ProductDetail.Product.ProductImages
                                    .Where(img => img.IsDelete != true)
                                    .Select(img => new { 
                                        imageUrl = img.ImageUrl ?? "",
                                        imageName = img.ImageName ?? ""
                                    })
                                : Enumerable.Empty<object>())
                                .ToList()
                        }
                    }
                })
                .ToListAsync();

            return Ok(new { items = details });
        }

        // GET: api/order/{orderId}/timeline
        [HttpGet("{orderId}/timeline")]
        public async Task<IActionResult> GetOrderTimeline(int orderId)
        {
            var order = await _db.Orders
                .FirstOrDefaultAsync(o => o.ID == orderId && (o.IsDeleted == null || o.IsDeleted == false));

            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            var timeline = new List<object>();

            // Tạo timeline dựa trên trạng thái và thời gian cập nhật
            if (order.CreateDate.HasValue)
            {
                timeline.Add(new
                {
                    status = order.Status ?? 1,
                    statusName = OrderStatusHelper.GetStatusName(order.Status),
                    timestamp = order.CreateDate.Value,
                    description = "Đơn hàng được tạo",
                    icon = "📝",
                    isActive = true
                });
            }

            // Nếu có UpdatedDate và khác CreateDate, thêm vào timeline
            if (order.UpdatedDate.HasValue && 
                order.CreateDate.HasValue && 
                order.UpdatedDate.Value != order.CreateDate.Value)
            {
                timeline.Add(new
                {
                    status = order.Status ?? 1,
                    statusName = OrderStatusHelper.GetStatusName(order.Status),
                    timestamp = order.UpdatedDate.Value,
                    description = GetStatusDescription(order.Status ?? 1),
                    icon = GetStatusIcon(order.Status ?? 1),
                    isActive = true
                });
            }

            // Sắp xếp theo thời gian
            timeline = timeline.OrderBy(t => ((dynamic)t).timestamp).ToList();

            return Ok(new { timeline });
        }

        // GET: api/order/{orderId}/estimated-delivery
        [HttpGet("{orderId}/estimated-delivery")]
        public async Task<IActionResult> GetEstimatedDelivery(int orderId)
        {
            var order = await _db.Orders
                .FirstOrDefaultAsync(o => o.ID == orderId && (o.IsDeleted == null || o.IsDeleted == false));

            if (order == null)
            {
                return NotFound(new { message = "Không tìm thấy đơn hàng" });
            }

            var status = order.Status ?? 1;
            var estimatedTime = CalculateEstimatedDeliveryTime(order, status);

            return Ok(new
            {
                estimatedTime = estimatedTime,
                estimatedTimeFormatted = FormatEstimatedTime(estimatedTime),
                status = status,
                statusName = OrderStatusHelper.GetStatusName(status)
            });
        }

        private string GetStatusDescription(int status)
        {
            return status switch
            {
                (int)OrderStatus.Pending => "Đơn hàng đang chờ xác nhận từ nhân viên",
                (int)OrderStatus.Confirmed => "Nhân viên đã xác nhận đơn hàng",
                (int)OrderStatus.Preparing => "Nhân viên đang chuẩn bị đơn hàng",
                (int)OrderStatus.InProgress => "Bếp đang chế biến món ăn",
                (int)OrderStatus.Ready => "Món ăn đã sẵn sàng, đang chờ giao hàng",
                (int)OrderStatus.Assigned => "Đơn hàng đã được gán cho shipper",
                (int)OrderStatus.Accepted => "Shipper đã chấp nhận đơn hàng",
                (int)OrderStatus.PickedUp => "Shipper đã lấy hàng tại cửa hàng",
                (int)OrderStatus.OnTheWay => "Shipper đang trên đường giao hàng",
                (int)OrderStatus.Arrived => "Shipper đã đến địa chỉ giao hàng",
                (int)OrderStatus.Delivering => "Đang giao hàng",
                (int)OrderStatus.Delivered => "Giao hàng thành công",
                (int)OrderStatus.Completed => "Đơn hàng đã hoàn thành",
                (int)OrderStatus.FailedDelivery => "Giao hàng thất bại",
                (int)OrderStatus.DeliveryFailed => "Giao hàng thất bại",
                (int)OrderStatus.Canceled => "Đơn hàng đã bị hủy",
                _ => "Cập nhật trạng thái đơn hàng"
            };
        }

        private string GetStatusIcon(int status)
        {
            return status switch
            {
                (int)OrderStatus.Pending => "⏳",
                (int)OrderStatus.Confirmed => "✅",
                (int)OrderStatus.Preparing => "👨‍🍳",
                (int)OrderStatus.InProgress => "🔥",
                (int)OrderStatus.Ready => "📦",
                (int)OrderStatus.Assigned => "👤",
                (int)OrderStatus.Accepted => "👍",
                (int)OrderStatus.PickedUp => "🚚",
                (int)OrderStatus.OnTheWay => "🛣️",
                (int)OrderStatus.Arrived => "📍",
                (int)OrderStatus.Delivering => "🚴",
                (int)OrderStatus.Delivered => "🎉",
                (int)OrderStatus.Completed => "✨",
                (int)OrderStatus.FailedDelivery => "❌",
                (int)OrderStatus.DeliveryFailed => "❌",
                (int)OrderStatus.Canceled => "🚫",
                _ => "📋"
            };
        }

        private DateTime? CalculateEstimatedDeliveryTime(Order order, int status)
        {
            if (!order.CreateDate.HasValue)
                return null;

            var baseTime = order.UpdatedDate ?? order.CreateDate.Value;
            var estimatedMinutes = 0;

            // Tính thời gian dự đoán dựa trên trạng thái hiện tại
            switch (status)
            {
                case (int)OrderStatus.Pending:
                    // Chờ xác nhận: 5-10 phút
                    estimatedMinutes = 10;
                    break;
                case (int)OrderStatus.Confirmed:
                case (int)OrderStatus.Preparing:
                    // Đã xác nhận/Chuẩn bị: 15-20 phút
                    estimatedMinutes = 20;
                    break;
                case (int)OrderStatus.InProgress:
                    // Đang chế biến: 20-30 phút
                    estimatedMinutes = 30;
                    break;
                case (int)OrderStatus.Ready:
                    // Sẵn sàng: 5-10 phút (chờ shipper)
                    estimatedMinutes = 10;
                    break;
                case (int)OrderStatus.Assigned:
                case (int)OrderStatus.Accepted:
                    // Đã gán/Chấp nhận: 10-15 phút (shipper đến lấy hàng)
                    estimatedMinutes = 15;
                    break;
                case (int)OrderStatus.PickedUp:
                    // Đã lấy hàng: 20-30 phút (giao hàng)
                    estimatedMinutes = 30;
                    break;
                case (int)OrderStatus.OnTheWay:
                    // Đang trên đường: 10-20 phút
                    estimatedMinutes = 20;
                    break;
                case (int)OrderStatus.Arrived:
                    // Đã đến nơi: 2-5 phút
                    estimatedMinutes = 5;
                    break;
                case (int)OrderStatus.Delivering:
                    // Đang giao: 2-5 phút
                    estimatedMinutes = 5;
                    break;
                case (int)OrderStatus.Delivered:
                case (int)OrderStatus.Completed:
                    // Đã giao: không cần dự đoán
                    return null;
                case (int)OrderStatus.FailedDelivery:
                case (int)OrderStatus.DeliveryFailed:
                case (int)OrderStatus.Canceled:
                    // Thất bại/Hủy: không cần dự đoán
                    return null;
                default:
                    estimatedMinutes = 30;
                    break;
            }

            return baseTime.AddMinutes(estimatedMinutes);
        }

        private string? FormatEstimatedTime(DateTime? estimatedTime)
        {
            if (!estimatedTime.HasValue)
                return null;

            var now = DateTime.Now;
            var diff = estimatedTime.Value - now;

            if (diff.TotalMinutes < 0)
                return "Đã quá thời gian dự kiến";

            if (diff.TotalMinutes < 60)
                return $"Khoảng {Math.Ceiling(diff.TotalMinutes)} phút nữa";

            var hours = Math.Floor(diff.TotalHours);
            var minutes = Math.Ceiling(diff.TotalMinutes % 60);
            
            if (minutes == 60)
            {
                hours += 1;
                minutes = 0;
            }

            if (hours > 0 && minutes > 0)
                return $"Khoảng {hours} giờ {minutes} phút nữa";
            else if (hours > 0)
                return $"Khoảng {hours} giờ nữa";
            else
                return $"Khoảng {minutes} phút nữa";
        }

    }
}

