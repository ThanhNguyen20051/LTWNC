// ===============================
// CHECKOUT PAGE - Rebuild from scratch
// ===============================

// Sử dụng IIFE để tránh conflict với các biến global khác
(function() {
    'use strict';
    
    // Helper function để lấy account ID từ auth.js
    function getAccountId() {
        if (window.getCurrentAccountId) {
            return window.getCurrentAccountId();
        }
        return null; // Trả về null nếu chưa login
    }
    let cartData = [];
    let cartTotal = 0;
    let shippingFee = 20000; // Phí ship mặc định: 20,000 VND
    let paymentMethods = [];
    let selectedPaymentMethod = 'cod';

    // ===============================
    // Khởi tạo khi trang load
    // ===============================
    function init() {
        console.log('Initializing checkout page...');
        
        // Check if user is logged in
        const accountId = getAccountId();
        if (!accountId) {
            alert('Vui lòng đăng nhập để thanh toán!');
            window.location.href = '/AccountView/Login';
            return;
        }
        
        const container = document.getElementById('checkoutContent');
        
        if (!container) {
            console.error('ERROR: checkoutContent not found!');
            setTimeout(init, 500); // Retry
            return;
        }
        
        console.log('Container found, loading data...');
        loadData();
    }
    
    // Đảm bảo DOM đã sẵn sàng
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function() {
            console.log('=== CHECKOUT.JS LOADED ===');
            init();
        });
    } else {
        // DOM đã sẵn sàng
        console.log('=== CHECKOUT.JS LOADED ===');
        setTimeout(init, 100);
    }

    // ===============================
    // Load tất cả dữ liệu từ API
    // ===============================
    async function loadData() {
    const container = document.getElementById('checkoutContent');
    if (!container) return;
    
    // Hiển thị loading
    container.innerHTML = '<div class="loading" style="text-align: center; padding: 40px; color: #666;">Đang tải dữ liệu...</div>';
    
    try {
        console.log('=== LOADING API DATA ===');
        
        // 1. Load giỏ hàng - BẮT BUỘC
        console.log('Step 1: Loading cart...');
        const accountId = getAccountId();
        if (!accountId) {
            container.innerHTML = '<div class="error" style="text-align: center; padding: 40px; color: #e31d14;">Vui lòng đăng nhập để thanh toán!</div>';
            return;
        }
        const cartResponse = await fetch(`/api/cart/by-account/${accountId}`);
        
        if (!cartResponse.ok) {
            throw new Error(`Lỗi tải giỏ hàng: ${cartResponse.status} ${cartResponse.statusText}`);
        }
        
        const cartJson = await cartResponse.json();
        console.log('✅ Cart API Response:', cartJson);
        
        cartData = cartJson.items || cartJson.Items || [];
        cartTotal = parseFloat(cartJson.total || cartJson.Total || 0);
        
        console.log(`✅ Cart loaded: ${cartData.length} items, Total: ${cartTotal}`);
        
        // 2. Load payment methods - CÓ FALLBACK
        console.log('Step 2: Loading payment methods...');
        try {
            const pmResponse = await fetch('/api/payment/methods');
            if (pmResponse.ok) {
                const pmJson = await pmResponse.json();
                paymentMethods = pmJson.methods || pmJson.Methods || [];
                console.log('✅ Payment methods loaded:', paymentMethods);
            } else {
                throw new Error('API returned error');
            }
        } catch (err) {
            console.warn('⚠️ Payment methods API failed, using fallback:', err);
            paymentMethods = [
                { code: 'cod', name: 'Thanh toán khi nhận hàng (COD)', description: 'Thanh toán bằng tiền mặt khi nhận hàng', icon: '💵' },
                { code: 'bank', name: 'Thanh toán qua ngân hàng', description: 'Chuyển khoản qua QR Code hoặc ngân hàng', icon: '🏦' }
            ];
        }
        
        // 3. Kiểm tra giỏ hàng
        if (!cartData || cartData.length === 0) {
            container.innerHTML = `
                <div style="text-align: center; padding: 40px;">
                    <p style="color: red; font-size: 18px; margin-bottom: 20px;">Giỏ hàng trống!</p>
                    <p style="color: #666; margin-bottom: 20px;">Vui lòng thêm món vào giỏ trước khi thanh toán.</p>
                    <a href="/CartView" style="display: inline-block; padding: 12px 24px; background: #e31d14; color: #fff; text-decoration: none; border-radius: 8px;">← Quay lại giỏ hàng</a>
                </div>
            `;
            return;
        }
        
        // 4. Render form
        console.log('Step 3: Rendering checkout form...');
        renderForm();
        
    } catch (error) {
        console.error('❌ ERROR loading checkout:', error);
        container.innerHTML = `
            <div style="text-align: center; padding: 40px; background: #fff5f5; border-radius: 12px; border: 2px solid #e31d14;">
                <p style="color: #e31d14; font-size: 20px; font-weight: 700; margin-bottom: 16px;">⚠️ Lỗi tải dữ liệu!</p>
                <p style="color: #666; font-size: 16px; margin-bottom: 20px;">${escapeHtml(error.message || 'Vui lòng thử lại sau.')}</p>
                <div style="display: flex; gap: 12px; justify-content: center; flex-wrap: wrap;">
                    <button onclick="location.reload()" style="padding: 12px 24px; background: #e31d14; color: #fff; border: none; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer;">🔄 Tải lại trang</button>
                    <a href="/CartView" style="display: inline-block; padding: 12px 24px; background: #6c757d; color: #fff; text-decoration: none; border-radius: 8px; font-size: 16px; font-weight: 600;">← Quay lại giỏ hàng</a>
                </div>
            </div>
        `;
    }
}

    // ===============================
    // Render form checkout
    // ===============================
    function renderForm() {
    const container = document.getElementById('checkoutContent');
    if (!container) return;
    
    console.log('Rendering form with:', {
        items: cartData.length,
        total: cartTotal,
        paymentMethods: paymentMethods.length
    });
    
    const itemsHtml = buildItemsHTML();
    const paymentMethodsHtml = buildPaymentMethodsHTML();
    
    container.innerHTML = `
        <form id="checkoutForm" onsubmit="handleSubmit(event)">
            <!-- Thông tin giao hàng -->
            <div class="checkout-form">
                <h2>Thông tin giao hàng</h2>
                
                <div class="form-group">
                    <label for="customerName">Họ và tên *</label>
                    <input type="text" id="customerName" name="customerName" required 
                           placeholder="Nhập họ và tên của bạn" />
                </div>

                <div class="form-group">
                    <label for="phoneNumber">Số điện thoại *</label>
                    <input type="tel" id="phoneNumber" name="phoneNumber" required 
                           placeholder="Nhập số điện thoại" />
                </div>

                <div class="form-group">
                    <label for="address">Địa chỉ giao hàng *</label>
                    <textarea id="address" name="address" required 
                              placeholder="Nhập địa chỉ giao hàng chi tiết"></textarea>
                </div>
            </div>

            <!-- Tóm tắt đơn hàng -->
            <div class="order-summary">
                <h2>Tóm tắt đơn hàng</h2>
                <div style="margin-bottom: 16px; padding-bottom: 16px; border-bottom: 1px solid #eee;">
                    <p style="color: #666; font-size: 14px; margin: 0;">
                        Tổng số sản phẩm: <strong style="color: #111;">${cartData.length}</strong> món
                    </p>
                </div>
                ${itemsHtml}
                <div style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #eee;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                        <span style="color: #666; font-size: 16px;">Tạm tính:</span>
                        <span style="font-size: 16px; font-weight: 600;">${formatPrice(cartTotal)}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 12px;">
                        <span style="color: #666; font-size: 16px;">Phí ship:</span>
                        <span style="font-size: 16px; font-weight: 600; color: #e31d14;">${formatPrice(shippingFee)}</span>
                    </div>
                </div>
                <div class="summary-total" style="margin-top: 16px; padding-top: 16px; border-top: 2px solid #e31d14;">
                    <span style="font-size: 22px; font-weight: 700;">Tổng cộng:</span>
                    <span class="amount" style="font-size: 24px; font-weight: 800; color: #e31d14;">${formatPrice(cartTotal + shippingFee)}</span>
                </div>
            </div>

            <!-- Phương thức thanh toán -->
            <div class="payment-section">
                <h2>Phương thức thanh toán</h2>
                <p style="color: #666; font-size: 14px; margin: 0 0 20px 0;">
                    Vui lòng chọn một trong hai phương thức thanh toán sau:
                </p>
                
                <div class="payment-methods" id="paymentMethodsContainer">
                    ${paymentMethodsHtml}
                </div>

                <!-- QR Code (ẩn mặc định) -->
                <!-- Lưu ý: QR Payment hoạt động giống COD - chỉ cần submit form để tạo đơn hàng -->
                <div class="qr-code-container" id="qrCodeContainer" style="display: none;">
                    <p style="margin: 0 0 20px 0; color: #111; font-size: 18px; font-weight: 700; text-align: center;"><strong>Thông tin thanh toán qua ngân hàng</strong></p>
                    <div style="display: flex; justify-content: center; align-items: center; width: 100%; margin-bottom: 20px;">
                        <img id="qrCodeImage" src="" alt="QR Code" style="display: none; max-width: 250px; width: 250px; height: 250px; object-fit: contain; border-radius: 12px; box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15); border: 3px solid #e31d14; padding: 12px; background: #fff; margin: 0 auto;" />
                    </div>
                    <div id="bankInfoContainer" style="width: 100%; max-width: 100%; margin-top: 0; padding: 20px; background: #fff; border-radius: 8px; border: 2px solid #e31d14; box-sizing: border-box; word-wrap: break-word; overflow-wrap: break-word;">
                        <!-- Bank info will be loaded here -->
                    </div>
                    <div style="margin-top: 16px; padding: 12px; background: #e3f2fd; border-radius: 8px; border-left: 4px solid #1976d2;">
                        <p style="margin: 0; color: #1976d2; font-size: 13px; text-align: center;">
                            <strong>💡 Lưu ý:</strong> Vui lòng điền đầy đủ thông tin giao hàng và nhấn <strong>"Xác nhận thanh toán"</strong> để hoàn tất đơn hàng.
                        </p>
                    </div>
                </div>

                <!-- COD Info (hiển thị mặc định) -->
                <div class="cod-info" id="codInfo" style="padding: 20px; background: #e8f5e9; border-radius: 12px; border: 2px solid #4caf50; margin-top: 20px;">
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <span style="font-size: 32px;">✓</span>
                        <div>
                            <p style="margin: 0 0 4px 0; font-weight: 600; color: #2e7d32; font-size: 16px;">
                                Thanh toán khi nhận hàng
                            </p>
                            <p style="margin: 0; color: #388e3c; font-size: 14px;">
                                Bạn sẽ thanh toán bằng tiền mặt khi nhận được đơn hàng. Vui lòng chuẩn bị đúng số tiền.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Nút hành động -->
            <div class="checkout-actions">
                <a href="/CartView" class="btn-back">← Quay lại giỏ hàng</a>
                <button type="submit" class="btn-submit" id="submitBtn">
                    Xác nhận thanh toán
                </button>
            </div>
        </form>
    `;
    
    // Setup default payment method
    selectedPaymentMethod = 'cod';
    setupPaymentDefault();
}

    // ===============================
    // Build HTML cho danh sách sản phẩm
    // ===============================
    function buildItemsHTML() {
    if (!cartData || cartData.length === 0) {
        return '<p style="color: red; text-align: center; padding: 20px;">Không có sản phẩm nào.</p>';
    }
    
    return cartData.map((item, index) => {
        try {
            // Parse dữ liệu - API trả về PascalCase
            const productDetail = item.productDetail || item.ProductDetail;
            if (!productDetail) {
                console.warn(`Item ${index} missing productDetail:`, item);
                return '';
            }
            
            const product = productDetail.product || productDetail.Product;
            const productName = product?.ProductName || product?.productName || 
                               product?.Name || product?.name || 'Sản phẩm không tên';
            
            const productSize = productDetail.productSize || productDetail.ProductSize;
            const sizeName = productSize?.SizeName || productSize?.sizeName || 
                            productSize?.Name || productSize?.name || 'Không xác định';
            
            const priceValue = productDetail.Price || productDetail.price || 0;
            const price = parseFloat(priceValue) || 0;
            const quantity = item.Quantity || item.quantity || 0;
            const subtotal = price * quantity;
            
            // Parse ảnh sản phẩm
            const productImages = product?.productImages || product?.ProductImages || product?.product_images || [];
            let imageUrl = '';
            
            if (productImages && productImages.length > 0) {
                const firstImage = productImages[0];
                imageUrl = firstImage?.ImageUrl || firstImage?.imageUrl || 
                          firstImage?.Url || firstImage?.url || '';
            }
            
            // Fallback nếu không có ảnh
            if (!imageUrl) {
                const productId = product?.ID || product?.id || productDetail?.ProductID || productDetail?.productID || index;
                imageUrl = `https://picsum.photos/seed/${productId}/200/200`;
            }
            
            console.log(`Item ${index + 1}: ${productName}, Size: ${sizeName}, Qty: ${quantity}, Price: ${price}, Image: ${imageUrl}`);
            
            return `
                <div class="summary-item" style="display: flex; gap: 16px; align-items: flex-start;">
                    <div style="flex-shrink: 0;">
                        <img src="${escapeHtml(imageUrl)}" 
                             alt="${escapeHtml(productName)}" 
                             style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px; border: 2px solid #eee;"
                             onerror="this.src='https://picsum.photos/seed/${index}/200/200';" />
                    </div>
                    <div style="flex: 1;">
                        <strong style="font-size: 17px; color: #111; display: block; margin-bottom: 8px;">
                            ${escapeHtml(productName)}
                        </strong>
                        <div style="display: flex; flex-wrap: wrap; gap: 8px; align-items: center;">
                            <span style="background: #e3f2fd; color: #1976d2; padding: 4px 10px; border-radius: 6px; font-size: 13px; font-weight: 600;">
                                📏 Size: <strong>${escapeHtml(sizeName)}</strong>
                            </span>
                            <span style="background: #fff3e0; color: #f57c00; padding: 4px 10px; border-radius: 6px; font-size: 13px; font-weight: 600;">
                                ✖️ Số lượng: <strong>${quantity}</strong>
                            </span>
                            <span style="background: #f3e5f5; color: #7b1fa2; padding: 4px 10px; border-radius: 6px; font-size: 13px; font-weight: 600;">
                                💰 Đơn giá: <strong>${formatPrice(price)}</strong>
                            </span>
                        </div>
                    </div>
                    <div style="font-weight: 800; font-size: 18px; color: #e31d14; margin-left: 16px; white-space: nowrap; flex-shrink: 0;">
                        ${formatPrice(subtotal)}
                    </div>
                </div>
            `;
        } catch (error) {
            console.error(`Error building item ${index}:`, error);
            return '';
        }
    }).filter(html => html !== '').join('');
}

    // ===============================
    // Build HTML cho phương thức thanh toán
    // ===============================
    function buildPaymentMethodsHTML() {
    if (!paymentMethods || paymentMethods.length === 0) {
        return '<p style="color: #666; text-align: center; padding: 20px;">Không có phương thức thanh toán nào.</p>';
    }
    
    return paymentMethods.map((method) => {
        const isActive = method.code === 'cod';
        const radioId = `payment${method.code.charAt(0).toUpperCase() + method.code.slice(1)}`;
        
        return `
            <div class="payment-method ${isActive ? 'active' : ''}" 
                 onclick="selectPayment('${method.code}')" 
                 data-method="${method.code}">
                <input type="radio" id="${radioId}" name="paymentMethod" value="${method.code}" ${isActive ? 'checked' : ''} />
                <label for="${radioId}" style="cursor: pointer; display: block;">
                    <div style="font-size: 32px; margin-bottom: 8px;">${method.icon || '💳'}</div>
                    <div style="font-weight: 700; font-size: 16px; color: #111; margin-bottom: 6px;">
                        ${escapeHtml(method.name)}
                    </div>
                    <div style="font-size: 13px; color: #666; line-height: 1.5;">
                        ${escapeHtml(method.description)}
                    </div>
                </label>
            </div>
        `;
    }).join('');
}

    // ===============================
    // Setup payment method default
    // ===============================
    function setupPaymentDefault() {
    selectedPaymentMethod = 'cod';
    
    const codInfo = document.getElementById('codInfo');
    const qrContainer = document.getElementById('qrCodeContainer');
    
    if (codInfo) codInfo.style.display = 'block';
    if (qrContainer) qrContainer.style.display = 'none';
    
    // Set active state
    setTimeout(() => {
        const codMethod = document.querySelector('.payment-method[data-method="cod"]');
        if (codMethod) codMethod.classList.add('active');
        const codRadio = document.getElementById('paymentCod');
        if (codRadio) codRadio.checked = true;
    }, 100);
}

    // ===============================
    // Chọn phương thức thanh toán
    // ===============================
    function selectPayment(method) {
    console.log('Selecting payment method:', method);
    selectedPaymentMethod = method;
    
    // Remove active from all
    document.querySelectorAll('.payment-method').forEach(el => {
        el.classList.remove('active');
    });
    
    // Add active to selected
    const selected = document.querySelector(`.payment-method[data-method="${method}"]`);
    if (selected) selected.classList.add('active');
    
    // Update radio
    const radioId = `payment${method.charAt(0).toUpperCase() + method.slice(1)}`;
    const radio = document.getElementById(radioId);
    if (radio) radio.checked = true;
    
    // Show/hide info
    const codInfo = document.getElementById('codInfo');
    const qrContainer = document.getElementById('qrCodeContainer');
    
    if (method === 'bank') {
        if (qrContainer) {
            qrContainer.style.display = 'block';
            loadBankInfo();
        }
        if (codInfo) codInfo.style.display = 'none';
    } else {
        if (qrContainer) qrContainer.style.display = 'none';
        if (codInfo) codInfo.style.display = 'block';
    }
}

    // ===============================
    // Load thông tin ngân hàng
    // ===============================
    async function loadBankInfo() {
    try {
        console.log('Loading bank info...');
        const accountId = getAccountId();
        const orderCode = 'FF' + Date.now();
        
        const [qrRes, bankRes] = await Promise.all([
            fetch(`/api/payment/qr-code?orderCode=${orderCode}&amount=${cartTotal}&accountId=${accountId || ''}`),
            fetch('/api/payment/bank-info')
        ]);
        
        if (qrRes.ok && bankRes.ok) {
            const qrData = await qrRes.json();
            const bankData = await bankRes.json();
            
            console.log('QR Data:', qrData);
            console.log('Bank Data:', bankData);
            
            // Update QR code
            const qrImg = document.getElementById('qrCodeImage');
            if (qrImg) {
                if (qrData.qrCodeUrl || qrData.qrCode || qrData.url) {
                    qrImg.src = qrData.qrCodeUrl || qrData.qrCode || qrData.url;
                    qrImg.style.display = 'block';
                    qrImg.style.maxWidth = '250px';
                    qrImg.style.width = '250px';
                    qrImg.style.height = '250px';
                    qrImg.style.objectFit = 'contain';
                    qrImg.style.borderRadius = '12px';
                    qrImg.style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.15)';
                    qrImg.style.border = '3px solid #e31d14';
                    qrImg.style.padding = '12px';
                    qrImg.style.background = '#fff';
                    qrImg.style.margin = '0 auto 20px auto';
                    qrImg.onerror = function() {
                        console.error('QR Code image failed to load');
                        this.style.display = 'none';
                    };
                } else {
                    console.warn('No QR code URL in response');
                    qrImg.style.display = 'none';
                }
            }
            
            // Update bank info
            const bankInfoContainer = document.getElementById('bankInfoContainer');
            if (bankInfoContainer) {
                // Sử dụng orderCode từ QR code API
                const transferContent = qrData.transferContent || qrData.orderCode || orderCode;
                
                bankInfoContainer.innerHTML = `
                    <p style="margin: 0 0 12px 0; font-weight: 700; color: #333; font-size: 16px; text-align: center;">Thông tin chuyển khoản:</p>
                    <div style="display: flex; flex-direction: column; gap: 8px; text-align: left; word-wrap: break-word; overflow-wrap: break-word;">
                        <p style="margin: 0; color: #666; word-wrap: break-word; overflow-wrap: break-word;"><strong style="color: #111; min-width: 140px; display: inline-block;">Ngân hàng:</strong> <span style="word-break: break-word;">${escapeHtml(bankData.bankName || bankData.bank || 'N/A')}</span></p>
                        <p style="margin: 0; color: #666; word-wrap: break-word; overflow-wrap: break-word;"><strong style="color: #111; min-width: 140px; display: inline-block;">Số tài khoản:</strong> <span style="word-break: break-word;">${escapeHtml(bankData.accountNumber || bankData.account || 'N/A')}</span></p>
                        <p style="margin: 0; color: #666; word-wrap: break-word; overflow-wrap: break-word;"><strong style="color: #111; min-width: 140px; display: inline-block;">Chủ tài khoản:</strong> <span style="word-break: break-word;">${escapeHtml(bankData.accountHolder || bankData.holder || 'N/A')}</span></p>
                        ${(bankData.branch || bankData.branchName) ? `<p style="margin: 0; color: #666; word-wrap: break-word; overflow-wrap: break-word;"><strong style="color: #111; min-width: 140px; display: inline-block;">Chi nhánh:</strong> <span style="word-break: break-word;">${escapeHtml(bankData.branch || bankData.branchName)}</span></p>` : ''}
                        <p style="margin: 12px 0 0 0; color: #e31d14; font-weight: 700; font-size: 15px; padding-top: 12px; border-top: 2px solid #e31d14; word-wrap: break-word; overflow-wrap: break-word;">
                            <strong style="color: #111; min-width: 140px; display: inline-block;">Nội dung thanh toán:</strong> 
                            <span style="color: #e31d14; font-weight: 700; word-break: break-word;">${escapeHtml(transferContent)}</span>
                        </p>
                    </div>
                `;
            }
        } else {
            console.error('Failed to load bank info:', { qrRes: qrRes.status, bankRes: bankRes.status });
            // Fallback: Hiển thị thông tin ngân hàng mặc định
            const bankInfoContainer = document.getElementById('bankInfoContainer');
            if (bankInfoContainer) {
                bankInfoContainer.innerHTML = `
                    <p style="margin: 0 0 12px 0; font-weight: 700; color: #333; font-size: 16px; text-align: center;">Thông tin chuyển khoản:</p>
                    <div style="display: flex; flex-direction: column; gap: 8px; text-align: left; word-wrap: break-word; overflow-wrap: break-word;">
                        <p style="margin: 0; color: #666;"><strong style="color: #111; min-width: 140px; display: inline-block;">Ngân hàng:</strong> MBank</p>
                        <p style="margin: 0; color: #666;"><strong style="color: #111; min-width: 140px; display: inline-block;">Số tài khoản:</strong> 076836043</p>
                        <p style="margin: 0; color: #666;"><strong style="color: #111; min-width: 140px; display: inline-block;">Chủ tài khoản:</strong> Nguyễn Công Danh</p>
                        <p style="margin: 0; color: #666;"><strong style="color: #111; min-width: 140px; display: inline-block;">Chi nhánh:</strong> TP. Hồ Chí Minh</p>
                        <p style="margin: 12px 0 0 0; color: #e31d14; font-weight: 700; font-size: 15px; padding-top: 12px; border-top: 2px solid #e31d14;">
                            <strong style="color: #111; min-width: 140px; display: inline-block;">Nội dung thanh toán:</strong> 
                            <span style="color: #e31d14; font-weight: 700;">${escapeHtml(orderCode)}</span>
                        </p>
                    </div>
                `;
            }
        }
    } catch (error) {
        console.error('Error loading bank info:', error);
        // Fallback: Hiển thị thông tin ngân hàng mặc định
        const bankInfoContainer = document.getElementById('bankInfoContainer');
        if (bankInfoContainer) {
            const orderCode = 'FF' + Date.now();
            bankInfoContainer.innerHTML = `
                <p style="margin: 0 0 12px 0; font-weight: 700; color: #333; font-size: 16px; text-align: center;">Thông tin chuyển khoản:</p>
                <div style="display: flex; flex-direction: column; gap: 8px; text-align: left; word-wrap: break-word; overflow-wrap: break-word;">
                    <p style="margin: 0; color: #666;"><strong style="color: #111; min-width: 140px; display: inline-block;">Ngân hàng:</strong> MBank</p>
                    <p style="margin: 0; color: #666;"><strong style="color: #111; min-width: 140px; display: inline-block;">Số tài khoản:</strong> 076836043</p>
                    <p style="margin: 0; color: #666;"><strong style="color: #111; min-width: 140px; display: inline-block;">Chủ tài khoản:</strong> Nguyễn Công Danh</p>
                    <p style="margin: 0; color: #666;"><strong style="color: #111; min-width: 140px; display: inline-block;">Chi nhánh:</strong> TP. Hồ Chí Minh</p>
                    <p style="margin: 12px 0 0 0; color: #e31d14; font-weight: 700; font-size: 15px; padding-top: 12px; border-top: 2px solid #e31d14;">
                        <strong style="color: #111; min-width: 140px; display: inline-block;">Nội dung thanh toán:</strong> 
                        <span style="color: #e31d14; font-weight: 700;">${escapeHtml(orderCode)}</span>
                    </p>
                </div>
            `;
        }
    }
}

    // ===============================
    // Xử lý submit form
    // Lưu ý: Thanh toán QR hoạt động giống COD - chỉ lưu paymentMethod vào order,
    // không có xử lý thanh toán thật sự qua QR. User có thể chọn QR payment
    // và submit form bình thường để tạo đơn hàng.
    // ===============================
    async function handleSubmit(event) {
    event.preventDefault();
    
    console.log('Submitting checkout form...');
    
        // Show Ratatouille loader (center screen)
        if (window.showRatatouilleLoader) {
            window.showRatatouilleLoader('Đang xử lý thanh toán...');
        }
        
        const submitBtn = document.getElementById('submitBtn');
        if (submitBtn && window.showButtonLoading) {
            window.showButtonLoading(submitBtn, 'Đang xử lý...');
        } else if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.textContent = 'Đang xử lý...';
        }
    
    // Get form data
    const customerName = document.getElementById('customerName')?.value.trim() || '';
    const phoneNumber = document.getElementById('phoneNumber')?.value.trim() || '';
    const address = document.getElementById('address')?.value.trim() || '';
    const paymentMethodRadio = document.querySelector('input[name="paymentMethod"]:checked');
    // Lấy payment method đã chọn (cod hoặc bank) - cả 2 đều hoạt động giống nhau
    const paymentMethod = paymentMethodRadio ? paymentMethodRadio.value : 'cod';
    
    // Validation
    if (!customerName || !phoneNumber || !address) {
        alert('Vui lòng điền đầy đủ thông tin!');
        if (submitBtn && window.hideButtonLoading) {
            window.hideButtonLoading(submitBtn);
        } else if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Xác nhận thanh toán';
        }
        return;
    }
    
    try {
        console.log('Submitting to API:', { customerName, phoneNumber, address, paymentMethod });
        console.log('Payment method:', paymentMethod === 'bank' ? 'QR Payment (simplified - same as COD)' : 'COD');
        
        // Gọi API checkout - hoạt động giống nhau cho cả COD và QR payment
        const response = await fetch('/api/cart/checkout', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                accountId: getAccountId(),
                customerName: customerName,
                phoneNumber: phoneNumber,
                address: address,
                paymentMethod: paymentMethod, // "cod" hoặc "bank" - cả 2 đều tạo order bình thường
                shippingFee: shippingFee // Phí ship
            })
        });
        
        if (!response.ok) {
            // Kiểm tra content-type trước khi parse JSON
            const contentType = response.headers.get('content-type');
            if (contentType && contentType.includes('application/json')) {
                try {
                    const errorData = await response.json();
                    throw new Error(errorData.message || 'Thanh toán thất bại');
                } catch (jsonError) {
                    throw new Error(`Lỗi: ${response.status} ${response.statusText}`);
                }
            } else {
                // Server trả về HTML error page
                const errorText = await response.text();
                console.error('Server response (not JSON):', errorText.substring(0, 200));
                throw new Error(`Lỗi server: ${response.status} ${response.statusText}. Vui lòng thử lại sau.`);
            }
        }
        
        // Kiểm tra content-type trước khi parse JSON
        const contentType = response.headers.get('content-type');
        if (!contentType || !contentType.includes('application/json')) {
            const text = await response.text();
            console.error('Response is not JSON:', text.substring(0, 200));
            throw new Error('Server trả về dữ liệu không hợp lệ. Vui lòng thử lại.');
        }
        
        const data = await response.json();
        console.log('✅ Checkout successful:', data);
        
        // Hide Ratatouille loader before redirect
        if (window.hideRatatouilleLoader) {
            window.hideRatatouilleLoader();
        }
        
        // Redirect to success page
        // Use redirectUrl from response if available, otherwise construct from orderId
        if (data.redirectUrl) {
            // Server provides redirect URL
            console.log('Redirecting to:', data.redirectUrl);
            window.location.replace(data.redirectUrl);
        } else if (data.success && (data.orderId || data.order_id)) {
            const orderId = data.orderId || data.order_id;
            console.log('Redirecting to success page with orderId:', orderId);
            window.location.replace(`/Checkout/Success/${orderId}`);
        } else if (data.orderId || data.order_id) {
            // Fallback: use orderId directly
            const orderId = data.orderId || data.order_id;
            console.log('Redirecting to success page (fallback):', orderId);
            window.location.replace(`/Checkout/Success/${orderId}`);
        } else if (data.orderCode || data.order_code) {
            // Last resort: show alert and go to orders page
            alert(`Thanh toán thành công!\nMã đơn hàng: ${data.orderCode || data.order_code}`);
            window.location.replace(`/Orders`);
        } else {
            console.error('❌ Invalid response from server:', data);
            throw new Error('Không nhận được thông tin đơn hàng từ server');
        }
        
    } catch (error) {
        console.error('Checkout error:', error);
        // Hide Ratatouille loader on error
        if (window.hideRatatouilleLoader) {
            window.hideRatatouilleLoader();
        }
        alert(error.message || 'Có lỗi xảy ra khi thanh toán. Vui lòng thử lại!');
        if (submitBtn && window.hideButtonLoading) {
            window.hideButtonLoading(submitBtn);
        } else if (submitBtn) {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Xác nhận thanh toán';
        }
    }
}

    // ===============================
    // Utility functions
    // ===============================
    function formatPrice(amount) {
        return parseFloat(amount || 0).toLocaleString('vi-VN') + 'đ';
    }

    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // ===============================
    // Export functions
    // ===============================
    window.selectPayment = selectPayment;
    window.handleSubmit = handleSubmit;
    
})(); // End IIFE
