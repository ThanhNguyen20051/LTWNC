using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using FFoodsStore.ViewModels;

namespace FFoodsStore.Controllers
{
    public class MenuController : Controller
    {
        private readonly StoreDbContext _db;
        public MenuController(StoreDbContext db) => _db = db;

        [HttpGet]
        public async Task<IActionResult> Index(string? q, string? cat)
        {
            // ===== Lấy ID loại theo slug =====
            List<int> filterTypeIds = new();
            if (!string.IsNullOrWhiteSpace(cat))
            {
                var typeRows = await _db.Set<ProductType>()
                    .Where(t => t.IsDelete == null || t.IsDelete == false)
                    .Select(t => new { t.ID, t.TypeCode, t.TypeName })
                    .ToListAsync();

                filterTypeIds = typeRows
                    .Select(t => new { t.ID, Slug = Slug(t.TypeCode ?? t.TypeName ?? "other") })
                    .Where(x => x.Slug == cat)
                    .Select(x => x.ID)
                    .ToList();
            }

            // ===== JOIN Product + Type + Detail + Image =====
            var baseQuery =
                from p in _db.Set<Product>()
                join pt in _db.Set<ProductType>() on p.ProductTypeID equals pt.ID
                join pd in _db.Set<ProductDetail>() on p.ID equals pd.ProductID
                join pi in _db.Set<ProductImage>() on p.ID equals pi.ProductID into imgGroup
                from pi in imgGroup.DefaultIfEmpty()
                where (p.IsDeleted == null || p.IsDeleted == false)
                      && (p.IsActive == true)
                      && (pd.IsDelete == null || pd.IsDelete == false)
                      && (pd.Price != null && pd.Price > 0)
                      && (pt.IsDelete == null || pt.IsDelete == false)
                select new
                {
                    Product = p,
                    Type = pt,
                    Detail = pd,
                    Image = pi
                };

            // ===== Lọc theo tên =====
            if (!string.IsNullOrWhiteSpace(q))
            {
                baseQuery = baseQuery.Where(x => EF.Functions.Like(x.Product.ProductName ?? "", $"%{q}%"));
            }

            // ===== Lọc theo loại =====
            if (filterTypeIds.Count > 0)
            {
                baseQuery = baseQuery.Where(x => filterTypeIds.Contains(x.Type.ID));
            }
            else if (!string.IsNullOrWhiteSpace(cat))
            {
                baseQuery = baseQuery.Where(x => false);
            }

            // ===== Chuyển sang LINQ thuần (fix lỗi EF Core không dịch GroupBy) =====
            var list = await baseQuery.ToListAsync();

            Console.WriteLine($"[MENU] Index - Found {list.Count} raw items after query (q={q}, cat={cat})");

            var items = list
                .GroupBy(x => new { x.Product, x.Type })
                .Select(g => new MenuItemVM
                {
                    ProductDetailId = g.Min(x => x.Detail.ID),
                    ProductId = g.Key.Product.ID,
                    Name = g.Key.Product.ProductName ?? "",
                    TypeName = g.Key.Type.TypeName ?? "Khác",
                    TypeSlug = Slug(g.Key.Type.TypeCode ?? g.Key.Type.TypeName ?? "other"),
                    Price = g.Min(x => x.Detail.Price) ?? 0,
                    // Get the most recent non-deleted image from the group (from join)
                    ImageUrl = FixImage(
                        g.Where(x => x.Image != null && (x.Image.IsDelete == null || x.Image.IsDelete == false))
                         .Select(x => x.Image)
                         .OrderByDescending(pi => pi.ID)
                         .FirstOrDefault()?.ImageUrl,
                        $"https://picsum.photos/seed/p-{g.Key.Product.ID}/800/450")
                })
                .OrderBy(x => x.Name)
                .ToList();

            Console.WriteLine($"[MENU] Index - Returning {items.Count} grouped items");
            if (items.Count > 0)
            {
                Console.WriteLine($"[MENU] Sample products: {string.Join(", ", items.Take(3).Select(i => $"{i.Name}(ID:{i.ProductId})"))}");
            }

            var vm = new MenuVM { Q = q, Cat = cat, Items = items };
            return View(vm);
        }

        // ===== Helper tạo slug tiếng Việt =====
        private static string Slug(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return "other";
            s = s.ToLowerInvariant();
            var repl = new Dictionary<string, string> {
                { " ", "-" }, { "/", "-" }, { "\\", "-" }, { "_", "-" },
                { "ă","a" }, { "â","a" }, { "á","a" }, { "à","a" }, { "ả","a" }, { "ã","a" }, { "ạ","a" },
                { "ê","e" }, { "é","e" }, { "è","e" }, { "ẻ","e" }, { "ẽ","e" }, { "ẹ","e" },
                { "ô","o" }, { "ơ","o" }, { "ó","o" }, { "ò","o" }, { "ỏ","o" }, { "õ","o" }, { "ọ","o" },
                { "ư","u" }, { "ú","u" }, { "ù","u" }, { "ủ","u" }, { "ũ","u" }, { "ụ","u" },
                { "í","i" }, { "ì","i" }, { "ỉ","i" }, { "ĩ","i" }, { "ị","i" },
                { "ý","y" }, { "ỳ","y" }, { "ỷ","y" }, { "ỹ","y" }, { "ỵ","y" },
                { "đ","d" }
            };
            foreach (var kv in repl) s = s.Replace(kv.Key, kv.Value);
            return s;
        }

        // ✅ FIX ẢNH (local, null, hoặc sai định dạng)
        private static string FixImage(string? img, string fallback)
        {
            if (string.IsNullOrWhiteSpace(img))
                return fallback;

            img = img.Trim();

            // Nếu là đường dẫn http => giữ nguyên
            if (img.StartsWith("http", StringComparison.OrdinalIgnoreCase))
                return img;

            // Bỏ "~" nếu có
            if (img.StartsWith("~/"))
                img = img[1..];

            // Loại bỏ duplicate /images/ nếu có
            while (img.StartsWith("/images/images/", StringComparison.OrdinalIgnoreCase))
                img = img.Substring(7); // Bỏ "/images"

            // Đảm bảo bắt đầu bằng "/"
            if (!img.StartsWith("/"))
                img = "/" + img;

            // Nếu không có /images/ trong path và không phải http, thêm /images/uploads/
            if (!img.StartsWith("/images/", StringComparison.OrdinalIgnoreCase) && !img.StartsWith("http", StringComparison.OrdinalIgnoreCase))
            {
                // Nếu path bắt đầu bằng /products/ hoặc /uploads/, thêm /images
                if (img.StartsWith("/products/") || img.StartsWith("/uploads/"))
                    img = "/images" + img;
                else
                    img = "/images/uploads" + img;
            }

            return img;
        }

        // ===== API: Lấy danh sách món ăn với phân trang, filter và search =====
        [HttpGet("/api/menu/items")]
        public async Task<IActionResult> GetMenuItems(string? q = null, string? cat = null, int page = 1, int pageSize = 12)
        {
            if (page < 1) page = 1;
            if (pageSize < 1) pageSize = 12;

            // ===== Lấy ID loại theo slug =====
            List<int> filterTypeIds = new();
            if (!string.IsNullOrWhiteSpace(cat) && cat != "all")
            {
                var typeRows = await _db.Set<ProductType>()
                    .Where(t => t.IsDelete == null || t.IsDelete == false)
                    .Select(t => new { t.ID, t.TypeCode, t.TypeName })
                    .ToListAsync();

                filterTypeIds = typeRows
                    .Select(t => new { t.ID, Slug = Slug(t.TypeCode ?? t.TypeName ?? "other") })
                    .Where(x => x.Slug == cat)
                    .Select(x => x.ID)
                    .ToList();
            }

            // ===== JOIN Product + Type + Detail + Image =====
            var baseQuery =
                from p in _db.Set<Product>()
                join pt in _db.Set<ProductType>() on p.ProductTypeID equals pt.ID
                join pd in _db.Set<ProductDetail>() on p.ID equals pd.ProductID
                join pi in _db.Set<ProductImage>() on p.ID equals pi.ProductID into imgGroup
                from pi in imgGroup.DefaultIfEmpty()
                where (p.IsDeleted == null || p.IsDeleted == false)
                      && (p.IsActive == true)
                      && (pd.IsDelete == null || pd.IsDelete == false)
                      && (pd.Price != null && pd.Price > 0)
                      && (pt.IsDelete == null || pt.IsDelete == false)
                select new
                {
                    Product = p,
                    Type = pt,
                    Detail = pd,
                    Image = pi
                };

            // ===== Lọc theo tên =====
            if (!string.IsNullOrWhiteSpace(q))
            {
                baseQuery = baseQuery.Where(x => EF.Functions.Like(x.Product.ProductName ?? "", $"%{q}%"));
            }

            // ===== Lọc theo loại =====
            if (filterTypeIds.Count > 0)
            {
                baseQuery = baseQuery.Where(x => filterTypeIds.Contains(x.Type.ID));
            }
            else if (!string.IsNullOrWhiteSpace(cat) && cat != "all")
            {
                baseQuery = baseQuery.Where(x => false);
            }

            // ===== Chuyển sang LINQ thuần (fix lỗi EF Core không dịch GroupBy) =====
            var list = await baseQuery.ToListAsync();

            Console.WriteLine($"[MENU API] GetMenuItems - Found {list.Count} raw items after query");

            var groupedItems = list
                .GroupBy(x => new { x.Product, x.Type })
                .Select(g => new MenuItemVM
                {
                    ProductDetailId = g.Min(x => x.Detail.ID),
                    ProductId = g.Key.Product.ID,
                    Name = g.Key.Product.ProductName ?? "",
                    TypeName = g.Key.Type.TypeName ?? "Khác",
                    TypeSlug = Slug(g.Key.Type.TypeCode ?? g.Key.Type.TypeName ?? "other"),
                    Price = g.Min(x => x.Detail.Price) ?? 0,
                    // Get the most recent non-deleted image from the group (from join)
                    ImageUrl = FixImage(
                        g.Where(x => x.Image != null && (x.Image.IsDelete == null || x.Image.IsDelete == false))
                         .Select(x => x.Image)
                         .OrderByDescending(pi => pi.ID)
                         .FirstOrDefault()?.ImageUrl,
                        $"https://picsum.photos/seed/p-{g.Key.Product.ID}/800/450")
                })
                .OrderBy(x => x.Name)
                .ToList();

            var total = groupedItems.Count;
            var items = groupedItems.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            Console.WriteLine($"[MENU API] GetMenuItems - Returning {items.Count} items (page {page}/{Math.Ceiling(total / (double)pageSize)}, total: {total})");
            if (items.Count > 0)
            {
                Console.WriteLine($"[MENU API] Sample products: {string.Join(", ", items.Take(3).Select(i => $"{i.Name}(ID:{i.ProductId})"))}");
            }

            return Json(new
            {
                Total = total,
                Page = page,
                PageSize = pageSize,
                TotalPages = (int)Math.Ceiling(total / (double)pageSize),
                Items = items
            });
        }

        // ===== API: Lấy danh sách các loại món ăn (categories) =====
        [HttpGet("/api/menu/categories")]
        public async Task<IActionResult> GetCategories()
        {
            var categories = await _db.Set<ProductType>()
                .Where(t => t.IsDelete == null || t.IsDelete == false)
                .Select(t => new
                {
                    ID = t.ID,
                    Name = t.TypeName ?? "Khác",
                    Slug = Slug(t.TypeCode ?? t.TypeName ?? "other")
                })
                .OrderBy(t => t.Name)
                .ToListAsync();

            return Json(new { Categories = categories });
        }
    }
}
