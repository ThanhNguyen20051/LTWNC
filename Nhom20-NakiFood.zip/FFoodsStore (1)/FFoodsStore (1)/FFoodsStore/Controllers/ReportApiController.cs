using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using FFoodsStore.Models;
using static FFoodsStore.Models.OrderStatus;
using System.Linq;

namespace FFoodsStore.Controllers
{
    [ApiController]
    [Route("api/report")]
    public class ReportApiController : ControllerBase
    {
        private readonly StoreDbContext _context;

        public ReportApiController(StoreDbContext context)
        {
            _context = context;
        }

        // GET: api/report/revenue/daily
        [HttpGet("revenue/daily")]
        public async Task<IActionResult> GetDailyRevenue([FromQuery] DateTime? date = null)
        {
            try
            {
                var targetDate = date ?? DateTime.Today;
                // Đảm bảo xử lý đúng timezone - chuyển về local date
                var startDate = targetDate.Date;
                var endDate = startDate.AddDays(1);

                Console.WriteLine($"[ReportAPI] Daily report - StartDate: {startDate}, EndDate: {endDate}, TargetDate: {targetDate}");

                // Chỉ lấy đơn hàng đã hoàn thành (Completed) - giống logic Dashboard
                var orders = await _context.Orders
                    .Where(o => o.CreateDate.HasValue
                        && o.CreateDate.Value.Date >= startDate 
                        && o.CreateDate.Value.Date < endDate
                        && (o.IsDeleted == null || o.IsDeleted == false)
                        && o.Status == (int)OrderStatus.Completed)
                    .ToListAsync();

                Console.WriteLine($"[ReportAPI] Found {orders.Count} orders for date {targetDate:yyyy-MM-dd}");

                var orderIds = orders.Select(o => o.ID).ToList();

                // Lấy tất cả OrderDetails của các đơn hàng trong ngày
                var allOrderDetails = orderIds.Any()
                    ? await _context.OrderDetails
                        .Where(od => od.OrderID.HasValue && orderIds.Contains(od.OrderID.Value) 
                            && (od.IsDelete == null || od.IsDelete == false))
                        .ToListAsync()
                    : new List<Models.OrderDetail>();

                // Tính tổng doanh thu
                var totalRevenue = allOrderDetails.Sum(od => od.TotalMoney ?? 0);

                // Nhóm theo OrderID để tính tổng nhanh hơn
                var orderTotals = allOrderDetails
                    .GroupBy(od => od.OrderID)
                    .ToDictionary(g => g.Key ?? 0, g => g.Sum(od => od.TotalMoney ?? 0));

                var codRevenue = 0m;
                var onlineRevenue = 0m;
                var dineInRevenue = 0m;
                var deliveryRevenue = 0m;

                // Chỉ duyệt một lần thay vì 2 lần
                foreach (var order in orders)
                {
                    var orderTotal = orderTotals.GetValueOrDefault(order.ID, 0);

                    // Phân loại theo phương thức thanh toán
                    if (order.PaymentMethod == "cod" || string.IsNullOrEmpty(order.PaymentMethod))
                    {
                        codRevenue += orderTotal;
                    }
                    else
                    {
                        onlineRevenue += orderTotal;
                    }

                    // Phân loại theo loại đơn (Tại quầy vs Online)
                    var address = order.Address ?? "";
                    var isDineIn = address.Contains("Tại quầy", StringComparison.OrdinalIgnoreCase) 
                                || address.Contains("tại quầy", StringComparison.OrdinalIgnoreCase)
                                || address.Trim().ToLower() == "tại quầy";

                    if (isDineIn)
                    {
                        dineInRevenue += orderTotal;
                    }
                    else
                    {
                        deliveryRevenue += orderTotal;
                    }
                }

                return Ok(new
                {
                    date = targetDate.ToString("yyyy-MM-dd"),
                    totalRevenue = totalRevenue,
                    totalOrders = orders.Count,
                    paymentMethod = new
                    {
                        cod = codRevenue,
                        online = onlineRevenue
                    },
                    orderType = new
                    {
                        dineIn = dineInRevenue,
                        delivery = deliveryRevenue
                    }
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Lỗi khi lấy dữ liệu báo cáo", error = ex.Message });
            }
        }

        // GET: api/report/revenue/weekly
        [HttpGet("revenue/weekly")]
        public async Task<IActionResult> GetWeeklyRevenue([FromQuery] DateTime? startDate = null)
        {
            try
            {
                // Tính tuần từ Thứ 2 đến Chủ Nhật
                var today = startDate ?? DateTime.Today;
                var dayOfWeek = (int)today.DayOfWeek;
                
                // Chuyển đổi: Sunday = 0 -> 7, Monday = 1 -> 1, ..., Saturday = 6 -> 6
                // Để Thứ 2 = 1, Chủ Nhật = 7
                if (dayOfWeek == 0) dayOfWeek = 7;
                
                // Tính số ngày cần trừ để về Thứ 2 (dayOfWeek - 1)
                var start = today.AddDays(-(dayOfWeek - 1)).Date;
                var end = start.AddDays(7); // Thứ 2 + 7 ngày = Thứ 2 tuần sau (exclusive)

                // Chỉ lấy đơn hàng đã hoàn thành (Completed) - giống logic Dashboard
                var orders = await _context.Orders
                    .Where(o => o.CreateDate.HasValue
                        && o.CreateDate.Value >= start 
                        && o.CreateDate.Value < end
                        && (o.IsDeleted == null || o.IsDeleted == false)
                        && o.Status == (int)OrderStatus.Completed)
                    .ToListAsync();

                var orderIds = orders.Select(o => o.ID).ToList();

                // Lấy tất cả OrderDetails của các đơn hàng trong tuần
                var allOrderDetails = orderIds.Any()
                    ? await _context.OrderDetails
                        .Where(od => od.OrderID.HasValue && orderIds.Contains(od.OrderID.Value) 
                            && (od.IsDelete == null || od.IsDelete == false))
                        .ToListAsync()
                    : new List<Models.OrderDetail>();

                // Tính tổng doanh thu
                var totalRevenue = allOrderDetails.Sum(od => od.TotalMoney ?? 0);

                // Nhóm theo OrderID để tính tổng nhanh hơn
                var orderTotals = allOrderDetails
                    .GroupBy(od => od.OrderID)
                    .ToDictionary(g => g.Key ?? 0, g => g.Sum(od => od.TotalMoney ?? 0));

                var codRevenue = 0m;
                var onlineRevenue = 0m;
                var dineInRevenue = 0m;
                var deliveryRevenue = 0m;

                // Chỉ duyệt một lần thay vì 2 lần
                foreach (var order in orders)
                {
                    var orderTotal = orderTotals.GetValueOrDefault(order.ID, 0);

                    // Phân loại theo phương thức thanh toán
                    if (order.PaymentMethod == "cod" || string.IsNullOrEmpty(order.PaymentMethod))
                    {
                        codRevenue += orderTotal;
                    }
                    else
                    {
                        onlineRevenue += orderTotal;
                    }

                    // Phân loại theo loại đơn (Tại quầy vs Online)
                    var address = order.Address ?? "";
                    var isDineIn = address.Contains("Tại quầy", StringComparison.OrdinalIgnoreCase) 
                                || address.Contains("tại quầy", StringComparison.OrdinalIgnoreCase)
                                || address.Trim().ToLower() == "tại quầy";

                    if (isDineIn)
                    {
                        dineInRevenue += orderTotal;
                    }
                    else
                    {
                        deliveryRevenue += orderTotal;
                    }
                }

                // Doanh thu theo từng ngày trong tuần
                var dailyRevenue = new List<object>();
                for (var day = start; day < end; day = day.AddDays(1))
                {
                    var dayStart = day.Date;
                    var dayEnd = dayStart.AddDays(1);
                    
                    // Chỉ lấy đơn hàng đã hoàn thành trong ngày (Completed) - giống logic Dashboard
                    var dayOrderIds = await _context.Orders
                        .Where(o => o.CreateDate.HasValue
                            && o.CreateDate.Value >= dayStart 
                            && o.CreateDate.Value < dayEnd
                            && (o.IsDeleted == null || o.IsDeleted == false)
                            && o.Status == (int)OrderStatus.Completed)
                        .Select(o => o.ID)
                        .ToListAsync();

                    var dayRevenue = dayOrderIds.Any()
                        ? await _context.OrderDetails
                            .Where(od => od.OrderID.HasValue && dayOrderIds.Contains(od.OrderID.Value)
                                && (od.IsDelete == null || od.IsDelete == false))
                            .SumAsync(od => od.TotalMoney ?? 0)
                        : 0;

                    dailyRevenue.Add(new
                    {
                        date = dayStart.ToString("yyyy-MM-dd"),
                        dayName = dayStart.ToString("dddd", new System.Globalization.CultureInfo("vi-VN")),
                        revenue = dayRevenue
                    });
                }

                return Ok(new
                {
                    startDate = start.ToString("yyyy-MM-dd"),
                    endDate = end.ToString("yyyy-MM-dd"),
                    totalRevenue = totalRevenue,
                    totalOrders = orders.Count,
                    paymentMethod = new
                    {
                        cod = codRevenue,
                        online = onlineRevenue
                    },
                    orderType = new
                    {
                        dineIn = dineInRevenue,
                        delivery = deliveryRevenue
                    },
                    dailyRevenue = dailyRevenue
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Lỗi khi lấy dữ liệu báo cáo", error = ex.Message });
            }
        }

        // GET: api/report/products/daily
        [HttpGet("products/daily")]
        public async Task<IActionResult> GetDailyProductSales([FromQuery] DateTime? date = null)
        {
            try
            {
                var targetDate = date ?? DateTime.Today;
                var startDate = targetDate.Date;
                var endDate = startDate.AddDays(1);

                // Chỉ lấy đơn hàng đã hoàn thành trong ngày (Completed) - giống logic Dashboard
                var orders = await _context.Orders
                    .Where(o => o.CreateDate.HasValue
                        && o.CreateDate.Value.Date >= startDate 
                        && o.CreateDate.Value.Date < endDate
                        && (o.IsDeleted == null || o.IsDeleted == false)
                        && o.Status == (int)OrderStatus.Completed)
                    .Select(o => o.ID)
                    .ToListAsync();

                // Lấy OrderDetails với Product và ProductType
                var orderDetails = orders.Any()
                    ? await _context.OrderDetails
                        .Include(od => od.ProductDetail!)
                            .ThenInclude(pd => pd.Product!)
                                .ThenInclude(p => p.ProductType)
                        .Where(od => od.OrderID.HasValue && orders.Contains(od.OrderID.Value) 
                            && (od.IsDelete == null || od.IsDelete == false)
                            && od.ProductDetail != null
                            && od.ProductDetail.Product != null)
                        .ToListAsync()
                    : new List<Models.OrderDetail>();

                // Nhóm theo ProductType (Category)
                var categorySales = orderDetails
                    .GroupBy(od => od.ProductDetail?.Product?.ProductType?.TypeName ?? "Không phân loại")
                    .Select(g => new
                    {
                        categoryName = g.Key,
                        totalQuantity = g.Sum(od => od.Quantity ?? 0),
                        totalRevenue = g.Sum(od => od.TotalMoney ?? 0)
                    })
                    .OrderByDescending(x => x.totalQuantity)
                    .ToList();

                return Ok(new
                    {
                        date = targetDate.ToString("yyyy-MM-dd"),
                        categorySales = categorySales
                    });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Lỗi khi lấy dữ liệu sản phẩm", error = ex.Message });
            }
        }

        // GET: api/report/products/weekly
        [HttpGet("products/weekly")]
        public async Task<IActionResult> GetWeeklyProductSales([FromQuery] DateTime? startDate = null)
        {
            try
            {
                // Tính tuần từ Thứ 2 đến Chủ Nhật
                var today = startDate ?? DateTime.Today;
                var dayOfWeek = (int)today.DayOfWeek;
                if (dayOfWeek == 0) dayOfWeek = 7;
                var start = today.AddDays(-(dayOfWeek - 1)).Date;
                var end = start.AddDays(7);

                // Chỉ lấy đơn hàng đã hoàn thành trong tuần (Completed) - giống logic Dashboard
                var orders = await _context.Orders
                    .Where(o => o.CreateDate.HasValue
                        && o.CreateDate.Value.Date >= start 
                        && o.CreateDate.Value.Date < end
                        && (o.IsDeleted == null || o.IsDeleted == false)
                        && o.Status == (int)OrderStatus.Completed)
                    .Select(o => o.ID)
                    .ToListAsync();

                // Lấy OrderDetails với Product và ProductType
                var orderDetails = orders.Any()
                    ? await _context.OrderDetails
                        .Include(od => od.ProductDetail!)
                            .ThenInclude(pd => pd.Product!)
                                .ThenInclude(p => p.ProductType)
                        .Where(od => od.OrderID.HasValue && orders.Contains(od.OrderID.Value) 
                            && (od.IsDelete == null || od.IsDelete == false)
                            && od.ProductDetail != null
                            && od.ProductDetail.Product != null)
                        .ToListAsync()
                    : new List<Models.OrderDetail>();

                // Nhóm theo ProductType (Category)
                var categorySales = orderDetails
                    .GroupBy(od => od.ProductDetail?.Product?.ProductType?.TypeName ?? "Không phân loại")
                    .Select(g => new
                    {
                        categoryName = g.Key,
                        totalQuantity = g.Sum(od => od.Quantity ?? 0),
                        totalRevenue = g.Sum(od => od.TotalMoney ?? 0)
                    })
                    .OrderByDescending(x => x.totalQuantity)
                    .ToList();

                return Ok(new
                    {
                        startDate = start.ToString("yyyy-MM-dd"),
                        endDate = end.ToString("yyyy-MM-dd"),
                        categorySales = categorySales
                    });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Lỗi khi lấy dữ liệu sản phẩm", error = ex.Message });
            }
        }

        // GET: api/report/revenue/monthly
        [HttpGet("revenue/monthly")]
        public async Task<IActionResult> GetMonthlyRevenue([FromQuery] int? year = null, [FromQuery] int? month = null)
        {
            try
            {
                var targetYear = year ?? DateTime.Now.Year;
                var targetMonth = month ?? DateTime.Now.Month;
                
                // Tính ngày đầu tháng và ngày đầu tháng sau
                var start = new DateTime(targetYear, targetMonth, 1).Date;
                var end = start.AddMonths(1);

                Console.WriteLine($"[ReportAPI] Monthly report - StartDate: {start}, EndDate: {end}");

                // Chỉ lấy đơn hàng đã hoàn thành trong tháng (Completed) - giống logic Dashboard
                var orders = await _context.Orders
                    .Where(o => o.CreateDate.HasValue
                        && o.CreateDate.Value.Date >= start 
                        && o.CreateDate.Value.Date < end
                        && (o.IsDeleted == null || o.IsDeleted == false)
                        && o.Status == (int)OrderStatus.Completed)
                    .ToListAsync();

                var orderIds = orders.Select(o => o.ID).ToList();

                // Lấy tất cả OrderDetails của các đơn hàng trong tháng
                var allOrderDetails = orderIds.Any()
                    ? await _context.OrderDetails
                        .Where(od => od.OrderID.HasValue && orderIds.Contains(od.OrderID.Value) 
                            && (od.IsDelete == null || od.IsDelete == false))
                        .ToListAsync()
                    : new List<Models.OrderDetail>();

                // Tính tổng doanh thu
                var totalRevenue = allOrderDetails.Sum(od => od.TotalMoney ?? 0);

                // Nhóm theo OrderID để tính tổng nhanh hơn
                var orderTotals = allOrderDetails
                    .GroupBy(od => od.OrderID)
                    .ToDictionary(g => g.Key ?? 0, g => g.Sum(od => od.TotalMoney ?? 0));

                var codRevenue = 0m;
                var onlineRevenue = 0m;
                var dineInRevenue = 0m;
                var deliveryRevenue = 0m;

                // Chỉ duyệt một lần thay vì 2 lần
                foreach (var order in orders)
                {
                    var orderTotal = orderTotals.GetValueOrDefault(order.ID, 0);

                    // Phân loại theo phương thức thanh toán
                    if (order.PaymentMethod == "cod" || string.IsNullOrEmpty(order.PaymentMethod))
                    {
                        codRevenue += orderTotal;
                    }
                    else
                    {
                        onlineRevenue += orderTotal;
                    }

                    // Phân loại theo loại đơn (Tại quầy vs Online)
                    var address = order.Address ?? "";
                    var isDineIn = address.Contains("Tại quầy", StringComparison.OrdinalIgnoreCase) 
                                || address.Contains("tại quầy", StringComparison.OrdinalIgnoreCase)
                                || address.Trim().ToLower() == "tại quầy";

                    if (isDineIn)
                    {
                        dineInRevenue += orderTotal;
                    }
                    else
                    {
                        deliveryRevenue += orderTotal;
                    }
                }

                // Doanh thu theo từng ngày trong tháng
                var dailyRevenue = new List<object>();
                for (var day = start; day < end; day = day.AddDays(1))
                {
                    var dayStart = day.Date;
                    var dayEnd = dayStart.AddDays(1);
                    
                    // Chỉ lấy đơn hàng đã hoàn thành trong ngày (Completed) - giống logic Dashboard
                    var dayOrderIds = await _context.Orders
                        .Where(o => o.CreateDate.HasValue
                            && o.CreateDate.Value.Date >= dayStart 
                            && o.CreateDate.Value.Date < dayEnd
                            && (o.IsDeleted == null || o.IsDeleted == false)
                            && o.Status == (int)OrderStatus.Completed)
                        .Select(o => o.ID)
                        .ToListAsync();

                    var dayRevenue = dayOrderIds.Any()
                        ? await _context.OrderDetails
                            .Where(od => od.OrderID.HasValue && dayOrderIds.Contains(od.OrderID.Value)
                                && (od.IsDelete == null || od.IsDelete == false))
                            .SumAsync(od => od.TotalMoney ?? 0)
                        : 0;

                    dailyRevenue.Add(new
                    {
                        date = dayStart.ToString("yyyy-MM-dd"),
                        dayName = dayStart.ToString("dddd", new System.Globalization.CultureInfo("vi-VN")),
                        revenue = dayRevenue
                    });
                }

                return Ok(new
                {
                    year = targetYear,
                    month = targetMonth,
                    startDate = start.ToString("yyyy-MM-dd"),
                    endDate = end.ToString("yyyy-MM-dd"),
                    totalRevenue = totalRevenue,
                    totalOrders = orders.Count,
                    paymentMethod = new
                    {
                        cod = codRevenue,
                        online = onlineRevenue
                    },
                    orderType = new
                    {
                        dineIn = dineInRevenue,
                        delivery = deliveryRevenue
                    },
                    dailyRevenue = dailyRevenue
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Lỗi khi lấy dữ liệu báo cáo", error = ex.Message });
            }
        }

        // GET: api/report/products/monthly
        [HttpGet("products/monthly")]
        public async Task<IActionResult> GetMonthlyProductSales([FromQuery] int? year = null, [FromQuery] int? month = null)
        {
            try
            {
                var targetYear = year ?? DateTime.Now.Year;
                var targetMonth = month ?? DateTime.Now.Month;
                
                var start = new DateTime(targetYear, targetMonth, 1).Date;
                var end = start.AddMonths(1);

                // Chỉ lấy đơn hàng đã hoàn thành trong tháng (Completed) - giống logic Dashboard
                var orders = await _context.Orders
                    .Where(o => o.CreateDate.HasValue
                        && o.CreateDate.Value.Date >= start 
                        && o.CreateDate.Value.Date < end
                        && (o.IsDeleted == null || o.IsDeleted == false)
                        && o.Status == (int)OrderStatus.Completed)
                    .Select(o => o.ID)
                    .ToListAsync();

                // Lấy OrderDetails với Product và ProductType
                var orderDetails = orders.Any()
                    ? await _context.OrderDetails
                        .Include(od => od.ProductDetail!)
                            .ThenInclude(pd => pd.Product!)
                                .ThenInclude(p => p.ProductType)
                        .Where(od => od.OrderID.HasValue && orders.Contains(od.OrderID.Value) 
                            && (od.IsDelete == null || od.IsDelete == false)
                            && od.ProductDetail != null
                            && od.ProductDetail.Product != null)
                        .ToListAsync()
                    : new List<Models.OrderDetail>();

                // Nhóm theo ProductType (Category)
                var categorySales = orderDetails
                    .GroupBy(od => od.ProductDetail?.Product?.ProductType?.TypeName ?? "Không phân loại")
                    .Select(g => new
                    {
                        categoryName = g.Key,
                        totalQuantity = g.Sum(od => od.Quantity ?? 0),
                        totalRevenue = g.Sum(od => od.TotalMoney ?? 0)
                    })
                    .OrderByDescending(x => x.totalQuantity)
                    .ToList();

                return Ok(new
                    {
                        year = targetYear,
                        month = targetMonth,
                        startDate = start.ToString("yyyy-MM-dd"),
                        endDate = end.ToString("yyyy-MM-dd"),
                        categorySales = categorySales
                    });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Lỗi khi lấy dữ liệu sản phẩm", error = ex.Message });
            }
        }
    }
}

