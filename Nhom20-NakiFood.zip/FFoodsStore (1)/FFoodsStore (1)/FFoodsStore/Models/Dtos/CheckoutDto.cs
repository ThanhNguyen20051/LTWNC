namespace FFoodsStore.Models.Dtos
{
    public class CheckoutDto
    {
        public int AccountId { get; set; }
        public string CustomerName { get; set; } = "";
        public string PhoneNumber { get; set; } = "";
        public string Address { get; set; } = "";
        public string PaymentMethod { get; set; } = "cod"; // "cod" hoặc "bank"
        public decimal ShippingFee { get; set; } = 0; // Phí ship
    }
}

