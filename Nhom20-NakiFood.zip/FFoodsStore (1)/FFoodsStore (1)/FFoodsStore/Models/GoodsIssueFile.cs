﻿using System;
using System.Collections.Generic;

namespace FFoodsStore.Models;

public partial class GoodsIssueFile
{
    public int ID { get; set; }

    public int GoodsIssueID { get; set; }

    public string? FileUrl { get; set; }

    public string? FileName { get; set; }

    public DateTime? CreatedDate { get; set; }

    public string? CreatedBy { get; set; }

    public DateTime? UpdatedDate { get; set; }

    public string? UpdatedBy { get; set; }

    public bool? IsDelete { get; set; }
}
