// ===============================
// ORDERS PAGE - Hiển thị đơn hàng đã xác nhận
// ===============================
(function() {
    'use strict';
    
    // ===============================
    // Helper function để lấy account ID từ auth.js
    // ===============================
    function getAccountId() {
        if (window.getCurrentAccountId) {
            return window.getCurrentAccountId();
        }
        return null; // Trả về null nếu chưa login
    }
    let orders = [];
    
    // ===============================
    // Format ngày tháng
    // ===============================
    function formatDate(dateString) {
        if (!dateString) return '';
        const date = new Date(dateString);
        const day = String(date.getDate()).padStart(2, '0');
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const year = date.getFullYear();
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        return `${day}/${month}/${year} ${hours}:${minutes}`;
    }
    
    // ===============================
    // Format giá tiền
    // ===============================
    function formatPrice(amount) {
        return new Intl.NumberFormat('vi-VN').format(amount || 0) + 'đ';
    }
    
    // ===============================
    // Lấy tên trạng thái
    // ===============================
    function getStatusName(status) {
        switch (status) {
            case 1: return 'Đang xử lý';
            case 2: return 'Đang giao';
            case 3: return 'Hoàn thành đơn';
            default: return 'Không xác định';
        }
    }
    
    // ===============================
    // Lấy class CSS cho trạng thái
    // ===============================
    function getStatusClass(status) {
        switch (status) {
            case 1: return 'status-processing';
            case 2: return 'status-delivering';
            case 3: return 'status-completed';
            default: return 'status-processing';
        }
    }
    
    // ===============================
    // Escape HTML để tránh XSS
    // ===============================
    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    // ===============================
    // Load chi tiết đơn hàng để hiển thị preview items
    // ===============================
    async function loadOrderItemsPreview(orderId) {
        try {
            const res = await fetch(`/api/order/${orderId}/details?t=${Date.now()}`);
            if (!res.ok) return null;
            const data = await res.json();
            return data.items || [];
        } catch (error) {
            console.error('Error loading order items:', error);
            return null;
        }
    }
    
    // ===============================
    // Build preview items HTML
    // ===============================
    function buildItemsPreviewHTML(items) {
        if (!items || items.length === 0) return '';
        
        const previewItems = items.slice(0, 3); // Chỉ hiển thị 3 món đầu
        const remainingCount = items.length - previewItems.length;
        
        let html = '<div class="order-items-preview">';
        html += '<h4>📋 Sản phẩm trong đơn hàng:</h4>';
        html += '<div class="items-preview-list">';
        
        previewItems.forEach(item => {
            const productName = item.productDetail?.product?.productName || 'Sản phẩm';
            const quantity = item.quantity || 0;
            html += `<span class="item-preview-badge">${escapeHtml(productName)} x${quantity}</span>`;
        });
        
        if (remainingCount > 0) {
            html += `<span class="item-preview-badge">+${remainingCount} sản phẩm khác</span>`;
        }
        
        html += '</div></div>';
        return html;
    }
    
    // ===============================
    // Load timeline for order
    // ===============================
    async function loadOrderTimeline(orderId) {
        try {
            const res = await fetch(`/api/order/${orderId}/timeline?t=${Date.now()}`);
            if (!res.ok) return null;
            const data = await res.json();
            return data.timeline || [];
        } catch (error) {
            console.error('Error loading order timeline:', error);
            return null;
        }
    }

    // ===============================
    // Load estimated delivery time
    // ===============================
    async function loadEstimatedDelivery(orderId) {
        try {
            const res = await fetch(`/api/order/${orderId}/estimated-delivery?t=${Date.now()}`);
            if (!res.ok) return null;
            const data = await res.json();
            return data;
        } catch (error) {
            console.error('Error loading estimated delivery:', error);
            return null;
        }
    }

    // ===============================
    // Build timeline HTML
    // ===============================
    function buildTimelineHTML(timeline) {
        if (!timeline || timeline.length === 0) return '';
        
        let html = '<div class="order-timeline">';
        html += '<h4 style="margin: 0 0 12px 0; font-size: 15px; color: #666; font-weight: 600;">📋 Tình trạng đơn hàng:</h4>';
        html += '<div class="timeline-list">';
        
        timeline.forEach((item, index) => {
            const isLast = index === timeline.length - 1;
            const timeStr = formatDate(item.timestamp);
            
            html += `
                <div class="timeline-item ${isLast ? 'timeline-active' : ''}">
                    <div class="timeline-icon">${item.icon || '📋'}</div>
                    <div class="timeline-content">
                        <div class="timeline-description">${escapeHtml(item.description || item.statusName)}</div>
                        <div class="timeline-time">${timeStr}</div>
                    </div>
                </div>
            `;
        });
        
        html += '</div></div>';
        return html;
    }

    // ===============================
    // Build estimated delivery HTML
    // ===============================
    function buildEstimatedDeliveryHTML(estimatedData) {
        if (!estimatedData || !estimatedData.estimatedTimeFormatted) return '';
        
        return `
            <div class="estimated-delivery">
                <div class="estimated-delivery-icon">⏰</div>
                <div class="estimated-delivery-content">
                    <div class="estimated-delivery-label">Dự kiến nhận hàng:</div>
                    <div class="estimated-delivery-time">${escapeHtml(estimatedData.estimatedTimeFormatted)}</div>
                </div>
            </div>
        `;
    }

    // ===============================
    // Build order card HTML
    // ===============================
    async function buildOrderCardHTML(order, itemsPreview = null) {
        const statusClass = getStatusClass(order.status || 1);
        const statusName = order.statusName || getStatusName(order.status || 1);
        
        // Load timeline and estimated delivery
        const [timeline, estimatedDelivery] = await Promise.all([
            loadOrderTimeline(order.id),
            loadEstimatedDelivery(order.id)
        ]);
        
        let itemsPreviewHTML = '';
        if (itemsPreview) {
            itemsPreviewHTML = buildItemsPreviewHTML(itemsPreview);
        }
        
        let timelineHTML = '';
        if (timeline) {
            timelineHTML = buildTimelineHTML(timeline);
        }
        
        let estimatedHTML = '';
        if (estimatedDelivery) {
            estimatedHTML = buildEstimatedDeliveryHTML(estimatedDelivery);
        }
        
        return `
            <div class="order-card" data-order-id="${order.id}">
                <div class="order-header">
                    <div class="order-code-section">
                        <div class="order-code">#${escapeHtml(order.orderCode || 'N/A')}</div>
                        <div class="order-date">📅 Đặt ngày: ${formatDate(order.createDate)}</div>
                    </div>
                    <span class="order-status ${statusClass}">
                        ${escapeHtml(statusName)}
                    </span>
                </div>
                
                ${estimatedHTML}
                
                <div class="order-info">
                    <div class="order-info-item">
                        <span class="order-info-label">👤 Tên khách hàng</span>
                        <span class="order-info-value">${escapeHtml(order.customerName || 'N/A')}</span>
                    </div>
                    <div class="order-info-item">
                        <span class="order-info-label">📞 Số điện thoại</span>
                        <span class="order-info-value">${escapeHtml(order.phoneNumber || 'N/A')}</span>
                    </div>
                    <div class="order-info-item">
                        <span class="order-info-label">📍 Địa chỉ giao hàng</span>
                        <span class="order-info-value">${escapeHtml(order.address || 'N/A')}</span>
                    </div>
                </div>
                
                ${timelineHTML}
                
                ${itemsPreviewHTML}
                
                <div class="order-footer">
                    <div>
                        <div style="font-size: 14px; color: #666; margin-bottom: 4px;">Tổng tiền:</div>
                        <div class="order-total">${formatPrice(order.total)}</div>
                    </div>
                    <div class="order-actions">
                        <a href="/Checkout/Success/${order.id}" class="btn-view-detail">
                            👁️ Xem chi tiết
                        </a>
                    </div>
                </div>
            </div>
        `;
    }
    
    // ===============================
    // Load danh sách đơn hàng
    // ===============================
    async function loadOrders() {
        const container = document.getElementById('ordersList');
        if (!container) {
            console.error('ordersList container not found!');
            return;
        }
        
        // Show Ratatouille loader (center screen)
        if (window.showRatatouilleLoader) {
            window.showRatatouilleLoader('Đang tải danh sách đơn hàng...');
        } else if (window.showCompactPageLoader) {
            window.showCompactPageLoader('Đang tải danh sách đơn hàng...');
        } else {
            container.innerHTML = '<div class="loading">⏳ Đang tải danh sách đơn hàng...</div>';
        }
        
        try {
            const accountId = getAccountId();
            if (!accountId) {
                if (window.hideRatatouilleLoader) window.hideRatatouilleLoader();
                container.innerHTML = `
                    <div class="no-orders">
                        <div class="no-orders-icon">🔒</div>
                        <h2>Vui lòng đăng nhập</h2>
                        <p>Bạn cần đăng nhập để xem đơn hàng của mình.</p>
                        <a href="/AccountView/Login" class="btn-browse" style="cursor: pointer; text-decoration: none; display: inline-block;">
                            🔐 Đăng nhập ngay
                        </a>
                    </div>
                `;
                return;
            }
            console.log('Loading orders for account:', accountId);
            const res = await fetch(`/api/order/by-account/${accountId}?t=${Date.now()}`, {
                cache: 'no-store',
                headers: {
                    'Cache-Control': 'no-cache'
                }
            });
            
            if (!res.ok) {
                throw new Error(`HTTP error! status: ${res.status}`);
            }
            
            const data = await res.json();
            orders = data.orders || [];
            
            console.log('Orders loaded:', orders.length);
            
            if (orders.length === 0) {
                container.innerHTML = `
                    <div class="no-orders">
                        <div class="no-orders-icon">📦</div>
                        <h2>Chưa có đơn hàng nào</h2>
                        <p>Bạn chưa có đơn hàng nào đã được xác nhận. Hãy đặt món ngay!</p>
                        <a href="/Menu" class="btn-browse">🍔 Xem thực đơn</a>
                    </div>
                `;
                return;
            }
            
            // Load chi tiết items cho mỗi đơn hàng (song song)
            const ordersWithItems = await Promise.all(
                orders.map(async (order) => {
                    const items = await loadOrderItemsPreview(order.id);
                    return { order, items };
                })
            );
            
            // Render danh sách đơn hàng
            const ordersHTML = await Promise.all(
                ordersWithItems.map(({ order, items }) => buildOrderCardHTML(order, items))
            );
            
            container.innerHTML = ordersHTML.join('');
            
        } catch (error) {
            console.error('Error loading orders:', error);
            // Hide Ratatouille loader on error
            if (window.hideRatatouilleLoader) {
                window.hideRatatouilleLoader();
            } else if (window.hideCompactPageLoader) {
                window.hideCompactPageLoader();
            }
            container.innerHTML = `
                <div class="no-orders">
                    <div class="no-orders-icon">⚠️</div>
                    <h2>Lỗi tải dữ liệu</h2>
                    <p>Có lỗi xảy ra khi tải danh sách đơn hàng. Vui lòng thử lại sau.</p>
                    <button onclick="location.reload()" class="btn-browse" style="cursor: pointer;">
                        🔄 Tải lại trang
                    </button>
                </div>
            `;
        } finally {
            // Hide Ratatouille loader when done
            if (window.hideRatatouilleLoader) {
                window.hideRatatouilleLoader();
            } else if (window.hideCompactPageLoader) {
                window.hideCompactPageLoader();
            }
        }
    }
    
    // ===============================
    // Initialize
    // ===============================
    function init() {
        console.log('Orders page initialized');
        loadOrders();
        
        // Reload khi trang được focus lại
        window.addEventListener('focus', function() {
            console.log('Window focused, reloading orders...');
            loadOrders();
        });
        
        // Reload khi visibility change
        document.addEventListener('visibilitychange', function() {
            if (!document.hidden) {
                console.log('Page visible, reloading orders...');
                loadOrders();
            }
        });
    }
    
    // Đảm bảo DOM đã sẵn sàng
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    
})(); // End IIFE
