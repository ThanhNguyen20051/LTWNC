using Microsoft.AspNetCore.Mvc;
using System.Text;
using System.Text.Json;
using System.Linq;

namespace FFoodsStore.Controllers.Api
{
    [ApiController]
    [Route("api/aichat")]
    public class AiChatController : ControllerBase
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _configuration;

        public AiChatController(
            IHttpClientFactory httpClientFactory,
            IConfiguration configuration)
        {
            _httpClientFactory = httpClientFactory;
            _configuration = configuration;
        }

        // POST: /api/aichat/send
        [HttpPost("send")]
        public async Task<IActionResult> Send([FromBody] AiChatRequest request)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(request.Message))
                {
                    return BadRequest(new { reply = "Tin nhắn không được để trống!" });
                }

                // Get API Key from appsettings.json
                var apiKey = _configuration["Gemini:ApiKey"];
                
                if (string.IsNullOrWhiteSpace(apiKey))
                {
                    Console.Error.WriteLine("Gemini API Key not found in appsettings.json");
                    return StatusCode(500, new { reply = "Xin lỗi, API key chưa được cấu hình. Vui lòng liên hệ admin." });
                }

                // SIMPLE: Generate response without context
                var reply = await GenerateGeminiProResponseAsync(request.Message, apiKey);

                return Ok(new { reply = reply });
            }
            catch (HttpRequestException ex)
            {
                // Handle network exceptions
                Console.Error.WriteLine($"Network error calling Gemini API: {ex.Message}");
                return StatusCode(500, new { reply = "Xin lỗi, đã xảy ra lỗi kết nối. Vui lòng thử lại sau!" });
            }
            catch (JsonException ex)
            {
                // Handle JSON parsing errors
                Console.Error.WriteLine($"JSON parsing error: {ex.Message}");
                return StatusCode(500, new { reply = "Xin lỗi, đã xảy ra lỗi xử lý dữ liệu. Vui lòng thử lại sau!" });
            }
            catch (Exception ex)
            {
                // Handle all other exceptions
                Console.Error.WriteLine($"Error in AiChatController: {ex.Message}");
                Console.Error.WriteLine($"Stack trace: {ex.StackTrace}");
                return StatusCode(500, new { reply = "Xin lỗi, đã xảy ra lỗi. Vui lòng thử lại sau! 😔" });
            }
        }

        // Generate Gemini Pro response - SIMPLE VERSION
        private async Task<string> GenerateGeminiProResponseAsync(string userMessage, string apiKey)
        {
            try
            {
                var client = _httpClientFactory.CreateClient();
                client.Timeout = TimeSpan.FromSeconds(30);

                // SIMPLE: Just send user message, no context
                var requestBody = new
                {
                    contents = new[]
                    {
                        new
                        {
                            parts = new[]
                            {
                                new { text = userMessage }
                            }
                        }
                    },
                    generationConfig = new
                    {
                        temperature = 0.7,
                        topK = 40,
                        topP = 0.95,
                        maxOutputTokens = 1024
                    }
                };

                var jsonContent = JsonSerializer.Serialize(requestBody);
                var httpContent = new StringContent(jsonContent, Encoding.UTF8, "application/json");

                // Call Gemini Pro API (as requested)
                var apiUrl = $"https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={apiKey}";
                
                var response = await client.PostAsync(apiUrl, httpContent);

                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    Console.Error.WriteLine($"Gemini API error ({response.StatusCode}): {errorContent}");
                    
                    // Handle specific error cases
                    if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        throw new Exception("API key không hợp lệ. Vui lòng kiểm tra lại cấu hình.");
                    }
                    else if (response.StatusCode == System.Net.HttpStatusCode.TooManyRequests)
                    {
                        throw new Exception("Quá nhiều yêu cầu. Vui lòng thử lại sau vài giây.");
                    }
                    
                    throw new Exception($"Gemini API error: {response.StatusCode} - {errorContent}");
                }

                var jsonString = await response.Content.ReadAsStringAsync();
                var result = JsonSerializer.Deserialize<GeminiResponse>(jsonString, new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

                // Extract reply from response
                var reply = result?.candidates?.FirstOrDefault()?.content?.parts?.FirstOrDefault()?.text
                    ?? "Xin lỗi, tôi không thể trả lời câu hỏi này. Vui lòng thử lại sau.";

                return reply;
            }
            catch (TaskCanceledException)
            {
                throw new Exception("Yêu cầu hết thời gian chờ. Vui lòng thử lại sau.");
            }
            catch (Exception ex)
            {
                throw new Exception($"Error calling Gemini API: {ex.Message}", ex);
            }
        }

        // Request Model - SIMPLE
        public class AiChatRequest
        {
            public string Message { get; set; } = string.Empty;
        }

        // Gemini Response Models
        private class GeminiResponse
        {
            public List<GeminiCandidate>? candidates { get; set; }
        }

        private class GeminiCandidate
        {
            public GeminiContent? content { get; set; }
        }

        private class GeminiContent
        {
            public List<GeminiPart>? parts { get; set; }
        }

        private class GeminiPart
        {
            public string? text { get; set; }
        }
    }
}

