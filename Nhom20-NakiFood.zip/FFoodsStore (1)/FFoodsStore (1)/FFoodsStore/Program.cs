using Microsoft.EntityFrameworkCore;
using FFoodsStore.Data;
using Microsoft.OpenApi.Models;
using FFoodsStore.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        // Cấu hình JSON để hỗ trợ camelCase (từ frontend) map sang PascalCase (C# model)
        options.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
    });

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "NakiFood API",
        Version = "v1",
        Description = "API cho hệ thống đặt món ăn nhanh NakiFood"
    });
    
    // Include XML comments if available
    var xmlFile = $"{System.Reflection.Assembly.GetExecutingAssembly().GetName().Name}.xml";
    var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    if (File.Exists(xmlPath))
    {
        c.IncludeXmlComments(xmlPath);
    }
    
    // Resolve conflicts with same route names
    c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
    
    // Ignore obsolete actions
    c.IgnoreObsoleteActions();
    c.IgnoreObsoleteProperties();
});

builder.Services.AddCors(o =>
    o.AddPolicy("AllowAll", p => p.AllowAnyOrigin().AllowAnyHeader().AllowAnyMethod()));

builder.Services.AddHttpClient();

builder.Services.AddDbContext<StoreDbContext>(opts =>
    opts.UseSqlServer(builder.Configuration.GetConnectionString("FFoodsStoreConnection")));

var app = builder.Build();

// Seed admin account if not exists
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    try
    {
        var context = services.GetRequiredService<StoreDbContext>();
        
        // Check if admin account exists (Role = 1)
        var adminExists = await context.Accounts
            .AnyAsync(a => a.Email == "admin@fastfood.vn" && a.Role == 1 && !a.IsDelete);
        
        if (!adminExists)
        {
            // Create admin account
            var admin = new FFoodsStore.Models.Account
            {
                Email = "admin@fastfood.vn",
                Password = "123456", // Plain text password - consider hashing in production
                Role = 1, // Admin
                FullName = "Administrator",
                IsActive = 1, // Active
                CreatedDate = DateTime.Now,
                CreatedBy = "System",
                IsDelete = false
            };
            
            context.Accounts.Add(admin);
            await context.SaveChangesAsync();
            Console.WriteLine("✅ Admin account seeded successfully: admin@fastfood.vn / 123456");
        }
        else
        {
            Console.WriteLine("ℹ️ Admin account already exists.");
        }

        // Check if staff account exists (Role = 2)
        var staffExists = await context.Accounts
            .AnyAsync(a => a.Email == "staff@fastfood.vn" && a.Role == 2 && !a.IsDelete);
        
        if (!staffExists)
        {
            // Create staff account
            var staff = new FFoodsStore.Models.Account
            {
                Email = "staff@fastfood.vn",
                Password = "123456", // Plain text password - consider hashing in production
                Role = 2, // Staff
                FullName = "Nhân viên",
                IsActive = 1, // Active
                CreatedDate = DateTime.Now,
                CreatedBy = "System",
                IsDelete = false
            };
            
            context.Accounts.Add(staff);
            await context.SaveChangesAsync();
            Console.WriteLine("✅ Staff account seeded successfully: staff@fastfood.vn / 123456");
        }
        else
        {
            Console.WriteLine("ℹ️ Staff account already exists.");
        }

        // Check if shipper account exists (Role = 3)
        var shipperExists = await context.Accounts
            .AnyAsync(a => a.Email == "shipper@fastfood.vn" && a.Role == 3 && !a.IsDelete);
        
        if (!shipperExists)
        {
            // Create shipper account
            var shipper = new FFoodsStore.Models.Account
            {
                Email = "shipper@fastfood.vn",
                Password = "123456", // Plain text password - consider hashing in production
                Role = 3, // Shipper
                FullName = "Shipper",
                IsActive = 1, // Active
                CreatedDate = DateTime.Now,
                CreatedBy = "System",
                IsDelete = false
            };
            
            context.Accounts.Add(shipper);
            await context.SaveChangesAsync();
            Console.WriteLine("✅ Shipper account seeded successfully: shipper@fastfood.vn / 123456");
        }
        else
        {
            Console.WriteLine("ℹ️ Shipper account already exists.");
        }
    }
    catch (Exception ex)
    {
        Console.WriteLine($"⚠️ Error seeding admin account: {ex.Message}");
    }
}

app.UseStaticFiles();
app.UseRouting();
app.UseCors("AllowAll");

// Enable Swagger in all environments (can be restricted to Development if needed)
app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "NakiFood API v1");
    c.RoutePrefix = "swagger";
    c.DisplayRequestDuration();
    c.EnableDeepLinking();
    c.EnableFilter();
    c.EnableValidator();
});

app.MapControllers();
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
