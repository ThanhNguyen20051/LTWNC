// ===== Config chung =====
const FF_API_BASE = "/api"; // Dùng relative path thay vì hardcoded localhost

// Helper function để lấy account ID từ auth.js
function getAccountIdForSite() {
    if (window.getCurrentAccountId) {
        return window.getCurrentAccountId();
    }
    return null; // Trả về null nếu chưa login
}

// ===== Badge giỏ hàng =====
async function refreshCartBadge() {
  try {
    const accountId = getAccountIdForSite();
    if (!accountId) {
      // Không login thì count = 0
      const badge = document.getElementById("cartCount");
      if (badge) badge.innerText = "0";
      return;
    }
    const res = await fetch(`${FF_API_BASE}/cart/by-account/${accountId}`);
    if (!res.ok) throw new Error("Load cart failed");
    const data = await res.json();
    const count = data.count || 0;
    const badge = document.getElementById("cartCount");
    if (badge) badge.innerText = count;
  } catch (e) {
    console.error("refreshCartBadge:", e);
  }
}
window.refreshCartBadge = refreshCartBadge; // export global

// ===== Thêm vào giỏ =====
async function addToCart(productDetailId) {
  try {
    const accountId = getAccountIdForSite();
    if (!accountId) {
      alert('Vui lòng đăng nhập để thêm sản phẩm vào giỏ hàng!');
      window.location.href = '/AccountView/Login';
      return;
    }
    const res = await fetch(`${FF_API_BASE}/cart/add`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ accountId, productDetailId })
    });
    if (!res.ok) throw new Error("API error");
    await res.json();

    // cập nhật badge sau khi thêm
    refreshCartBadge();
    showCartNotification("Đã thêm món vào giỏ hàng!");
  } catch (e) {
    console.error(e);
    showCartNotification("Không thể thêm vào giỏ!", true);
  }
}

// ===== Toast mini =====
function showCartNotification(message, isError = false) {
  const note = document.createElement("div");
  Object.assign(note.style, {
    position: "fixed", bottom: "20px", right: "20px",
    padding: "10px 16px", borderRadius: "10px",
    background: isError ? "#dc3545" : "#28a745",
    color: "#fff", fontSize: "14px", zIndex: 9999,
    boxShadow: "0 3px 10px rgba(0,0,0,.2)"
  });
  note.textContent = message;
  document.body.appendChild(note);
  setTimeout(() => note.remove(), 2000);
}

const apiBase = "/api/cart";
let cartData = [];

async function loadCart() {
  const container = document.getElementById("cartList");
  const totalEl = document.getElementById("totalPrice");
  
  // Chỉ chạy nếu đang ở trang cart (có element cartList)
  if (!container) {
    // Trang này không có cart, chỉ cập nhật badge nếu cần
    if (window.refreshCartBadge) window.refreshCartBadge();
    return;
  }
  
  const accountId = getAccountIdForSite();
  if (!accountId) {
    container.innerHTML = "<p style='color: #e31d14;'>Vui lòng đăng nhập để xem giỏ hàng!</p>";
    return;
  }
  
  container.innerHTML = "<p>Đang tải dữ liệu...</p>";

  try {
    const res = await fetch(`${apiBase}/by-account/${accountId}`);
    if (!res.ok) throw new Error("Load cart failed");
    const result = await res.json();

    cartData = (result.items || []).map(x => ({
      id: x.id,
      quantity: x.quantity || 0,
      productDetail: x.productDetail
    }));

    if (!cartData.length) {
      container.innerHTML = "<p>Giỏ hàng trống!</p>";
      if (totalEl) totalEl.textContent = "0đ";
    } else {
      renderCart(result.total || 0);
    }

    // cập nhật badge
    if (window.refreshCartBadge) window.refreshCartBadge();
  } catch (err) {
    console.error(err);
    if (container) container.innerHTML = "<p style='color:red;'>Không thể tải dữ liệu!</p>";
    if (window.refreshCartBadge) window.refreshCartBadge();
  }
}

function renderCart(total) {
  const container = document.getElementById("cartList");
  const totalEl = document.getElementById("totalPrice");
  
  // Kiểm tra element tồn tại
  if (!container) return;

  const html = cartData.map(item => {
    const prod = item.productDetail?.product;
    const name = prod?.productName || "Sản phẩm";
    const price = item.productDetail?.price || 0;
    const qty = item.quantity || 0;
    const img = prod?.productImages?.[0]?.imageUrl
      || `https://picsum.photos/seed/${item.productDetail?.productID}/640/420`;

    return `
      <div class="cart-item" data-id="${item.id}">
        <img src="${img}" alt="${name}" class="cart-thumb" />
        <div class="cart-info">
          <h4>${name}</h4>
          <p>Giá: ${price.toLocaleString()}đ</p>
          <div class="qty-control">
            <button onclick="changeQty(${item.id}, -1)">-</button>
            <span>${qty}</span>
            <button onclick="changeQty(${item.id}, 1)">+</button>
          </div>
        </div>
        <button class="btn-remove" onclick="removeItem(${item.id})">🗑 Xóa</button>
      </div>
    `;
  }).join("");

  container.innerHTML = html;
  totalEl.textContent = (total || 0).toLocaleString() + "đ";
}

async function changeQty(id, delta) {
  const item = cartData.find(x => x.id === id);
  if (!item) return;
  const newQty = (item.quantity || 0) + delta;
  if (newQty < 1) return alert("Số lượng tối thiểu là 1!");

  // cập nhật UI trước
  item.quantity = newQty;
  const newTotal = cartData.reduce((s, i) => s + (i.productDetail?.price || 0) * (i.quantity || 0), 0);
  renderCart(newTotal);

  try {
    await fetch(`${apiBase}/update-qty/${id}?qty=${newQty}`, { method: "PUT" });
    if (window.refreshCartBadge) window.refreshCartBadge();
  } catch (e) {
    console.error(e);
  }
}

async function removeItem(id) {
  try {
    await fetch(`${apiBase}/delete/${id}`, { method: "DELETE" });
    cartData = cartData.filter(x => x.id !== id);
    const newTotal = cartData.reduce((s, i) => s + (i.productDetail?.price || 0) * (i.quantity || 0), 0);
    renderCart(newTotal);

    if (!cartData.length) {
      const cartListEl = document.getElementById("cartList");
      const totalPriceEl = document.getElementById("totalPrice");
      if (cartListEl) cartListEl.innerHTML = "<p>Giỏ hàng trống!</p>";
      if (totalPriceEl) totalPriceEl.textContent = "0đ";
    }

    if (window.refreshCartBadge) window.refreshCartBadge();
  } catch (e) {
    console.error(e);
  }
}

function checkout() {
  alert("Thanh toán thành công (demo)!");
}

document.addEventListener("DOMContentLoaded", loadCart);

// ===== Loading Remy cho trang Khuyến mãi và Liên hệ =====
// Thêm mới - không thay đổi code gốc
document.addEventListener("DOMContentLoaded", function() {
    // Tìm các link menu trong navigation
    const allNavLinks = document.querySelectorAll('.nav a, header nav a');
    
    allNavLinks.forEach(link => {
        const href = link.getAttribute('href') || '';
        const text = link.textContent.trim();
        
        // Kiểm tra nếu là link Khuyến mãi hoặc Liên hệ
        const isPromotion = href.includes('/Promotion') || href.includes('Promotion') || text.includes('Khuyến mãi');
        const isContact = href.includes('/Contact') || href.includes('Contact') || text.includes('Liên hệ');
        
        if (isPromotion || isContact) {
            link.addEventListener('click', function(e) {
                // Gọi loading khi click menu
                if (window.showRatatouilleLoader) {
                    window.showRatatouilleLoader('Đang tải dữ liệu...');
                }
            });
        }
    });
});